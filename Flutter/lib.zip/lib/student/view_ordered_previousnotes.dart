import 'dart:convert';
import 'package:college_connect/student/studenthome.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class view_ordered_previousnotes extends StatelessWidget {
  const view_ordered_previousnotes({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: view_ordered_previousnotes_sub(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class view_ordered_previousnotes_sub extends StatefulWidget {
  const view_ordered_previousnotes_sub({Key? key}) : super(key: key);

  @override
  State<view_ordered_previousnotes_sub> createState() => view_ordered_previousnotes_sub_State();
}

class view_ordered_previousnotes_sub_State extends State<view_ordered_previousnotes_sub> {
  late Future<List<Joke>> _orderedNotesFuture;
  bool _isLoading = true;
  List<Joke> _allNotes = [];
  List<Joke> _filteredNotes = [];
  List<String> _statusFilters = ["All", "Paid", "Pending"];
  String _selectedStatus = "All";

  @override
  void initState() {
    super.initState();
    _orderedNotesFuture = _getJokes();
  }

  Future<List<Joke>> _getJokes() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      var data = await http.post(
        Uri.parse(prefs.getString("ip").toString() + "/view_ordered_previousnotes"),
        body: {"sid": prefs.getString('sid').toString()},
      );

      var jsonData = json.decode(data.body);
      List<Joke> jokes = [];

      for (var joke in jsonData["data"]) {
        Joke newJoke = Joke(
          joke["id"].toString(),
          joke["date"].toString(),
          joke["status"].toString(),
          joke["payment_date"].toString(),
          joke["title"].toString(),
          joke["name"].toString(),
          prefs.getString("ip").toString() + joke["file"].toString(),
          joke["price"].toString(),
          joke["student"].toString(),
        );
        jokes.add(newJoke);
      }

      // Sort by date (newest first)
      jokes.sort((a, b) => b.date.compareTo(a.date));

      setState(() {
        _allNotes = jokes;
        _filteredNotes = jokes;
        _isLoading = false;
      });

      return jokes;
    } catch (e) {
      print("Error fetching ordered notes: $e");
      setState(() {
        _isLoading = false;
      });
      return [];
    }
  }

  void _filterByStatus(String status) {
    setState(() {
      _selectedStatus = status;
      if (status == "All") {
        _filteredNotes = _allNotes;
      } else {
        _filteredNotes = _allNotes.where((note) {
          return note.status.toLowerCase() == status.toLowerCase();
        }).toList();
      }
    });
  }

  Future<void> _refreshNotes() async {
    setState(() {
      _isLoading = true;
      _orderedNotesFuture = _getJokes();
    });
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case "paid":
        return Color(0xFF10B981); // Green
      case "pending":
        return Color(0xFFF59E0B); // Amber
      default:
        return Color(0xFF667EEA); // Blue
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFAFAFA),
      body: SafeArea(
        child: Column(
          children: [
            // Clean Minimal Header
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                  bottom: BorderSide(color: Color(0xFFE8E8E8), width: 1),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: IconButton(
                          onPressed: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (context) => home()),
                            );
                          },
                          icon: Icon(Icons.arrow_back_ios_new_rounded,
                              size: 16, color: Color(0xFF667EEA)),
                          padding: EdgeInsets.zero,
                        ),
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Ordered Notes",
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF1E293B),
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              _isLoading
                                  ? "Loading..."
                                  : "${_filteredNotes.length} ordered notes",
                              style: TextStyle(
                                fontSize: 13,
                                color: Color(0xFF64748B),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: Icon(
                          Icons.shopping_bag_outlined,
                          size: 22,
                          color: Color(0xFF667EEA),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 16),

                  // Status Filter Section
                  FutureBuilder<List<Joke>>(
                    future: _orderedNotesFuture,
                    builder: (context, snapshot) {
                      if (_isLoading) {
                        return SizedBox(
                          height: 40,
                          child: Center(
                            child: SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Color(0xFF7C3AED),
                              ),
                            ),
                          ),
                        );
                      }

                      if (_allNotes.isEmpty) {
                        return Container(
                          height: 40,
                          child: Center(
                            child: Text(
                              "No ordered notes yet",
                              style: TextStyle(
                                color: Color(0xFF64748B),
                                fontSize: 13,
                              ),
                            ),
                          ),
                        );
                      }

                      return Container(
                        height: 40,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: _statusFilters.length,
                          itemBuilder: (context, index) {
                            final status = _statusFilters[index];
                            final isSelected = _selectedStatus == status;
                            Color statusColor = _getStatusColor(status == "All" ? "pending" : status);

                            return Padding(
                              padding: EdgeInsets.only(right: 8),
                              child: ChoiceChip(
                                label: Text(
                                  status,
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: isSelected ? Colors.white : statusColor,
                                  ),
                                ),
                                selected: isSelected,
                                onSelected: (selected) {
                                  if (selected) {
                                    _filterByStatus(status);
                                  }
                                },
                                backgroundColor: statusColor.withOpacity(0.1),
                                selectedColor: statusColor,
                                shape: StadiumBorder(
                                  side: BorderSide(
                                    color: isSelected ? statusColor : statusColor.withOpacity(0.3),
                                    width: 1,
                                  ),
                                ),
                                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),

            // Ordered Notes List
            Expanded(
              child: FutureBuilder<List<Joke>>(
                future: _orderedNotesFuture,
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (_isLoading) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 28,
                            height: 28,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFF7C3AED),
                            ),
                          ),
                          SizedBox(height: 16),
                          Text(
                            "Loading Ordered Notes...",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    );
                  }

                  if (snapshot.hasError) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              Icons.error_outline_rounded,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            "Error Loading Notes",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            "Please check your connection",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          SizedBox(height: 16),
                          TextButton(
                            onPressed: _refreshNotes,
                            style: TextButton.styleFrom(
                              foregroundColor: Color(0xFF667EEA),
                            ),
                            child: Text("Retry"),
                          ),
                        ],
                      ),
                    );
                  }

                  if (_filteredNotes.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              _selectedStatus != "All"
                                  ? Icons.filter_alt_outlined
                                  : Icons.shopping_bag_outlined,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            _selectedStatus != "All"
                                ? "No notes with ${_selectedStatus} status"
                                : "No Ordered Notes Yet",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            _selectedStatus != "All"
                                ? "Try selecting a different status"
                                : "Your ordered notes will appear here",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          if (_selectedStatus != "All")
                            Padding(
                              padding: EdgeInsets.only(top: 16),
                              child: TextButton(
                                onPressed: () => _filterByStatus("All"),
                                style: TextButton.styleFrom(
                                  foregroundColor: Color(0xFF667EEA),
                                ),
                                child: Text("Show All Orders"),
                              ),
                            ),
                        ],
                      ),
                    );
                  }

                  return ListView.builder(
                    padding: EdgeInsets.all(16),
                    itemCount: _filteredNotes.length,
                    itemBuilder: (BuildContext context, int index) {
                      var note = _filteredNotes[index];
                      return _buildOrderedNoteCard(note);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOrderedNoteCard(Joke note) {
    Color statusColor = _getStatusColor(note.status);
    bool isPaid = note.status.toLowerCase() == "paid";

    return Container(
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Color(0xFFE8E8E8), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Note Header
          Padding(
            padding: EdgeInsets.all(20),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    gradient: isPaid
                        ? LinearGradient(
                      colors: [Color(0xFF10B981), Color(0xFF059669)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                        : LinearGradient(
                      colors: [Color(0xFFF59E0B), Color(0xFFD97706)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isPaid ? Color(0xFF10B981) : Color(0xFFF59E0B),
                      width: 2,
                    ),
                  ),
                  child: Icon(
                    isPaid ? Icons.shopping_bag_rounded : Icons.pending_outlined,
                    size: 32,
                    color: Colors.white,
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        note.title,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1E293B),
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 6),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: statusColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: statusColor, width: 1),
                        ),
                        child: Text(
                          note.status.toUpperCase(),
                          style: TextStyle(
                            fontSize: 13,
                            color: statusColor,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(
                            Icons.subject_outlined,
                            size: 14,
                            color: Color(0xFF94A3B8),
                          ),
                          SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              note.name,
                              style: TextStyle(
                                fontSize: 13,
                                color: Color(0xFF64748B),
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Note Details
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ID Badge
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Color(0xFFF8FAFC),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Color(0xFFF1F5F9)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.badge_outlined,
                        size: 12,
                        color: Color(0xFF64748B),
                      ),
                      SizedBox(width: 6),
                      Text(
                        "Order ID: ${note.id}",
                        style: TextStyle(
                          fontSize: 11,
                          color: Color(0xFF64748B),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 20),

                // Note Details
                _buildDetailRow(Icons.description_outlined, "Note Title", note.title),
                SizedBox(height: 12),
                _buildDetailRow(Icons.subject_outlined, "Subject", note.name),
                SizedBox(height: 12),
                _buildDetailRow(Icons.person_outlined, "Student", note.student),
                SizedBox(height: 12),
                _buildDetailRow(Icons.calendar_today_outlined, "Order Date", _formatDate(note.date)),
                SizedBox(height: 12),
                _buildDetailRow(Icons.calendar_month_outlined, "Payment Date",
                    note.payment_date.isEmpty || note.payment_date == "null"
                        ? "Not Paid Yet"
                        : _formatDate(note.payment_date)),
                SizedBox(height: 12),
                _buildPriceDetailRow(note.price),
                SizedBox(height: 12),
                _buildStatusDetailRow(note.status),

                // File Preview
                SizedBox(height: 20),
                Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Color(0xFFF0F9FF),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Color(0xFFBAE6FD)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(
                            Icons.attach_file_outlined,
                            size: 16,
                            color: Color(0xFF0EA5E9),
                          ),
                          SizedBox(width: 8),
                          Text(
                            "File Preview",
                            style: TextStyle(
                              fontSize: 12,
                              color: Color(0xFF0369A1),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      Container(
                        height: 100,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: Color(0xFFE2E8F0)),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: Image.network(
                            note.file,
                            height: 100,
                            width: double.infinity,
                            fit: BoxFit.cover,
                            loadingBuilder: (context, child, loadingProgress) {
                              if (loadingProgress == null) return child;
                              return Center(
                                child: CircularProgressIndicator(
                                  value: loadingProgress.expectedTotalBytes != null
                                      ? loadingProgress.cumulativeBytesLoaded /
                                      loadingProgress.expectedTotalBytes!
                                      : null,
                                ),
                              );
                            },
                            errorBuilder: (context, error, stackTrace) {
                              return Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.insert_drive_file_outlined,
                                      size: 32,
                                      color: Color(0xFF94A3B8),
                                    ),
                                    SizedBox(height: 4),
                                    Text(
                                      "File Preview",
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: Color(0xFF64748B),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                      SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          "Available for download if paid",
                          style: TextStyle(
                            fontSize: 11,
                            color: Color(0xFF64748B),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 16),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Color(0xFFF1F5F9)),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: Color(0xFFF5F3FF),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: Color(0xFFE9E0FF)),
            ),
            child: Icon(
              icon,
              size: 16,
              color: Color(0xFF8B5CF6),
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF1E293B),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPriceDetailRow(String price) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Color(0xFFF0F9FF),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Color(0xFFBAE6FD)),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: Color(0xFF0EA5E9).withOpacity(0.1),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: Color(0xFF0EA5E9)),
            ),
            child: Icon(
              Icons.attach_money_rounded,
              size: 16,
              color: Color(0xFF0EA5E9),
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Price Paid",
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF0369A1),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  "₹$price",
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xFF0369A1),
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusDetailRow(String status) {
    Color statusColor = _getStatusColor(status);
    bool isPaid = status.toLowerCase() == "paid";

    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: statusColor.withOpacity(0.05),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: statusColor.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: statusColor),
            ),
            child: Icon(
              isPaid ? Icons.check_circle_outline : Icons.pending_outlined,
              size: 16,
              color: statusColor,
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Order Status",
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  status.toUpperCase(),
                  style: TextStyle(
                    fontSize: 14,
                    color: statusColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(String dateString) {
    try {
      DateTime date = DateTime.parse(dateString);
      return "${date.day.toString().padLeft(2, '0')}-${date.month.toString().padLeft(2, '0')}-${date.year}";
    } catch (e) {
      return dateString;
    }
  }
}

class Joke {
  final String id;
  final String date;
  final String status;
  final String payment_date;
  final String title;
  final String name;
  final String file;
  final String price;
  final String student;

  Joke(this.id, this.date, this.status, this.payment_date, this.title, this.name, this.file, this.price, this.student);
}








// import 'dart:convert';
//
// import 'package:college_connect/student/studenthome.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart'as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// class view_ordered_previousnotes extends StatelessWidget {
// const view_ordered_previousnotes({Key? key}) : super(key: key);
//
// @override
// Widget build(BuildContext context) {
// return MaterialApp(home:view_ordered_previousnotes_sub() ,);
// }
// }
//
// class view_ordered_previousnotes_sub extends StatefulWidget {
// const view_ordered_previousnotes_sub({Key? key}) : super(key: key);
//
// @override
// State<view_ordered_previousnotes_sub> createState() => view_ordered_previousnotes_sub_State();
// }
//
// class view_ordered_previousnotes_sub_State extends State<view_ordered_previousnotes_sub> {
//   Future<List<Joke>> _getJokes() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     String b = prefs.getString("uid").toString();
//     String foodimage="";
//     var data =
//     await http.post(Uri.parse(prefs.getString("ip").toString()+"/view_ordered_previousnotes"),
//         body: {"sid":prefs.getString('sid').toString()}
//     );
//
//     var jsonData = json.decode(data.body);
// //    print(jsonData);
//     List<Joke> jokes = [];
//     for (var joke in jsonData["data"]) {
//       print(joke);
//       Joke newJoke = Joke(
//           joke["id"].toString(),
//           joke["date"].toString(),
//           joke["status"].toString(),
//           joke["payment_date"].toString(),
//           joke["title"].toString(),
//           joke["name"].toString(),
//           prefs.getString("ip").toString()+joke["file"].toString(),
//           joke["price"].toString(),
//           joke["student"].toString()
//       );
//       jokes.add(newJoke);
//     }
//     return jokes;
//   }
// @override
// Widget build(BuildContext context) {
// return Scaffold(
//   appBar: AppBar(title: Text("Ordered Notes"),centerTitle: true,leading: IconButton(onPressed: (){
//     Navigator.push(context, MaterialPageRoute(builder: (context)=>home()));
//   }, icon: Icon(Icons.arrow_back)),),
//   body:
//
//
//   Container(
//
//     child:
//     FutureBuilder(
//       future: _getJokes(),
//       builder: (BuildContext context, AsyncSnapshot snapshot) {
// //              print("snapshot"+snapshot.toString());
//         if (snapshot.data == null) {
//           return Container(
//             child: Center(
//               child: Text("Loading..."),
//             ),
//           );
//         } else {
//           return ListView.builder(
//             itemCount: snapshot.data.length,
//             itemBuilder: (BuildContext context, int index) {
//               var i = snapshot.data![index];
//               return Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: Card(
//                   elevation: 3,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(10),
//                     side: BorderSide(color: Colors.grey.shade300),
//                   ),
//                   child: Padding(
//                     padding: const EdgeInsets.all(16.0),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//
//                         SizedBox(height: 10),
//                         Image.network(i.file,height: 100,width: 200,),
//                         _buildRow("Id:", i.id.toString()),
//                         _buildRow("Date:", i.date.toString()),
//                         _buildRow("Status:", i.status.toString()),
//                         _buildRow("Payment Date:", i.payment_date.toString()),
//                         _buildRow("Previous Note Name:", i.title.toString()),
//                         _buildRow("Subject Name:", i.name.toString()),
//                         _buildRow("File:", i.file.toString()),
//                         _buildRow("Price:", i.price.toString()),
//                         _buildRow("Student Name:", i.student.toString()),
//
//
//                       ],
//                     ),
//                   ),
//                 ),
//               );
//             },
//           );
//
//
//         }
//       },
//
//
//     ),
//
//
//
//
//
//   ),
// );
// }
// }
// Widget _buildRow(String label, String value) {
//   return Padding(
//     padding: const EdgeInsets.symmetric(vertical: 4),
//     child: Row(
//       children: [
//         SizedBox(
//           width: 100,
//           child: Text(
//             label,
//             style: TextStyle(
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//         ),
//         SizedBox(width: 5),
//         Flexible(
//           child: Text(
//             value,
//             style: TextStyle(
//               color: Colors.grey.shade800,
//             ),
//           ),
//         ),
//       ],
//     ),
//   );
// }
//
// class Joke {
//   final String id;
//   final String date;
//   final String status;
//   final String payment_date;
//   final String title;
//   final String name;
//   final String file;
//   final String price;
//   final String student;
//
//
//
//
//
//   Joke(this.id,this.date,this.status,this.payment_date,this.title,this.name,this.file,this.price,this.student);
// //  print("hiiiii");
// }