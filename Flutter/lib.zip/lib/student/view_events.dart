import 'dart:convert';
import 'package:college_connect/student/studenthome.dart';
import 'package:college_connect/student/view_result_events.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class view_events extends StatelessWidget {
  const view_events({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: view_events_sub(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class view_events_sub extends StatefulWidget {
  const view_events_sub({Key? key}) : super(key: key);

  @override
  State<view_events_sub> createState() => view_events_sub_State();
}

class view_events_sub_State extends State<view_events_sub> {
  late Future<List<Event>> _eventsFuture;
  List<Event> _allEvents = [];
  List<Event> _filteredEvents = [];
  List<String> _statuses = ["All", "Upcoming", "Ongoing", "Completed"];
  String _selectedStatus = "All";
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _eventsFuture = _fetchEvents();
  }

  Future<List<Event>> _fetchEvents() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String b = prefs.getString("uid").toString();
      var data = await http.post(
        Uri.parse(prefs.getString("ip").toString() + "/view_events"),
        body: {"id": b},
      );

      var jsonData = json.decode(data.body);
      List<Event> eventList = [];

      for (var event in jsonData["data"]) {
        Event newEvent = Event(
          event["id"].toString(),
          event["title"].toString(),
          event["description"].toString(),
          event["event_date"].toString(),
          event["location"].toString(),
          event["status"].toString(),
        );
        eventList.add(newEvent);
      }

      setState(() {
        _allEvents = eventList;
        _filteredEvents = eventList;
        _isLoading = false;
      });

      return eventList;
    } catch (e) {
      print("Error fetching events: $e");
      setState(() {
        _isLoading = false;
      });
      return [];
    }
  }

  void _filterByStatus(String status) {
    setState(() {
      _selectedStatus = status;
      _applyFilters();
    });
  }

  void _applyFilters() {
    List<Event> filtered = _allEvents;

    // Apply status filter
    if (_selectedStatus != "All") {
      filtered = filtered
          .where((event) => _getEventStatus(event.event_date, event.status) == _selectedStatus)
          .toList();
    }

    setState(() {
      _filteredEvents = filtered;
    });
  }

  String _getEventStatus(String eventDate, String status) {
    // You can implement your own logic here based on event_date and status
    // For now, we'll use the status from the API
    if (status.toLowerCase() == "completed") return "Completed";
    if (status.toLowerCase() == "ongoing") return "Ongoing";
    return "Upcoming";
  }

  Future<void> _refreshEvents() async {
    setState(() {
      _isLoading = true;
      _eventsFuture = _fetchEvents();
    });
  }

  Future<void> _registerForEvent(String eventId) async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      var response = await http.post(
        Uri.parse(prefs.getString("ip").toString() + "/register_events"),
        body: {
          'id': eventId,
          "sid": prefs.getString("sid"),
        },
      );

      if (response.statusCode == 200) {
        // Show success dialog
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            backgroundColor: Colors.white,
            surfaceTintColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
              side: BorderSide(color: Color(0xFFE8E8E8), width: 1),
            ),
            title: Row(
              children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: Color(0xFFD1FAE5),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.check_rounded,
                    size: 18,
                    color: Color(0xFF10B981),
                  ),
                ),
                SizedBox(width: 12),
                Text(
                  "Registration Successful",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF1E293B),
                  ),
                ),
              ],
            ),
            content: Container(
              child: Text(
                "You have successfully registered for the event. You will receive confirmation details soon.",
                style: TextStyle(
                  fontSize: 14,
                  color: Color(0xFF64748B),
                  height: 1.5, // Changed from lineHeight to height
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  _refreshEvents();
                },
                style: TextButton.styleFrom(
                  foregroundColor: Color(0xFF667EEA),
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                ),
                child: Text(
                  "Done",
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      print("Error registering for event: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFAFAFA),
      body: SafeArea(
        child: Column(
          children: [
            // Clean Minimal Header
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                  bottom: BorderSide(color: Color(0xFFE8E8E8), width: 1),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: IconButton(
                          onPressed: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (context) => home()),
                            );
                          },
                          icon: Icon(Icons.arrow_back_ios_new_rounded,
                              size: 16, color: Color(0xFF667EEA)),
                          padding: EdgeInsets.zero,
                        ),
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "College Events",
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF1E293B),
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              _isLoading
                                  ? "Loading..."
                                  : "${_filteredEvents.length} events",
                              style: TextStyle(
                                fontSize: 13,
                                color: Color(0xFF64748B),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: Icon(
                          Icons.event_outlined,
                          size: 22,
                          color: Color(0xFF667EEA),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 16),

                  // Status Filter Section
                  FutureBuilder<List<Event>>(
                    future: _eventsFuture,
                    builder: (context, snapshot) {
                      if (_isLoading) {
                        return SizedBox(
                          height: 40,
                          child: Center(
                            child: SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Color(0xFF7C3AED),
                              ),
                            ),
                          ),
                        );
                      }

                      return Container(
                        height: 40,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: _statuses.length,
                          itemBuilder: (context, index) {
                            final status = _statuses[index];
                            final isSelected = _selectedStatus == status;
                            Color statusColor = _getStatusColor(status);

                            return Padding(
                              padding: EdgeInsets.only(right: 8),
                              child: ChoiceChip(
                                label: Text(
                                  status,
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: isSelected ? Colors.white : statusColor,
                                  ),
                                ),
                                selected: isSelected,
                                onSelected: (selected) {
                                  if (selected) {
                                    _filterByStatus(status);
                                  }
                                },
                                backgroundColor: statusColor.withOpacity(0.1),
                                selectedColor: statusColor,
                                shape: StadiumBorder(
                                  side: BorderSide(
                                    color: isSelected ? statusColor : statusColor.withOpacity(0.3),
                                    width: 1,
                                  ),
                                ),
                                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),

            // Events List
            Expanded(
              child: FutureBuilder<List<Event>>(
                future: _eventsFuture,
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (_isLoading) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 28,
                            height: 28,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFF7C3AED),
                            ),
                          ),
                          SizedBox(height: 16),
                          Text(
                            "Loading Events...",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    );
                  }

                  if (snapshot.hasError) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              Icons.error_outline_rounded,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            "Error Loading Events",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            "Please check your connection",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          SizedBox(height: 16),
                          TextButton(
                            onPressed: _refreshEvents,
                            style: TextButton.styleFrom(
                              foregroundColor: Color(0xFF667EEA),
                            ),
                            child: Text("Retry"),
                          ),
                        ],
                      ),
                    );
                  }

                  if (_filteredEvents.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              _selectedStatus != "All"
                                  ? Icons.filter_alt_outlined
                                  : Icons.event_outlined,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            _selectedStatus != "All"
                                ? "No events in this category"
                                : "No Events Available",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            _selectedStatus != "All"
                                ? "Try a different status filter"
                                : "Events will appear here when available",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          if (_selectedStatus != "All")
                            Padding(
                              padding: EdgeInsets.only(top: 16),
                              child: TextButton(
                                onPressed: () {
                                  _filterByStatus("All");
                                },
                                style: TextButton.styleFrom(
                                  foregroundColor: Color(0xFF667EEA),
                                ),
                                child: Text("Clear Filter"),
                              ),
                            ),
                        ],
                      ),
                    );
                  }

                  return ListView.builder(
                    padding: EdgeInsets.all(16),
                    itemCount: _filteredEvents.length,
                    itemBuilder: (BuildContext context, int index) {
                      var event = _filteredEvents[index];
                      return _buildEventCard(event);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEventCard(Event event) {
    Color statusColor = _getStatusColor(_getEventStatus(event.event_date, event.status));

    return Container(
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Color(0xFFE8E8E8), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Event Header
          Padding(
            padding: EdgeInsets.all(20),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: statusColor, width: 2),
                  ),
                  child: Icon(
                    _getEventIcon(event.status),
                    size: 32,
                    color: statusColor,
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        event.title,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1E293B),
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 6),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: statusColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: statusColor, width: 1),
                        ),
                        child: Text(
                          _getEventStatus(event.event_date, event.status),
                          style: TextStyle(
                            fontSize: 13,
                            color: statusColor,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(
                            Icons.calendar_today_outlined,
                            size: 14,
                            color: Color(0xFF94A3B8),
                          ),
                          SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              event.event_date,
                              style: TextStyle(
                                fontSize: 13,
                                color: Color(0xFF64748B),
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Event Details
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ID Badge
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Color(0xFFF8FAFC),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Color(0xFFF1F5F9)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.badge_outlined,
                        size: 12,
                        color: Color(0xFF64748B),
                      ),
                      SizedBox(width: 6),
                      Text(
                        "ID: ${event.id}",
                        style: TextStyle(
                          fontSize: 11,
                          color: Color(0xFF64748B),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 20),

                // Event Details
                _buildDetailRow(Icons.title_outlined, "Title", event.title),
                SizedBox(height: 12),
                _buildDetailRow(Icons.description_outlined, "Description", event.description),
                SizedBox(height: 12),
                _buildDetailRow(Icons.calendar_today_outlined, "Date", event.event_date),
                SizedBox(height: 12),
                _buildDetailRow(Icons.location_on_outlined, "Location", event.location),
                SizedBox(height: 12),
                _buildStatusDetailRow(event.status),

                SizedBox(height: 20),

                // Action Buttons
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        height: 44,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Color(0xFF667EEA),
                              Color(0xFF764BA2),
                            ],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xFF667EEA).withOpacity(0.25),
                              blurRadius: 8,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        child: TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => view_result_events()),
                            );
                          },
                          style: TextButton.styleFrom(
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.visibility_outlined, size: 18),
                              SizedBox(width: 8),
                              Text(
                                "View Results",
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Container(
                        height: 44,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE2E8F0), width: 1),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 4,
                              offset: Offset(0, 2),
                            ),
                          ],
                        ),
                        child: TextButton(
                          onPressed: () {
                            _showRegistrationDialog(event);
                          },
                          style: TextButton.styleFrom(
                            foregroundColor: Color(0xFF334155),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.app_registration_outlined, size: 18),
                              SizedBox(width: 8),
                              Text(
                                "Register",
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 20),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showRegistrationDialog(Event event) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: Color(0xFFE8E8E8), width: 1),
        ),
        title: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: Color(0xFFE0F2FE),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                Icons.app_registration_outlined,
                size: 18,
                color: Color(0xFF0369A1),
              ),
            ),
            SizedBox(width: 12),
            Expanded(
              child: Text(
                "Register for Event",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF1E293B),
                ),
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Are you sure you want to register for:",
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF64748B),
              ),
            ),
            SizedBox(height: 8),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Color(0xFFF8FAFC),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Color(0xFFF1F5F9)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    event.title,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF1E293B),
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    "Date: ${event.event_date}",
                    style: TextStyle(
                      fontSize: 13,
                      color: Color(0xFF64748B),
                    ),
                  ),
                  Text(
                    "Location: ${event.location}",
                    style: TextStyle(
                      fontSize: 13,
                      color: Color(0xFF64748B),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 16),
            Text(
              "Registration cannot be canceled once confirmed.",
              style: TextStyle(
                fontSize: 12,
                color: Color(0xFF94A3B8),
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            style: TextButton.styleFrom(
              foregroundColor: Color(0xFF64748B),
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            ),
            child: Text("Cancel"),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color(0xFF667EEA),
                  Color(0xFF764BA2),
                ],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(8),
              boxShadow: [
                BoxShadow(
                  color: Color(0xFF667EEA).withOpacity(0.25),
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: TextButton(
              onPressed: () {
                Navigator.pop(context);
                _registerForEvent(event.id);
              },
              style: TextButton.styleFrom(
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              ),
              child: Text(
                "Confirm Registration",
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Color(0xFFF1F5F9)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: Color(0xFFF5F3FF),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: Color(0xFFE9E0FF)),
            ),
            child: Icon(
              icon,
              size: 16,
              color: Color(0xFF8B5CF6),
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF1E293B),
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: label == "Description" ? 3 : 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusDetailRow(String status) {
    Color statusColor = _getStatusColor(_getEventStatus("", status));

    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: statusColor.withOpacity(0.05),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: statusColor.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: statusColor),
            ),
            child: Icon(
              _getEventIcon(status),
              size: 16,
              color: statusColor,
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Status",
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  _getEventStatus("", status),
                  style: TextStyle(
                    fontSize: 14,
                    color: statusColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case "upcoming":
        return Color(0xFF667EEA); // Blue
      case "ongoing":
        return Color(0xFFF59E0B); // Amber
      case "completed":
        return Color(0xFF10B981); // Green
      default:
        return Color(0xFF667EEA); // Blue
    }
  }

  IconData _getEventIcon(String status) {
    switch (status.toLowerCase()) {
      case "completed":
        return Icons.check_circle_outline;
      case "ongoing":
        return Icons.play_circle_outline;
      default:
        return Icons.event_outlined;
    }
  }
}

class Event {
  final String id;
  final String title;
  final String description;
  final String event_date;
  final String location;
  final String status;

  Event(this.id, this.title, this.description, this.event_date, this.location, this.status);
}








// import 'dart:convert';
//
// import 'package:college_connect/student/studenthome.dart';
// import 'package:college_connect/student/view_result_events.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart'as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// class view_events extends StatelessWidget {
// const view_events({Key? key}) : super(key: key);
//
// @override
// Widget build(BuildContext context) {
// return MaterialApp(home: view_events_sub(),);
// }
// }
//
// class  view_events_sub extends StatefulWidget {
// const view_events_sub({Key? key}) : super(key: key);
//
// @override
// State<view_events_sub> createState() => view_events_sub_State();
// }
//
// class view_events_sub_State extends State<view_events_sub> {
//   Future<List<Joke>> _getJokes() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     String b = prefs.getString("uid").toString();
//     String foodimage="";
//     var data =
//     await http.post(Uri.parse(prefs.getString("ip").toString()+"/view_events"),
//         body: {"id":b}
//     );
//
//     var jsonData = json.decode(data.body);
// //    print(jsonData);
//     List<Joke> jokes = [];
//     for (var joke in jsonData["data"]) {
//       print(joke);
//       Joke newJoke = Joke(
//           joke["id"].toString(),
//           joke["title"].toString(),
//           joke["description"].toString(),
//           joke["event_date"].toString(),
//           joke["location"].toString(),
//           joke["status"].toString()
//       );
//       jokes.add(newJoke);
//     }
//     return jokes;
//   }
//
//   @override
// Widget build(BuildContext context) {
// return Scaffold(
//   appBar: AppBar(title: Text("Events"),centerTitle: true,leading: IconButton(onPressed: (){
//     Navigator.push(context, MaterialPageRoute(builder: (context)=>home()));
//   }, icon: Icon(Icons.arrow_back)),),
//   body:
//
//
//   Container(
//
//     child:
//     FutureBuilder(
//       future: _getJokes(),
//       builder: (BuildContext context, AsyncSnapshot snapshot) {
// //              print("snapshot"+snapshot.toString());
//         if (snapshot.data == null) {
//           return Container(
//             child: Center(
//               child: Text("Loading..."),
//             ),
//           );
//         } else {
//           return ListView.builder(
//             itemCount: snapshot.data.length,
//             itemBuilder: (BuildContext context, int index) {
//               var i = snapshot.data![index];
//               return Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: Card(
//                   elevation: 3,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(10),
//                     side: BorderSide(color: Colors.grey.shade300),
//                   ),
//                   child: Padding(
//                     padding: const EdgeInsets.all(16.0),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//
//                         SizedBox(height: 10),
//                         _buildRow("Id:", i.id.toString()),
//                         _buildRow("Title:", i.title.toString()),
//                         _buildRow("Description:", i.description.toString()),
//                         _buildRow("Event Date:", i.event_date.toString()),
//                         _buildRow("Location:", i.location.toString()),
//                         _buildRow("Status:", i.status.toString()),
//
//                         SizedBox(height: 10),
//                         Row(children: [
//                           ElevatedButton(onPressed: () async {
//                             SharedPreferences prefs= await SharedPreferences.getInstance();
//                             var data =
//                             Navigator.push(context, MaterialPageRoute(builder: (context)=>view_result_events()));
//                           }, child: Text("Results"))
//                         ],),
//                         SizedBox(height: 10),
//                         Row(children: [
//                           ElevatedButton(onPressed: () async {
//
//                             showDialog(context: context, builder: (context)=>AlertDialog(
//                               title: Text('event registration'),
//                               content: Text('Registered Successfully'),
//                               actions: [
//                                 TextButton(onPressed: () async {
//                                   SharedPreferences prefs= await SharedPreferences.getInstance();
//                                   var data =
//                                       await http.post(Uri.parse(prefs.getString("ip").toString()+"/register_events"),
//                                       body: {'id':i.id.toString(),
//                                         "sid":prefs.getString("sid"),
//                                       }
//                                   );
//                                   Navigator.push(context, MaterialPageRoute(builder: (context)=>view_events()));
//
//                                 }, child: Text('ok')),
//
//
//                                 TextButton(onPressed: (){
//                                   Navigator.pop(context);
//                                 }, child: Text('cancel'))
//                               ],
//                             ));
//                           }, child: Text("Register"))
//                         ],),
//                         SizedBox(height: 10),
//
//
//                       ],
//                     ),
//                   ),
//                 ),
//               );
//             },
//           );
//         }
//       },
//     ),
//   ),
// );
// }
// }
// Widget _buildRow(String label, String value) {
//   return Padding(
//     padding: const EdgeInsets.symmetric(vertical: 4),
//     child: Row(
//       children: [
//         SizedBox(
//           width: 100,
//           child: Text(
//             label,
//             style: TextStyle(
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//         ),
//         SizedBox(width: 5),
//         Flexible(
//           child: Text(
//             value,
//             style: TextStyle(
//               color: Colors.grey.shade800,
//             ),
//           ),
//         ),
//       ],
//     ),
//   );
// }
//
// class Joke {
//   final String id;
//   final String title;
//   final String description;
//   final String event_date;
//   final String location;
//   final String status;
//
//
//
//
//
//   Joke(this.id,this.title, this.description,this.event_date,this.location,this.status);
// //  print("hiiiii");
// }