import 'dart:convert';
import 'package:college_connect/student/studenthome.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'RazorpayScreen.dart';

class view_others_previousnotes extends StatelessWidget {
  const view_others_previousnotes({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: view_others_previousnotes_sub(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class view_others_previousnotes_sub extends StatefulWidget {
  const view_others_previousnotes_sub({Key? key}) : super(key: key);

  @override
  State<view_others_previousnotes_sub> createState() => view_others_previousnotes_sub_State();
}

class view_others_previousnotes_sub_State extends State<view_others_previousnotes_sub> {
  late Future<List<Joke>> _notesFuture;
  bool _isLoading = true;
  List<Joke> _allNotes = [];
  List<Joke> _filteredNotes = [];
  List<String> _subjectFilters = ["All"];
  String _selectedSubject = "All";

  @override
  void initState() {
    super.initState();
    _notesFuture = _getJokes();
  }

  Future<List<Joke>> _getJokes() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      var data = await http.post(
        Uri.parse(prefs.getString("ip").toString() + "/view_others_previousnotes"),
        body: {"sid": prefs.getString('sid').toString()},
      );

      var jsonData = json.decode(data.body);
      List<Joke> jokes = [];
      Set<String> subjectSet = Set();

      for (var joke in jsonData["data"]) {
        Joke newJoke = Joke(
          joke["id"].toString(),
          joke["date"].toString(),
          joke["title"].toString(),
          prefs.getString("ip").toString() + joke["file"].toString(),
          joke["price"].toString(),
          joke["subject"].toString(),
          joke["student"].toString(),
          joke["sub_id"].toString(),
        );
        jokes.add(newJoke);

        if (joke["subject"].toString().isNotEmpty) {
          subjectSet.add(joke["subject"].toString());
        }
      }

      // Sort subjects alphabetically
      List<String> sortedSubjects = subjectSet.toList()..sort();

      // Sort by date (newest first)
      jokes.sort((a, b) => b.date.compareTo(a.date));

      setState(() {
        _allNotes = jokes;
        _filteredNotes = jokes;
        _subjectFilters = ["All"] + sortedSubjects;
        _isLoading = false;
      });

      return jokes;
    } catch (e) {
      print("Error fetching previous notes: $e");
      setState(() {
        _isLoading = false;
      });
      return [];
    }
  }

  void _filterBySubject(String subject) {
    setState(() {
      _selectedSubject = subject;
      if (subject == "All") {
        _filteredNotes = _allNotes;
      } else {
        _filteredNotes = _allNotes.where((note) {
          return note.subject == subject;
        }).toList();
      }
    });
  }

  Future<void> _refreshNotes() async {
    setState(() {
      _isLoading = true;
      _notesFuture = _getJokes();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFAFAFA),
      body: SafeArea(
        child: Column(
          children: [
            // Clean Minimal Header
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                  bottom: BorderSide(color: Color(0xFFE8E8E8), width: 1),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: IconButton(
                          onPressed: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (context) => home()),
                            );
                          },
                          icon: Icon(Icons.arrow_back_ios_new_rounded,
                              size: 16, color: Color(0xFF667EEA)),
                          padding: EdgeInsets.zero,
                        ),
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Previous Notes",
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF1E293B),
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              _isLoading
                                  ? "Loading..."
                                  : "${_filteredNotes.length} notes",
                              style: TextStyle(
                                fontSize: 13,
                                color: Color(0xFF64748B),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: Icon(
                          Icons.note_outlined,
                          size: 22,
                          color: Color(0xFF667EEA),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 16),

                  // Subject Filter Section
                  FutureBuilder<List<Joke>>(
                    future: _notesFuture,
                    builder: (context, snapshot) {
                      if (_isLoading) {
                        return SizedBox(
                          height: 40,
                          child: Center(
                            child: SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Color(0xFF7C3AED),
                              ),
                            ),
                          ),
                        );
                      }

                      return Container(
                        height: 40,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: _subjectFilters.length,
                          itemBuilder: (context, index) {
                            final subject = _subjectFilters[index];
                            final isSelected = _selectedSubject == subject;

                            return Padding(
                              padding: EdgeInsets.only(right: 8),
                              child: ChoiceChip(
                                label: Text(
                                  subject,
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: isSelected ? Colors.white : Color(0xFF667EEA),
                                  ),
                                ),
                                selected: isSelected,
                                onSelected: (selected) {
                                  if (selected) {
                                    _filterBySubject(subject);
                                  }
                                },
                                backgroundColor: Color(0xFFF0F5FF),
                                selectedColor: Color(0xFF667EEA),
                                shape: StadiumBorder(
                                  side: BorderSide(
                                    color: isSelected ? Color(0xFF667EEA) : Color(0xFFE0E7FF),
                                    width: 1,
                                  ),
                                ),
                                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),

            // Notes List
            Expanded(
              child: FutureBuilder<List<Joke>>(
                future: _notesFuture,
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (_isLoading) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 28,
                            height: 28,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFF7C3AED),
                            ),
                          ),
                          SizedBox(height: 16),
                          Text(
                            "Loading Notes...",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    );
                  }

                  if (snapshot.hasError) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              Icons.error_outline_rounded,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            "Error Loading Notes",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            "Please check your connection",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          SizedBox(height: 16),
                          TextButton(
                            onPressed: _refreshNotes,
                            style: TextButton.styleFrom(
                              foregroundColor: Color(0xFF667EEA),
                            ),
                            child: Text("Retry"),
                          ),
                        ],
                      ),
                    );
                  }

                  if (_filteredNotes.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              _selectedSubject != "All"
                                  ? Icons.filter_alt_outlined
                                  : Icons.note_outlined,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            _selectedSubject != "All"
                                ? "No notes in ${_selectedSubject}"
                                : "No Notes Available",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            _selectedSubject != "All"
                                ? "Try selecting a different subject"
                                : "Notes will appear here once uploaded",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          if (_selectedSubject != "All")
                            Padding(
                              padding: EdgeInsets.only(top: 16),
                              child: TextButton(
                                onPressed: () => _filterBySubject("All"),
                                style: TextButton.styleFrom(
                                  foregroundColor: Color(0xFF667EEA),
                                ),
                                child: Text("Show All Subjects"),
                              ),
                            ),
                        ],
                      ),
                    );
                  }

                  return ListView.builder(
                    padding: EdgeInsets.all(16),
                    itemCount: _filteredNotes.length,
                    itemBuilder: (BuildContext context, int index) {
                      var note = _filteredNotes[index];
                      return _buildNoteCard(note);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNoteCard(Joke note) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Color(0xFFE8E8E8), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Note Header
          Padding(
            padding: EdgeInsets.all(20),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    color: Color(0xFFF5F3FF),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Color(0xFFE9E0FF), width: 2),
                  ),
                  child: Icon(
                    Icons.description_rounded,
                    size: 32,
                    color: Color(0xFF8B5CF6),
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        note.title,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                      SizedBox(height: 6),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Color(0xFFF5F3FF),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: Color(0xFFE9E0FF), width: 1),
                        ),
                        child: Text(
                          note.subject,
                          style: TextStyle(
                            fontSize: 13,
                            color: Color(0xFF7C3AED),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(
                            Icons.person_outlined,
                            size: 14,
                            color: Color(0xFF94A3B8),
                          ),
                          SizedBox(width: 6),
                          Text(
                            "By: ${note.student}",
                            style: TextStyle(
                              fontSize: 13,
                              color: Color(0xFF64748B),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Note Details
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ID Badge
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Color(0xFFF8FAFC),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Color(0xFFF1F5F9)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.badge_outlined,
                        size: 12,
                        color: Color(0xFF64748B),
                      ),
                      SizedBox(width: 6),
                      Text(
                        "ID: ${note.id}",
                        style: TextStyle(
                          fontSize: 11,
                          color: Color(0xFF64748B),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 20),

                // Note Details
                _buildDetailRow(Icons.description_outlined, "Title", note.title),
                SizedBox(height: 12),
                _buildDetailRow(Icons.subject_outlined, "Subject", note.subject),
                SizedBox(height: 12),
                _buildDetailRow(Icons.person_outlined, "Uploaded By", note.student),
                SizedBox(height: 12),
                _buildDetailRow(Icons.calendar_today_outlined, "Date", _formatDate(note.date)),
                SizedBox(height: 12),
                _buildDetailRow(Icons.attach_money_outlined, "Price", "₹${note.price}"),
                SizedBox(height: 12),
                _buildDetailRow(Icons.fingerprint_outlined, "Subject ID", note.sub_id),

                SizedBox(height: 24),

                // Action Buttons
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        height: 46,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFF667EEA), width: 1.5),
                        ),
                        child: Material(
                          color: Colors.transparent,
                          borderRadius: BorderRadius.circular(10),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(10),
                            onTap: () async {
                              final String ipfsUrl = note.file.toString();
                              final Uri uri = Uri.parse(ipfsUrl);

                              if (await canLaunchUrl(uri)) {
                                await launchUrl(uri, mode: LaunchMode.externalApplication);
                              } else {
                                throw '❌ Could not launch $ipfsUrl';
                              }
                            },
                            child: Center(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.visibility_outlined,
                                    size: 16,
                                    color: Color(0xFF667EEA),
                                  ),
                                  SizedBox(width: 10),
                                  Text(
                                    'View File',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      color: Color(0xFF667EEA),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Container(
                        height: 46,
                        decoration: BoxDecoration(
                          color: Color(0xFF667EEA),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Material(
                          color: Colors.transparent,
                          borderRadius: BorderRadius.circular(10),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(10),
                            onTap: () async {
                              SharedPreferences sh = await SharedPreferences.getInstance();
                              var data = await http.post(
                                Uri.parse('${sh.getString('ip')}/send_request_for_notes'),
                                body: {
                                  'pnid': note.id.toString(),
                                  'sid': sh.getString('sid').toString(),
                                },
                              );
                              var decoded = json.decode(data.body);
                              if (decoded['status'] == 'ok') {
                                showDialog(
                                  context: context,
                                  builder: (context) => AlertDialog(
                                    title: Text('Request Sent'),
                                    content: Text('Request sent successfully!'),
                                    actions: [
                                      TextButton(
                                        onPressed: () async {
                                          Navigator.pop(context);
                                        },
                                        child: Text('OK'),
                                      ),
                                    ],
                                  ),
                                );
                              }
                            },
                            child: Center(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.send_outlined,
                                    size: 16,
                                    color: Colors.white,
                                  ),
                                  SizedBox(width: 10),
                                  Text(
                                    'Request',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    "Preview file or request access to download",
                    style: TextStyle(
                      fontSize: 11,
                      color: Color(0xFF94A3B8),
                    ),
                  ),
                ),
                SizedBox(height: 16),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Color(0xFFF1F5F9)),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: Color(0xFFF5F3FF),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: Color(0xFFE9E0FF)),
            ),
            child: Icon(
              icon,
              size: 16,
              color: Color(0xFF8B5CF6),
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF1E293B),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(String dateString) {
    try {
      DateTime date = DateTime.parse(dateString);
      return "${date.day.toString().padLeft(2, '0')}-${date.month.toString().padLeft(2, '0')}-${date.year}";
    } catch (e) {
      return dateString;
    }
  }
}

class Joke {
  final String id;
  final String date;
  final String title;
  final String file;
  final String price;
  final String subject;
  final String student;
  final String sub_id;

  Joke(this.id, this.date, this.title, this.file, this.price, this.subject, this.student, this.sub_id);
}








// import 'dart:convert';
//
// import 'package:college_connect/student/studenthome.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart'as http;
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:url_launcher/url_launcher.dart';
//
// import 'RazorpayScreen.dart';
//
// class view_others_previousnotes extends StatelessWidget {
// const view_others_previousnotes({Key? key}) : super(key: key);
//
// @override
// Widget build(BuildContext context) {
// return MaterialApp(home:view_others_previousnotes_sub(),);
// }
// }
//
// class view_others_previousnotes_sub extends StatefulWidget {
// const view_others_previousnotes_sub({Key? key}) : super(key: key);
//
// @override
// State<view_others_previousnotes_sub> createState() => view_others_previousnotes_sub_State();
// }
//
// class view_others_previousnotes_sub_State extends State<view_others_previousnotes_sub> {
//   Future<List<Joke>> _getJokes() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     String b = prefs.getString("uid").toString();
//     String foodimage="";
//     var data =
//     await http.post(Uri.parse(prefs.getString("ip").toString()+"/view_others_previousnotes"),
//         body: {"sid":prefs.getString('sid').toString()}
//     );
//
//     var jsonData = json.decode(data.body);
// //    print(jsonData);
//     List<Joke> jokes = [];
//     for (var joke in jsonData["data"]) {
//       print(joke);
//       Joke newJoke = Joke(
//           joke["id"].toString(),
//           joke["date"].toString(),
//           joke["title"].toString(),
//           prefs.getString("ip").toString()+joke["file"].toString(),
//           joke["price"].toString(),
//           joke["subject"].toString(),
//           joke["student"].toString(),
//           joke["sub_id"].toString()
//       );
//       jokes.add(newJoke);
//     }
//     return jokes;
//   }
// @override
// Widget build(BuildContext context) {
// return Scaffold(
//   appBar: AppBar(title: Text("Others Previous notes"),centerTitle: true,leading: IconButton(onPressed: (){
//     Navigator.push(context, MaterialPageRoute(builder: (context)=>home()));
//   }, icon: Icon(Icons.arrow_back)),),
//   body:
//
//
//   Container(
//
//     child:
//     FutureBuilder(
//       future: _getJokes(),
//       builder: (BuildContext context, AsyncSnapshot snapshot) {
// //              print("snapshot"+snapshot.toString());
//         if (snapshot.data == null) {
//           return Container(
//             child: Center(
//               child: Text("Loading..."),
//             ),
//           );
//         } else {
//           return ListView.builder(
//             itemCount: snapshot.data.length,
//             itemBuilder: (BuildContext context, int index) {
//               var i = snapshot.data![index];
//               return Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: Card(
//                   elevation: 3,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(10),
//                     side: BorderSide(color: Colors.grey.shade300),
//                   ),
//                   child: Padding(
//                     padding: const EdgeInsets.all(16.0),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//
//                         SizedBox(height: 10),
//                         _buildRow("id:", i.id.toString()),
//                         _buildRow("Date:", i.date.toString()),
//                         _buildRow("Title:", i.title.toString()),
//                         //Image.network(i.file.toString(),height:100,width:100,),
//                         _buildRow("price:",i.price.toString()),
//                         _buildRow("Subject Name:", i.subject.toString()),
//                         _buildRow("Student Name:", i.student.toString()),
//                         _buildRow("sub_id:", i.sub_id.toString()),
//                         SizedBox(height: 10),
//                         ElevatedButton(onPressed: () async {
//                           final String ipfsUrl = i.file.toString();
//
// // ✅ Convert the string to a Uri object (required by url_launcher)
//                           final Uri uri = Uri.parse(ipfsUrl);
//
// // 🔍 Check if the URL can be launched
//                           if (await canLaunchUrl(uri)) {
//                             // 🚀 Launch the URL in an external application (e.g., browser, PDF viewer)
//                             await launchUrl(uri, mode: LaunchMode.externalApplication);
//                           } else {
//                             // ⚠ Handle the error gracefully (you can also show a toast/snackbar)
//                             throw '❌ Could not launch $ipfsUrl';
//                           }
//                         }, child: Text("view")),
//                         SizedBox(height: 10),
//                         ElevatedButton(onPressed: () async {
//                           SharedPreferences sh=await SharedPreferences.getInstance();
//                           var data=await http.post(Uri.parse('${sh.getString('ip')}/send_request_for_notes'),
//                           body: {
//                             'pnid':i.id.toString(),
//                             'sid':sh.getString('sid').toString(),
//
//                           });
//                           var decoded=json.decode(data.body);
//                           if(decoded['status']=='ok'){
//                             showDialog(context: context, builder: (context)=>AlertDialog(
//                               title: Text('request'),
//                               content: Text('sended Successfully'),
//                               actions: [
//                                 TextButton(onPressed: () async {
//                                   Navigator.pop(context);
//                                 }, child: Text('ok')),
//
//                               ],
//                             ));
//                           }
//                           Navigator.push(context, MaterialPageRoute(builder: (context)=>view_others_previousnotes()));
//                         }, child: Text('request'))
//
//                         // ElevatedButton(onPressed: ()async{
//                         //   SharedPreferences prefs= await SharedPreferences.getInstance();
//                         //   prefs.setString("id",i.id.toString());
//                         //
//                         //   prefs.setString("price",i.price.toString());
//                         //   Navigator.push(context, MaterialPageRoute(builder: (context)=>RazorpayScreen()));
//                         // }, child: Text("ORDER"))
//
//                       ],
//                     ),
//                   ),
//                 ),
//               );
//             },
//           );
//
//
//         }
//       },
//
//
//     ),
//
//
//
//
//
//   ),
// );
// }
// }
// Widget _buildRow(String label, String value) {
//   return Padding(
//     padding: const EdgeInsets.symmetric(vertical: 4),
//     child: Row(
//       children: [
//         SizedBox(
//           width: 100,
//           child: Text(
//             label,
//             style: TextStyle(
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//         ),
//         SizedBox(width: 5),
//         Flexible(
//           child: Text(
//             value,
//             style: TextStyle(
//               color: Colors.grey.shade800,
//             ),
//           ),
//         ),
//       ],
//     ),
//   );
// }
//
// class Joke {
//   final String id;
//   final String date;
//   final String title;
//   final String file;
//   final String price;
//   final String subject;
//   final String student;
//   final String sub_id;
//
//   Joke(this.id,this.date, this.title,this.file,this.price,this.subject,this.student,this.sub_id);
// //  print("hiiiii");
// }