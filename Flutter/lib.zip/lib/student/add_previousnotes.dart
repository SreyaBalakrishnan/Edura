import 'dart:convert';
import 'package:college_connect/student/studenthome.dart';
import 'package:college_connect/student/view_my_previousnotes.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class add_previousnotes extends StatelessWidget {
  const add_previousnotes({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: add_previousnotes_sub(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class add_previousnotes_sub extends StatefulWidget {
  const add_previousnotes_sub({Key? key}) : super(key: key);

  @override
  State<add_previousnotes_sub> createState() => add_previousnotes_sub_State();
}

class add_previousnotes_sub_State extends State<add_previousnotes_sub> {
  TextEditingController title = TextEditingController();
  TextEditingController price = TextEditingController();
  PlatformFile? _selectedFile;
  Uint8List? _webFileBytes;
  bool _isLoading = false;
  String _errorMessage = '';

  Future<void> _pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      allowMultiple: false,
      type: FileType.any,
    );

    if (result != null) {
      setState(() {
        _selectedFile = result.files.first;
        _errorMessage = '';
      });

      if (kIsWeb) {
        _webFileBytes = result.files.first.bytes;
      }
    }
  }

  Future<void> _submitForm() async {
    if (title.text.isEmpty) {
      setState(() {
        _errorMessage = 'Please enter a title for the notes';
      });
      return;
    }

    if (price.text.isEmpty) {
      setState(() {
        _errorMessage = 'Please enter a price';
      });
      return;
    }

    if (_selectedFile == null) {
      setState(() {
        _errorMessage = 'Please select a file to upload';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      SharedPreferences sh = await SharedPreferences.getInstance();
      var request = await http.MultipartRequest(
        'POST',
        Uri.parse('${sh.getString('ip')}/add_previous_notes'),
      );

      // Form Data
      request.fields['title'] = title.text;
      request.fields['price'] = price.text;
      request.fields['sid'] = sh.getString('sid').toString();
      request.fields['subid'] = sh.getString('subid').toString();

      // File Upload
      if (kIsWeb) {
        request.files.add(http.MultipartFile.fromBytes(
          'file',
          _webFileBytes!,
          filename: _selectedFile!.name,
        ));
      } else {
        request.files.add(await http.MultipartFile.fromPath(
          'file',
          _selectedFile!.path!,
        ));
      }

      var response = await request.send();

      if (response.statusCode == 200) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => view_my_previousnotes()),
        );
      } else {
        setState(() {
          _errorMessage = 'Failed to upload. Please try again.';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Error: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFAFAFA),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Clean Minimal Header
              Container(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border(
                    bottom: BorderSide(color: Color(0xFFE8E8E8), width: 1),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.03),
                      blurRadius: 6,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Color(0xFFF0F5FF),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                      ),
                      child: IconButton(
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (context) => home()),
                          );
                        },
                        icon: Icon(Icons.arrow_back_ios_new_rounded,
                            size: 16, color: Color(0xFF667EEA)),
                        padding: EdgeInsets.zero,
                      ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Add Previous Notes",
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF1E293B),
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            "Upload study materials for other students",
                            style: TextStyle(
                              fontSize: 13,
                              color: Color(0xFF64748B),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: Color(0xFFF0F5FF),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                      ),
                      child: Icon(
                        Icons.note_add_outlined,
                        size: 22,
                        color: Color(0xFF667EEA),
                      ),
                    ),
                  ],
                ),
              ),

              // Form Content
              Padding(
                padding: EdgeInsets.all(24),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Color(0xFFE8E8E8), width: 1),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.02),
                        blurRadius: 6,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Title Field
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.title_outlined,
                                  size: 16,
                                  color: Color(0xFF667EEA),
                                ),
                                SizedBox(width: 8),
                                Text(
                                  "Note Title",
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    color: Color(0xFF1E293B),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 8),
                            Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: Color(0xFFE2E8F0)),
                              ),
                              child: TextField(
                                controller: title,
                                style: TextStyle(
                                  fontSize: 15,
                                  color: Color(0xFF1E293B),
                                ),
                                decoration: InputDecoration(
                                  hintText: "Enter note title (e.g., Calculus Formulas)",
                                  hintStyle: TextStyle(
                                    color: Color(0xFF94A3B8),
                                    fontSize: 14,
                                  ),
                                  border: InputBorder.none,
                                  contentPadding: EdgeInsets.all(16),
                                ),
                              ),
                            ),
                          ],
                        ),

                        SizedBox(height: 24),

                        // Price Field
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.attach_money_outlined,
                                  size: 16,
                                  color: Color(0xFF667EEA),
                                ),
                                SizedBox(width: 8),
                                Text(
                                  "Price (₹)",
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    color: Color(0xFF1E293B),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 8),
                            Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: Color(0xFFE2E8F0)),
                              ),
                              child: TextField(
                                controller: price,
                                keyboardType: TextInputType.number,
                                style: TextStyle(
                                  fontSize: 15,
                                  color: Color(0xFF1E293B),
                                ),
                                decoration: InputDecoration(
                                  hintText: "Enter price in rupees",
                                  hintStyle: TextStyle(
                                    color: Color(0xFF94A3B8),
                                    fontSize: 14,
                                  ),
                                  border: InputBorder.none,
                                  contentPadding: EdgeInsets.all(16),
                                ),
                              ),
                            ),
                          ],
                        ),

                        SizedBox(height: 24),

                        // File Upload Section
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.attach_file_outlined,
                                  size: 16,
                                  color: Color(0xFF667EEA),
                                ),
                                SizedBox(width: 8),
                                Text(
                                  "Upload File",
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    color: Color(0xFF1E293B),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 12),

                            // File Upload Card
                            Container(
                              width: double.infinity,
                              decoration: BoxDecoration(
                                color: Color(0xFFF8FAFC),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: Color(0xFFE2E8F0),
                                  width: 1.5,
                                ),
                              ),
                              child: Material(
                                color: Colors.transparent,
                                borderRadius: BorderRadius.circular(12),
                                child: InkWell(
                                  borderRadius: BorderRadius.circular(12),
                                  onTap: _pickFile,
                                  child: Padding(
                                    padding: EdgeInsets.all(24),
                                    child: Column(
                                      children: [
                                        Icon(
                                          Icons.cloud_upload_outlined,
                                          size: 48,
                                          color: Color(0xFF667EEA),
                                        ),
                                        SizedBox(height: 16),
                                        Text(
                                          _selectedFile != null
                                              ? _selectedFile!.name
                                              : "Select PDF, DOC, or Image File",
                                          style: TextStyle(
                                            fontSize: 15,
                                            color: _selectedFile != null
                                                ? Color(0xFF1E293B)
                                                : Color(0xFF64748B),
                                            fontWeight: _selectedFile != null
                                                ? FontWeight.w600
                                                : FontWeight.normal,
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                        SizedBox(height: 8),
                                        Text(
                                          "Click to browse files",
                                          style: TextStyle(
                                            fontSize: 13,
                                            color: Color(0xFF94A3B8),
                                          ),
                                        ),
                                        if (_selectedFile != null) ...[
                                          SizedBox(height: 16),
                                          Container(
                                            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                            decoration: BoxDecoration(
                                              color: Color(0xFFF0F9FF),
                                              borderRadius: BorderRadius.circular(6),
                                              border: Border.all(color: Color(0xFFBAE6FD)),
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Icon(
                                                  Icons.check_circle_outline_rounded,
                                                  size: 14,
                                                  color: Color(0xFF0EA5E9),
                                                ),
                                                SizedBox(width: 6),
                                                Text(
                                                  "File Selected",
                                                  style: TextStyle(
                                                    fontSize: 12,
                                                    color: Color(0xFF0369A1),
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),

                        // Error Message
                        if (_errorMessage.isNotEmpty) ...[
                          SizedBox(height: 20),
                          Container(
                            padding: EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Color(0xFFFEF2F2),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Color(0xFFFECACA)),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.error_outline_rounded,
                                  color: Color(0xFFDC2626),
                                  size: 16,
                                ),
                                SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    _errorMessage,
                                    style: TextStyle(
                                      fontSize: 13,
                                      color: Color(0xFFDC2626),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],

                        SizedBox(height: 32),

                        // Guidelines
                        Container(
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Color(0xFFF0F9FF),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: Color(0xFFBAE6FD),
                              width: 1.5,
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.info_outline_rounded,
                                    color: Color(0xFF0EA5E9),
                                    size: 16,
                                  ),
                                  SizedBox(width: 8),
                                  Text(
                                    "Upload Guidelines",
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Color(0xFF0369A1),
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 8),
                              Text(
                                "• Upload PDF, DOC, or image files only\n• File size should be under 10MB\n• Clear title helps students find your notes\n• Set reasonable price for accessibility",
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Color(0xFF0C4A6E),
                                  height: 1.5,
                                ),
                              ),
                            ],
                          ),
                        ),

                        SizedBox(height: 32),

                        // Submit Button
                        Container(
                          width: double.infinity,
                          height: 52,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            gradient: LinearGradient(
                              colors: [
                                Color(0xFF667EEA),
                                Color(0xFF8B5CF6),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF667EEA).withOpacity(0.3),
                                blurRadius: 10,
                                offset: Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Material(
                            color: Colors.transparent,
                            borderRadius: BorderRadius.circular(12),
                            child: InkWell(
                              borderRadius: BorderRadius.circular(12),
                              onTap: _isLoading ? null : _submitForm,
                              child: Center(
                                child: _isLoading
                                    ? SizedBox(
                                  width: 24,
                                  height: 24,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                                    : Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.upload_rounded,
                                      size: 20,
                                      color: Colors.white,
                                    ),
                                    SizedBox(width: 10),
                                    Text(
                                      "Upload Notes",
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),

                        SizedBox(height: 16),
                        Align(
                          alignment: Alignment.centerRight,
                          child: Text(
                            "Notes will be available for other students",
                            style: TextStyle(
                              fontSize: 11,
                              color: Color(0xFF94A3B8),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}








// import 'dart:convert';
//
// import 'package:college_connect/student/studenthome.dart';
// import 'package:college_connect/student/view_my_previousnotes.dart';
// import 'package:file_picker/file_picker.dart';
// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart'as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
//
// class add_previousnotes extends StatelessWidget {
//   const add_previousnotes({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(home:add_previousnotes_sub() ,);
//   }
// }
// class  add_previousnotes_sub extends StatefulWidget {
//   const add_previousnotes_sub({Key? key}) : super(key: key);
//
//   @override
//   State<add_previousnotes_sub> createState() => add_previousnotes_sub_State();
// }
//
// class add_previousnotes_sub_State extends State<add_previousnotes_sub> {
//   TextEditingController title=TextEditingController();
//   TextEditingController price=TextEditingController();
//   TextEditingController subject=TextEditingController();
//   PlatformFile? _selectedFile;
//   Uint8List? _webFileBytes;
//   String? _result;
//   bool _isLoading = false;
//
//   // =====================================================
//   // 📸 PICK FILE FUNCTION
//   // =====================================================
//   Future<void> _pickFile() async {
//     FilePickerResult? result = await FilePicker.platform.pickFiles(
//       allowMultiple: false,
//       type: FileType.any, // Any file type allowed
//     );
//
//     if (result != null) {
//       setState(() {
//         _selectedFile = result.files.first;
//         _result = null;
//       });
//
//       if (kIsWeb) {
//         _webFileBytes = result.files.first.bytes;
//       }
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         appBar: AppBar(title: Text("Previous Notes"),centerTitle: true,leading: IconButton(onPressed: (){
//           Navigator.push(context, MaterialPageRoute(builder: (context)=>home()));
//         }, icon: Icon(Icons.arrow_back)),),
//         body: Center(child: Column(children: [
//           SizedBox(height: 30,),
//           SizedBox(height: 40,width: 300,child: TextField(controller: title,
//             decoration: InputDecoration(border: OutlineInputBorder(),labelText: "Name of Notes/Text"),
//           ),),
//           SizedBox(height: 30,),
//           SizedBox(height: 40,width: 300,child: TextField(controller: price,
//             decoration: InputDecoration(border: OutlineInputBorder(),labelText: "Price"),
//           ),),
//           SizedBox(height: 30,),
//
//           ElevatedButton.icon(
//             icon: Icon(Icons.upload_file),
//             label: Text("Select File"),
//             onPressed: _pickFile,
//           ),
//           if (_selectedFile != null) ...[
//             SizedBox(height: 10),
//             Text("Selected: ${_selectedFile!.name}"),
//           ],
// ElevatedButton(onPressed: () async {
//   SharedPreferences sh=await SharedPreferences.getInstance();
//   var request =   await http.MultipartRequest(
//       'POST',
//       Uri.parse('${sh.getString('ip')}/add_previous_notes')
//   );
//
//   // 🔹 Normal Form Data
//   request.fields['title'] = title.text;
//   request.fields['price'] = price.text;
//   request.fields['sid'] = sh.getString('sid').toString();
//   request.fields['subid'] = sh.getString('subid').toString();
//
//   // 🔹 File Upload Part
//   if (kIsWeb) {
//     request.files.add(http.MultipartFile.fromBytes(
//       'file',
//       _webFileBytes!,
//       filename: _selectedFile!.name,
//     ));
//   } else {
//     request.files.add(await http.MultipartFile.fromPath(
//       'file',
//       _selectedFile!.path!,
//     ));
//   }
//   // =====================================================
//   // 🌐 END SERVER UPLOAD SECTION
//   // =====================================================
//
//   var response = await request.send();
//   Navigator.push(context, MaterialPageRoute(builder: (context)=>view_my_previousnotes()));
//
// }, child: Text("Add"))
//
//         ],),)
//     );
//   }
// }
