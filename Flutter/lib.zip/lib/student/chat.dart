import 'dart:async';
import 'dart:convert';
import 'package:college_connect/student/studenthome.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const MyChatApp());
}

class MyChatApp extends StatelessWidget {
  const MyChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Group Chat',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Color(0xFFFAFAFA),
      ),
      home: const MyChatPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyChatPage extends StatefulWidget {
  const MyChatPage({super.key});

  @override
  State<MyChatPage> createState() => _MyChatPageState();
}

class ChatMessage {
  final String messageContent;
  final String messageType;
  final String senderName;
  final String date;

  ChatMessage({
    required this.messageContent,
    required this.messageType,
    required this.senderName,
    required this.date,
  });
}

class _MyChatPageState extends State<MyChatPage> {
  bool _isDisposed = false;
  String groupName = "Group Chat";
  String userName = "";

  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  List<ChatMessage> messages = [];
  Timer? _messageTimer;

  // From your original code
  List<String> from_id_ = <String>[];
  List<String> to_id_ = <String>[];
  List<String> message_ = <String>[];
  List<String> date_ = <String>[];
  List<String> type = <String>[];

  @override
  void initState() {
    super.initState();
    _loadUserData();
    _startMessagePolling();
  }

  @override
  void dispose() {
    _isDisposed = true;
    _messageTimer?.cancel();
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _loadUserData() async {
    final pref = await SharedPreferences.getInstance();
    setState(() {
      userName = pref.getString("name") ?? "User";
    });
  }

  void _startMessagePolling() {
    _messageTimer = Timer.periodic(Duration(seconds: 2), (_) {
      if (!_isDisposed) {
        _viewMessages();
      }
    });
  }

  Future<void> _viewMessages() async {
    try {
      final pref = await SharedPreferences.getInstance();

      // IMPORTANT: Check this URL construction - matches your working code
      String urls = pref.getString('ip') ?? '';
      String url = '$urls/user_viewchat';

      print("Fetching messages from: $url");
      print("LID: ${pref.getString("lid")}");
      print("GROUP_id: ${pref.getString('GROUP_id')}");

      final response = await http.post(Uri.parse(url), body: {
        'lid': pref.getString("lid") ?? '',
        'GROUP_id': pref.getString('GROUP_id') ?? '',
      });

      print("Response status: ${response.statusCode}");
      print("Response body: ${response.body}");

      var jsondata = json.decode(response.body);
      String status = jsondata['status'];
      print("API Status: $status");

      if (status == 'success') {
        var arr = jsondata["data"];
        print("Data array: $arr");

        List<ChatMessage> newMessages = [];
        List<String> from_id = [];
        List<String> to_id = [];
        List<String> message = [];
        List<String> date = [];
        List<String> typeList = [];

        for (int i = 0; i < arr.length; i++) {
          from_id.add(arr[i]['from'].toString());
          to_id.add(arr[i]['to'].toString());
          message.add(arr[i]['msg']);
          date.add(arr[i]['date'].toString());
          typeList.add(arr[i]['type'].toString());

          // IMPORTANT: Use the same logic as your original code
          if ("me" == arr[i]['type'].toString()) {
            newMessages.add(ChatMessage(
              messageContent: arr[i]['msg'],
              messageType: "sender",
              senderName: arr[i]['from_name']?.toString() ?? 'Unknown',
              date: arr[i]['date'].toString(),
            ));
          } else {
            newMessages.add(ChatMessage(
              messageContent: arr[i]['msg'],
              messageType: "receiver",
              senderName: arr[i]['from_name']?.toString() ?? 'Unknown',
              date: arr[i]['date'].toString(),
            ));
          }
        }

        if (!_isDisposed) {
          setState(() {
            messages = newMessages;
            from_id_ = from_id;
            to_id_ = to_id;
            message_ = message;
            date_ = date;
            type = typeList;
          });
          _scrollToBottom();
        }
      }
    } catch (e) {
      print("Error fetching messages: $e");
    }
  }

  Future<void> _sendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty) return;

    try {
      final pref = await SharedPreferences.getInstance();

      // IMPORTANT: Use the same URL construction as your working code
      String ip = pref.getString("ip") ?? '';
      String url = ip + "/user_sendchat";

      print("Sending message to: $url");
      print("Message: $message");
      print("LID: ${pref.getString("lid")}");
      print("GROUP_id: ${pref.getString('GROUP_id')}");

      final response = await http.post(Uri.parse(url), body: {
        'message': message,
        'lid': pref.getString("lid") ?? '',
        'GROUP_id': pref.getString('GROUP_id') ?? '',
      });

      print("Send response: ${response.statusCode}");
      print("Send response body: ${response.body}");

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        if (jsonData['status'] == 'success') {
          _messageController.clear();
          // Immediately refresh messages
          await _viewMessages();
        }
      }
    } catch (e) {
      print("Error sending message: $e");
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => home()),
        );
        return false;
      },
      child: Scaffold(
        backgroundColor: Color(0xFFFAFAFA),
        body: Column(
          children: [
            // Header
            Container(
              padding: EdgeInsets.only(
                top: MediaQuery.of(context).padding.top + 8,
                left: 16,
                right: 16,
                bottom: 16,
              ),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                  bottom: BorderSide(color: Color(0xFFE8E8E8), width: 1),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Color(0xFFF0F5FF),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                    ),
                    child: IconButton(
                      onPressed: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) => home()),
                        );
                      },
                      icon: Icon(Icons.arrow_back_ios_new_rounded,
                          size: 16, color: Color(0xFF667EEA)),
                      padding: EdgeInsets.zero,
                    ),
                  ),
                  SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          groupName,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF1E293B),
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          "${messages.length} messages",
                          style: TextStyle(
                            fontSize: 13,
                            color: Color(0xFF64748B),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: Color(0xFFF0F5FF),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                    ),
                    child: Icon(
                      Icons.group_outlined,
                      size: 22,
                      color: Color(0xFF667EEA),
                    ),
                  ),
                ],
              ),
            ),

            // Messages List
            Expanded(
              child: messages.isEmpty
                  ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        color: Color(0xFFF5F3FF),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Color(0xFFE9E0FF),
                          width: 1,
                        ),
                      ),
                      child: Icon(
                        Icons.chat_outlined,
                        size: 36,
                        color: Color(0xFF8B5CF6),
                      ),
                    ),
                    SizedBox(height: 20),
                    Text(
                      "No messages yet",
                      style: TextStyle(
                        fontSize: 16,
                        color: Color(0xFF1E293B),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      "Start the conversation",
                      style: TextStyle(
                        fontSize: 14,
                        color: Color(0xFF64748B),
                      ),
                    ),
                  ],
                ),
              )
                  : ListView.builder(
                controller: _scrollController,
                padding: EdgeInsets.all(16),
                itemCount: messages.length,
                itemBuilder: (context, index) {
                  final message = messages[index];
                  return _buildMessageBubble(message);
                },
              ),
            ),

            // Message Input
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                  top: BorderSide(color: Color(0xFFE8E8E8), width: 1),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 4,
                    offset: Offset(0, -2),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(25),
                        border: Border.all(color: Color(0xFFF1F5F9), width: 1),
                      ),
                      child: TextField(
                        controller: _messageController,
                        decoration: InputDecoration(
                          hintText: "Type a message...",
                          hintStyle: TextStyle(
                            color: Color(0xFF94A3B8),
                            fontSize: 14,
                          ),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical: 12,
                          ),
                        ),
                        style: TextStyle(
                          fontSize: 14,
                          color: Color(0xFF1E293B),
                        ),
                        onSubmitted: (_) => _sendMessage(),
                      ),
                    ),
                  ),
                  SizedBox(width: 12),
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Color(0xFF667EEA),
                          Color(0xFF764BA2),
                        ],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xFF667EEA).withOpacity(0.25),
                          blurRadius: 8,
                          offset: Offset(0, 4),
                        ),
                      ],
                    ),
                    child: IconButton(
                      onPressed: _sendMessage,
                      icon: Icon(
                        Icons.send_rounded,
                        color: Colors.white,
                        size: 20,
                      ),
                      padding: EdgeInsets.zero,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage message) {
    final isSender = message.messageType == "sender";

    return Container(
      margin: EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment:
        isSender ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isSender)
            Container(
              width: 32,
              height: 32,
              margin: EdgeInsets.only(right: 8),
              decoration: BoxDecoration(
                color: Color(0xFFF0F5FF),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Color(0xFFE0E7FF), width: 1),
              ),
              child: Icon(
                Icons.person_outlined,
                size: 16,
                color: Color(0xFF667EEA),
              ),
            ),
          Expanded(
            child: Column(
              crossAxisAlignment:
              isSender ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                if (!isSender)
                  Padding(
                    padding: EdgeInsets.only(left: 8, bottom: 4),
                    child: Text(
                      message.senderName,
                      style: TextStyle(
                        fontSize: 12,
                        color: Color(0xFF64748B),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                Container(
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.of(context).size.width * 0.75,
                  ),
                  child: Column(
                    crossAxisAlignment: isSender
                        ? CrossAxisAlignment.end
                        : CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: isSender
                              ? Color(0xFF667EEA)
                              : Colors.white,
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(14),
                            topRight: Radius.circular(14),
                            bottomLeft:
                            isSender ? Radius.circular(14) : Radius.circular(4),
                            bottomRight:
                            isSender ? Radius.circular(4) : Radius.circular(14),
                          ),
                          border: Border.all(
                            color: isSender
                                ? Color(0xFF667EEA)
                                : Color(0xFFE2E8F0),
                            width: 1,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 6,
                              offset: Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Text(
                          message.messageContent,
                          style: TextStyle(
                            fontSize: 14,
                            color: isSender ? Colors.white : Color(0xFF1E293B),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                          top: 4,
                          left: isSender ? 0 : 8,
                          right: isSender ? 8 : 0,
                        ),
                        child: Text(
                          message.date,
                          style: TextStyle(
                            fontSize: 10,
                            color: Color(0xFF94A3B8),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}








// import 'dart:async';
// import 'dart:convert';
// import 'package:college_connect/student/studenthome.dart';
// import 'package:http/http.dart' as http;
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
//
// void main() {
//   runApp(const MyChatApp());
// }
//
// class MyChatApp extends StatelessWidget {
//   const MyChatApp({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Flutter Demo',
//       theme: ThemeData(
//
//         primarySwatch: Colors.blue,
//       ),
//       home: const MyChatPage(title: 'Flutter Demo Home Page'),
//     );
//   }
// }
//
// class MyChatPage extends StatefulWidget {
//   const MyChatPage({super.key, required this.title});
//
//
//
//   final String title;
//
//   @override
//   State<MyChatPage> createState() => _MyChatPageState();
// }
//
// class ChatMessage {
//   String messageContent;
//   String messageType;
//
//   ChatMessage({required this.messageContent, required this.messageType});
// }
//
// class _MyChatPageState extends State<MyChatPage> {
//   int _counter = 0;
//   String name = "";
//   bool _isD = false;
//
//   @override
//   void dispose() {
//     // TODO: implement dispose
//     _isD = true;
//     super.dispose();
//   }
//   _MyChatPageState() {
//       Timer.periodic(Duration(seconds: 2), (_) {
//         if(_isD==false){
//         view_message();
//     }
//       });
//   }
//
//   List<ChatMessage> messages = [];
//
//   void _incrementCounter() {
//     setState(() {
//
//       _counter++;
//     });
//   }
//
//   TextEditingController te_message = TextEditingController();
//
//   List<String> from_id_ = <String>[];
//   List<String> to_id_ = <String>[];
//   List<String> message_ = <String>[];
//   List<String> date_ = <String>[];
//   List<String> type = <String>[];
//
//   Future<void> view_message() async {
//     final pref = await SharedPreferences.getInstance();
//     name = "Hello" ;pref.getString("name").toString();
//
//
//     List<String> from_id = <String>[];
//     List<String> to_id = <String>[];
//     List<String> message = <String>[];
//     List<String> date = <String>[];
//     List<String> type = <String>[];
//
//     try {
//       final pref = await SharedPreferences.getInstance();
//       String urls = pref.getString('ip').toString();
//       String url = '$urls/user_viewchat';
//       print(pref.getString("lid").toString());
//       var data = await http.post(Uri.parse(url), body: {
//         'lid': pref.getString("lid").toString(),
//         'GROUP_id':pref.getString('GROUP_id'.toString()),
//         // 'to_id': pref.getString("did").toString()
//       });
//       var jsondata = json.decode(data.body);
//       String status = jsondata['status'];
//       print(status);
//
//       var arr = jsondata["data"];
//       print(arr);
//
//
//       messages.clear();
//
//
//       for (int i = 0; i < arr.length; i++) {
//         from_id.add(arr[i]['from'].toString());
//         to_id.add(arr[i]['to'].toString());
//         message.add(arr[i]['msg']);
//         date.add(arr[i]['date'].toString());
//         type.add(arr[i]['type'].toString());
//
//         if ("me" == arr[i]['type'].toString()) {
//           messages.add(ChatMessage(
//               messageContent: arr[i]['msg'], messageType: "sender"));
//         } else {
//           messages.add(ChatMessage(
//               messageContent: arr[i]['msg'], messageType: "receiver"));
//         }
//       }
//
//
//       setState(() {
//         from_id_ = from_id;
//         to_id_ = to_id;
//         message_ = message;
//         date_ = date;
//         // time_ = time;
//
//         messages = messages;
//       });
//
//       print(status);
//     } catch (e) {
//       print("Error ------------------- " + e.toString());
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//
//     return WillPopScope(
//       onWillPop: () async{
//         Navigator.push(context, MaterialPageRoute(builder: (context) => home(),));
//         return true;
//       },
//       child: Scaffold(
//         backgroundColor: Color.fromARGB(255, 228, 213, 231),
//
//         appBar: AppBar(
//             title: new Text(
//               name,
//               style: new TextStyle(color: Colors.white),
//             ),
//             leading: new IconButton(
//               icon: new Icon(Icons.arrow_back),
//               onPressed: () {
//                 Navigator.push(context, MaterialPageRoute(builder: (context) => home()));
//                 // print("Hello");
//
//               },
//             )),
//         body: Stack(
//           children: <Widget>[
//             ListView.builder(
//               itemCount: messages.length,
//               shrinkWrap: true,
//               padding: EdgeInsets.only(top: 10, bottom: 50),
//               physics: ScrollPhysics(),
//               itemBuilder: (context, index) {
//                 return Container(
//                   padding:
//                       EdgeInsets.only(left: 14, right: 14, top: 10, bottom: 10),
//                   child: Align(
//                     alignment: (messages[index].messageType == "receiver"
//                         ? Alignment.topLeft
//                         : Alignment.topRight),
//                     child: Container(
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(20),
//                         color: (messages[index].messageType == "receiver"
//                             ? Colors.grey.shade200
//                             : Colors.blue[200]),
//                       ),
//                       padding: EdgeInsets.all(16),
//                       child: Text(
//                         messages[index].messageContent,
//                         style: TextStyle(fontSize: 15),
//                       ),
//                     ),
//                   ),
//                 );
//               },
//             ),
//             Align(
//               alignment: Alignment.bottomLeft,
//               child: Container(
//                 padding: EdgeInsets.only(left: 10, bottom: 10, top: 10),
//                 height: 60,
//                 width: double.infinity,
//                 color: Colors.white,
//                 child: Row(
//                   children: <Widget>[
//                     GestureDetector(
//                       onTap: () {},
//                       child: Container(
//                         height: 30,
//                         width: 30,
//                         decoration: BoxDecoration(
//                           color: Colors.cyan,
//                           borderRadius: BorderRadius.circular(30),
//                         ),
//                         child: Icon(
//                           Icons.add,
//                           color: Colors.white,
//                           size: 20,
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       width: 15,
//                     ),
//                     Expanded(
//                       child: TextField(
//                         controller: te_message,
//                         decoration: InputDecoration(
//                             hintText: "Write message...",
//                             hintStyle: TextStyle(color: Colors.black54),
//                             border: InputBorder.none),
//                       ),
//                     ),
//                     SizedBox(
//                       width: 15,
//                     ),
//                     FloatingActionButton(
//                       onPressed: () async {
//                         String fid = "";
//                         String toid = "";
//                         String message = te_message.text.toString();
//
//                         /////
//                         try {
//                           final pref = await SharedPreferences.getInstance();
//                           String ip = pref.getString("ip").toString();
//
//                           String url = ip + "/user_sendchat";
//
//                           var data = await http.post(Uri.parse(url), body: {
//                             'message': message,
//                             'lid': pref.getString("lid").toString(),
//                             // 'to_id': pref.getString("did").toString()
//                             'GROUP_id':pref.getString('GROUP_id'.toString()),
//
//                           });
//                           var jsondata = json.decode(data.body);
//                           String status = jsondata['status'];
//
//                           te_message.text = "";
//
//                           var arr = jsondata["data"];
//
//                           setState(() {});
//
//                           print("");
//                         } catch (e) {
//                           print("Error ------------------- " + e.toString());
//                           //there is error during converting file image to base64 encoding.
//                         }
//                         ////
//
//                         // print("Hiiiiii");
//                         //
//                         // setState(() {
//                         //
//                         //   List<ChatMessage> messages1= messages;
//                         //   messages1.add(ChatMessage(messageContent: "Hello, Fadhil", messageType: "receiver"));
//                         //   setState(() {
//                         //
//                         //     messages=messages1;
//                         //   });
//                         //
//                         // });
//                       },
//                       child: Icon(
//                         Icons.send,
//                         color: Colors.white,
//                         size: 18,
//                       ),
//                       backgroundColor: Colors.cyan,
//                       elevation: 0,
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ],
//         ),
//
//         // This trailing comma makes auto-formatting nicer for build methods.
//       ),
//     );
//   }
// }
