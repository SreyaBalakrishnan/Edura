import 'dart:async';
import 'dart:convert';
import 'package:college_connect/student/studenthome.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const MyChatBotApp());
}

class MyChatBotApp extends StatelessWidget {
  const MyChatBotApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'College Connect Chatbot',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Color(0xFFF8FAFC),
        fontFamily: 'Inter',
      ),
      home: const MyChatPage(title: 'AI Assistant'),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyChatPage extends StatefulWidget {
  const MyChatPage({super.key, required this.title});

  final String title;

  @override
  State<MyChatPage> createState() => _MyChatPageState();
}

class ChatMessage {
  final String messageContent;
  final String messageType;
  final String date;

  ChatMessage({
    required this.messageContent,
    required this.messageType,
    required this.date,
  });
}

class _MyChatPageState extends State<MyChatPage> {
  bool _isDisposed = false;
  String name = "";

  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  List<ChatMessage> messages = [];
  Timer? _messageTimer;

  // Store variables
  List<String> id_ = <String>[];
  List<String> message_ = <String>[];
  List<String> date_ = <String>[];
  List<String> type_ = <String>[];

  @override
  void initState() {
    super.initState();
    _loadUserData();
    _startMessagePolling();
  }

  @override
  void dispose() {
    _isDisposed = true;
    _messageTimer?.cancel();
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _loadUserData() async {
    final pref = await SharedPreferences.getInstance();
    setState(() {
      name = pref.getString("name") ?? "Student";
    });
  }

  void _startMessagePolling() {
    _messageTimer = Timer.periodic(Duration(seconds: 3), (_) {
      if (!_isDisposed) {
        _viewMessages();
      }
    });
  }

  Future<void> _viewMessages() async {
    try {
      final pref = await SharedPreferences.getInstance();
      String urls = pref.getString('ip') ?? '';
      String url = '$urls/user_viewchatbot';

      print("Fetching chatbot messages...");

      var response = await http.post(Uri.parse(url), body: {
        'sid': pref.getString("sid") ?? '',
      });

      var jsondata = json.decode(response.body);
      String status = jsondata['status'];

      if (status == 'success') {
        var arr = jsondata["data"];

        List<ChatMessage> newMessages = [];
        List<String> id = [];
        List<String> message = [];
        List<String> date = [];
        List<String> type = [];

        for (int i = 0; i < arr.length; i++) {
          id.add(arr[i]['id'].toString());
          message.add(arr[i]['msg']);
          date.add(arr[i]['date'].toString());
          type.add(arr[i]['type'].toString());

          if ("me" == arr[i]['type'].toString()) {
            newMessages.add(ChatMessage(
              messageContent: arr[i]['msg'],
              messageType: "sender",
              date: arr[i]['date'].toString(),
            ));
          } else {
            newMessages.add(ChatMessage(
              messageContent: arr[i]['msg'],
              messageType: "receiver",
              date: arr[i]['date'].toString(),
            ));
          }
        }

        if (!_isDisposed) {
          setState(() {
            messages = newMessages;
            id_ = id;
            message_ = message;
            date_ = date;
            type_ = type;
          });
          _scrollToBottom();
        }
      }
    } catch (e) {
      print("Error fetching messages: $e");
    }
  }

  Future<void> _sendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty) return;

    try {
      final pref = await SharedPreferences.getInstance();
      String ip = pref.getString("ip") ?? '';
      String url = ip + "/user_sendchatbot";

      var response = await http.post(Uri.parse(url), body: {
        'message': message,
        'sid': pref.getString("sid") ?? '',
      });

      var jsondata = json.decode(response.body);
      if (jsondata['status'] == 'success') {
        _messageController.clear();
        await _viewMessages(); // Refresh messages
      }
    } catch (e) {
      print("Error sending message: $e");
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => home()),
        );
        return false;
      },
      child: Scaffold(
        backgroundColor: Color(0xFFF8FAFC),
        body: Column(
          children: [
            // Elegant Header
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFF667EEA),
                    Color(0xFF764BA2),
                  ],
                ),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(24),
                  bottomRight: Radius.circular(24),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 20,
                    offset: Offset(0, 10),
                  ),
                ],
              ),
              child: SafeArea(
                bottom: false,
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          GestureDetector(
                            onTap: () {
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(builder: (context) => home()),
                              );
                            },
                            child: Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Icon(
                                Icons.arrow_back_ios_new_rounded,
                                color: Colors.white,
                                size: 18,
                              ),
                            ),
                          ),
                          SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "AI Assistant",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: -0.5,
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  "Ask me anything about college",
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.9),
                                    fontSize: 14,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(15),
                              border: Border.all(
                                color: Colors.white.withOpacity(0.3),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              Icons.smart_toy_outlined,
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 20),
                      // Quick suggestions
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: [
                            _buildSuggestionChip("Academic Calendar"),
                            SizedBox(width: 8),
                            _buildSuggestionChip("Exam Schedule"),
                            SizedBox(width: 8),
                            _buildSuggestionChip("Library Hours"),
                            SizedBox(width: 8),
                            _buildSuggestionChip("Campus Events"),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            // Messages List
            Expanded(
              child: messages.isEmpty
                  ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(40.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 120,
                        height: 120,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Color(0xFF667EEA).withOpacity(0.1),
                              Color(0xFF764BA2).withOpacity(0.1),
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(
                            color: Colors.white,
                            width: 3,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 20,
                              offset: Offset(0, 10),
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.smart_toy_outlined,
                          size: 50,
                          color: Color(0xFF667EEA),
                        ),
                      ),
                      SizedBox(height: 24),
                      Text(
                        "Start a Conversation",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1E293B),
                          letterSpacing: -0.5,
                        ),
                      ),
                      SizedBox(height: 12),
                      Text(
                        "Ask me about academics, events,\nor campus life",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 15,
                          color: Color(0xFF64748B),
                          height: 1.5,
                        ),
                      ),
                      SizedBox(height: 24),
                      Wrap(
                        spacing: 12,
                        runSpacing: 12,
                        children: [
                          _buildQuickQuestion("When's the next event?"),
                          _buildQuickQuestion("Library opening time?"),
                          _buildQuickQuestion("Exam schedule?"),
                          _buildQuickQuestion("Contact faculty?"),
                        ],
                      ),
                    ],
                  ),
                ),
              )
                  : ListView.builder(
                controller: _scrollController,
                padding: EdgeInsets.all(16),
                physics: BouncingScrollPhysics(),
                itemCount: messages.length,
                itemBuilder: (context, index) {
                  final message = messages[index];
                  return _buildMessageBubble(message);
                },
              ),
            ),

            // Modern Message Input
            Container(
              padding: EdgeInsets.fromLTRB(20, 16, 20, 24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 20,
                    offset: Offset(0, -5),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: Color(0xFFE2E8F0),
                          width: 1.5,
                        ),
                      ),
                      child: Row(
                        children: [
                          SizedBox(width: 16),
                          Expanded(
                            child: TextField(
                              controller: _messageController,
                              style: TextStyle(
                                fontSize: 15,
                                color: Color(0xFF1E293B),
                                fontWeight: FontWeight.w500,
                              ),
                              decoration: InputDecoration(
                                hintText: "Type your question...",
                                hintStyle: TextStyle(
                                  color: Color(0xFF94A3B8),
                                  fontSize: 15,
                                  fontWeight: FontWeight.w400,
                                ),
                                border: InputBorder.none,
                                contentPadding: EdgeInsets.symmetric(vertical: 14),
                              ),
                              maxLines: 3,
                              minLines: 1,
                              onSubmitted: (_) => _sendMessage(),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(right: 12),
                            child: IconButton(
                              onPressed: () {
                                // Add attachment functionality
                              },
                              icon: Icon(
                                Icons.attach_file_outlined,
                                color: Color(0xFF94A3B8),
                                size: 22,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(width: 12),
                  Container(
                    width: 54,
                    height: 54,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Color(0xFF667EEA),
                          Color(0xFF764BA2),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(18),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xFF667EEA).withOpacity(0.3),
                          blurRadius: 15,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(18),
                        onTap: _sendMessage,
                        child: Center(
                          child: Icon(
                            Icons.send_rounded,
                            color: Colors.white,
                            size: 22,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSuggestionChip(String text) {
    return GestureDetector(
      onTap: () {
        _messageController.text = text;
        _sendMessage();
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.2),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: Colors.white.withOpacity(0.3),
            width: 1,
          ),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: Colors.white,
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Widget _buildQuickQuestion(String text) {
    return GestureDetector(
      onTap: () {
        _messageController.text = text;
        _sendMessage();
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Color(0xFFE2E8F0),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.03),
              blurRadius: 10,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Text(
          text,
          style: TextStyle(
            color: Color(0xFF475569),
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage message) {
    final isSender = message.messageType == "sender";

    return Container(
      margin: EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment:
        isSender ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isSender)
            Container(
              width: 36,
              height: 36,
              margin: EdgeInsets.only(right: 8, top: 4),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF667EEA),
                    Color(0xFF764BA2),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Color(0xFF667EEA).withOpacity(0.2),
                    blurRadius: 8,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: Center(
                child: Icon(
                  Icons.smart_toy_outlined,
                  color: Colors.white,
                  size: 18,
                ),
              ),
            ),
          Expanded(
            child: Column(
              crossAxisAlignment:
              isSender ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                // Message bubble
                Container(
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.of(context).size.width * 0.75,
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      topLeft: isSender ? Radius.circular(18) : Radius.circular(4),
                      topRight: isSender ? Radius.circular(4) : Radius.circular(18),
                      bottomLeft: Radius.circular(18),
                      bottomRight: Radius.circular(18),
                    ),
                    gradient: isSender
                        ? LinearGradient(
                      colors: [
                        Color(0xFF667EEA),
                        Color(0xFF764BA2),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                        : null,
                    color: isSender ? null : Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.08),
                        blurRadius: 15,
                        offset: Offset(0, 5),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (!isSender)
                          Padding(
                            padding: EdgeInsets.only(bottom: 6),
                            child: Text(
                              "AI Assistant",
                              style: TextStyle(
                                color: Color(0xFF764BA2),
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        Text(
                          message.messageContent,
                          style: TextStyle(
                            fontSize: 15,
                            color: isSender ? Colors.white : Color(0xFF1E293B),
                            height: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                // Timestamp
                Padding(
                  padding: EdgeInsets.only(
                    top: 6,
                    left: isSender ? 0 : 12,
                    right: isSender ? 12 : 0,
                  ),
                  child: Text(
                    message.date,
                    style: TextStyle(
                      fontSize: 11,
                      color: Color(0xFF94A3B8),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (isSender)
            Container(
              width: 36,
              height: 36,
              margin: EdgeInsets.only(left: 8, top: 4),
              decoration: BoxDecoration(
                color: Color(0xFFF1F5F9),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Color(0xFFE2E8F0),
                  width: 1.5,
                ),
              ),
              child: Center(
                child: Icon(
                  Icons.person_outline,
                  color: Color(0xFF475569),
                  size: 18,
                ),
              ),
            ),
        ],
      ),
    );
  }
}








// import 'dart:async';
// import 'dart:convert';
// import 'package:college_connect/student/studenthome.dart';
// import 'package:http/http.dart' as http;
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
//
// void main() {
//   runApp(const MyChatBotApp());
// }
//
// class MyChatBotApp extends StatelessWidget {
//   const MyChatBotApp({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Chatbot',
//       theme: ThemeData(
//
//         primarySwatch: Colors.blue,
//       ),
//       home: const MyChatPage(title: 'Chatbot'),
//     );
//   }
// }
//
// class MyChatPage extends StatefulWidget {
//   const MyChatPage({super.key, required this.title});
//
//
//
//   final String title;
//
//   @override
//   State<MyChatPage> createState() => _MyChatPageState();
// }
//
// class ChatMessage {
//   String messageContent;
//   String messageType;
//
//   ChatMessage({required this.messageContent, required this.messageType});
// }
//
// class _MyChatPageState extends State<MyChatPage> {
//   int _counter = 0;
//   String name = "";
//   bool _isD = false;
//
//   @override
//   void dispose() {
//     // TODO: implement dispose
//     _isD = true;
//     super.dispose();
//   }
//   _MyChatPageState() {
//     Timer.periodic(Duration(seconds: 2), (_) {
//       if(_isD==false){
//         view_message();
//       }
//     });
//   }
//
//   List<ChatMessage> messages = [];
//
//   void _incrementCounter() {
//     setState(() {
//
//       _counter++;
//     });
//   }
//
//   TextEditingController te_message = TextEditingController();
//   List<String> id_ = <String>[];
//   List<String> message_ = <String>[];
//   List<String> date_ = <String>[];
//   List<String> type_ = <String>[];
//
//   Future<void> view_message() async {
//     final pref = await SharedPreferences.getInstance();
//     name = "Hello" ;
//
//
//     List<String> id = <String>[];
//     List<String> message = <String>[];
//     List<String> date = <String>[];
//     List<String> type = <String>[];
//
//     try {
//       final pref = await SharedPreferences.getInstance();
//       String urls = pref.getString('ip').toString();
//       String url = '$urls/user_viewchatbot';
//       print(pref.getString("sid").toString());
//       var data = await http.post(Uri.parse(url), body: {
//         'sid': pref.getString("sid").toString(),
//       });
//       var jsondata = json.decode(data.body);
//       String status = jsondata['status'];
//       print(status);
//
//       var arr = jsondata["data"];
//       print(arr);
//
//
//       messages.clear();
//
//
//       for (int i = 0; i < arr.length; i++) {
//         id.add(arr[i]['id'].toString());
//         message.add(arr[i]['msg']);
//         date.add(arr[i]['date'].toString());
//         type.add(arr[i]['type'].toString());
//
//         if ("me" == arr[i]['type'].toString()) {
//           messages.add(ChatMessage(
//               messageContent: arr[i]['msg'], messageType: "sender"));
//         } else {
//           messages.add(ChatMessage(
//               messageContent: arr[i]['msg'], messageType: "receiver"));
//         }
//       }
//
//
//       setState(() {
//         id_ = id;
//         message_ = message;
//         date_ = date;
//         messages = messages;
//       });
//
//       print(status);
//     } catch (e) {
//       print("Error ------------------- " + e.toString());
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//
//     return WillPopScope(
//       onWillPop: () async{
//         Navigator.push(context, MaterialPageRoute(builder: (context) => home(),));
//         return true;
//       },
//       child: Scaffold(
//         backgroundColor: Color.fromARGB(255, 228, 213, 231),
//
//         appBar: AppBar(
//             title: new Text(
//               name,
//               style: new TextStyle(color: Colors.white),
//             ),
//             leading: new IconButton(
//               icon: new Icon(Icons.arrow_back),
//               onPressed: () {
//                 Navigator.push(context, MaterialPageRoute(builder: (context) => home()));
//                 // print("Hello");
//
//               },
//             )),
//         body: Stack(
//           children: <Widget>[
//             ListView.builder(
//               itemCount: messages.length,
//               shrinkWrap: true,
//               padding: EdgeInsets.only(top: 10, bottom: 50),
//               physics: ScrollPhysics(),
//               itemBuilder: (context, index) {
//                 return Container(
//                   padding:
//                   EdgeInsets.only(left: 14, right: 14, top: 10, bottom: 10),
//                   child: Align(
//                     alignment: (messages[index].messageType == "receiver"
//                         ? Alignment.topLeft
//                         : Alignment.topRight),
//                     child: Container(
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(20),
//                         color: (messages[index].messageType == "receiver"
//                             ? Colors.grey.shade200
//                             : Colors.blue[200]),
//                       ),
//                       padding: EdgeInsets.all(16),
//                       child: Text(
//                         messages[index].messageContent,
//                         style: TextStyle(fontSize: 15),
//                       ),
//                     ),
//                   ),
//                 );
//               },
//             ),
//             Align(
//               alignment: Alignment.bottomLeft,
//               child: Container(
//                 padding: EdgeInsets.only(left: 10, bottom: 10, top: 10),
//                 height: 60,
//                 width: double.infinity,
//                 color: Colors.white,
//                 child: Row(
//                   children: <Widget>[
//                     GestureDetector(
//                       onTap: () {},
//                       child: Container(
//                         height: 30,
//                         width: 30,
//                         decoration: BoxDecoration(
//                           color: Colors.cyan,
//                           borderRadius: BorderRadius.circular(30),
//                         ),
//                         child: Icon(
//                           Icons.add,
//                           color: Colors.white,
//                           size: 20,
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       width: 15,
//                     ),
//                     Expanded(
//                       child: TextField(
//                         controller: te_message,
//                         decoration: InputDecoration(
//                             hintText: "Write message...",
//                             hintStyle: TextStyle(color: Colors.black54),
//                             border: InputBorder.none),
//                       ),
//                     ),
//                     SizedBox(
//                       width: 15,
//                     ),
//                     FloatingActionButton(
//                       onPressed: () async {
//                         String fid = "";
//                         String toid = "";
//                         String message = te_message.text.toString();
//
//                         /////
//                         try {
//                           final pref = await SharedPreferences.getInstance();
//                           String ip = pref.getString("ip").toString();
//
//                           String url = ip + "/user_sendchatbot";
//
//                           var data = await http.post(Uri.parse(url), body: {
//                             'message': message,
//                             'sid': pref.getString("sid").toString(),
//
//                           });
//                           var jsondata = json.decode(data.body);
//                           String status = jsondata['status'];
//
//                           te_message.text = "";
//
//
//                           setState(() {});
//
//                           print("");
//                         } catch (e) {
//                           print("Error ------------------- " + e.toString());
//                           //there is error during converting file image to base64 encoding.
//                         }
//                         ////
//
//                         // print("Hiiiiii");
//                         //
//                         // setState(() {
//                         //
//                         //   List<ChatMessage> messages1= messages;
//                         //   messages1.add(ChatMessage(messageContent: "Hello, Fadhil", messageType: "receiver"));
//                         //   setState(() {
//                         //
//                         //     messages=messages1;
//                         //   });
//                         //
//                         // });
//                       },
//                       child: Icon(
//                         Icons.send,
//                         color: Colors.white,
//                         size: 18,
//                       ),
//                       backgroundColor: Colors.cyan,
//                       elevation: 0,
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ],
//         ),
//
//         // This trailing comma makes auto-formatting nicer for build methods.
//       ),
//     );
//   }
// }
