import 'dart:convert';
import 'package:college_connect/student/studenthome.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class view_materials extends StatelessWidget {
  const view_materials({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: view_materials_sub(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class view_materials_sub extends StatefulWidget {
  const view_materials_sub({Key? key}) : super(key: key);

  @override
  State<view_materials_sub> createState() => view_materials_sub_State();
}

class view_materials_sub_State extends State<view_materials_sub> {
  late Future<List<MaterialItem>> _materialsFuture;
  List<MaterialItem> _allMaterials = [];
  List<MaterialItem> _filteredMaterials = [];
  final TextEditingController _searchController = TextEditingController();
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _materialsFuture = _fetchMaterials();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<List<MaterialItem>> _fetchMaterials() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String b = prefs.getString("uid").toString();
      var data = await http.post(
        Uri.parse(prefs.getString("ip").toString() + "/view_materials"),
        body: {"id": b},
      );

      var jsonData = json.decode(data.body);
      List<MaterialItem> materials = [];

      for (var item in jsonData["data"]) {
        MaterialItem newMaterial = MaterialItem(
          item["id"].toString(),
          item["subject"].toString(),
          item["title"].toString(),
          prefs.getString("ip").toString() + item["file"].toString(),
          item["date"].toString(),
        );
        materials.add(newMaterial);
      }

      setState(() {
        _allMaterials = materials;
        _filteredMaterials = materials;
        _isLoading = false;
      });

      return materials;
    } catch (e) {
      print("Error fetching materials: $e");
      setState(() {
        _isLoading = false;
      });
      return [];
    }
  }

  void _onSearchChanged() {
    setState(() {
      final query = _searchController.text.trim().toLowerCase();
      if (query.isEmpty) {
        _filteredMaterials = _allMaterials;
      } else {
        _filteredMaterials = _allMaterials.where((material) {
          return material.subject.toLowerCase().contains(query) ||
              material.title.toLowerCase().contains(query);
        }).toList();
      }
    });
  }

  Future<void> _refreshMaterials() async {
    setState(() {
      _isLoading = true;
      _materialsFuture = _fetchMaterials();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFAFAFA),
      body: SafeArea(
        child: Column(
          children: [
            // Clean Minimal Header
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                  bottom: BorderSide(color: Color(0xFFE8E8E8), width: 1),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: IconButton(
                          onPressed: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (context) => home()),
                            );
                          },
                          icon: Icon(Icons.arrow_back_ios_new_rounded,
                              size: 16, color: Color(0xFF667EEA)),
                          padding: EdgeInsets.zero,
                        ),
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Study Materials",
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF1E293B),
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              _isLoading
                                  ? "Loading..."
                                  : "${_filteredMaterials.length} materials available",
                              style: TextStyle(
                                fontSize: 13,
                                color: Color(0xFF64748B),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: Icon(
                          Icons.menu_book_outlined,
                          size: 22,
                          color: Color(0xFF667EEA),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 16),

                  // Search Bar
                  Container(
                    height: 44,
                    decoration: BoxDecoration(
                      color: Color(0xFFF8FAFC),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                    ),
                    child: Row(
                      children: [
                        SizedBox(width: 16),
                        Icon(
                          Icons.search_rounded,
                          color: Color(0xFF64748B),
                          size: 20,
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: _searchController,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: "Search by subject or title...",
                              hintStyle: TextStyle(
                                color: Color(0xFF94A3B8),
                                fontSize: 14,
                              ),
                            ),
                            style: TextStyle(
                              color: Color(0xFF2D3748),
                              fontSize: 14,
                            ),
                            cursorColor: Color(0xFF667EEA),
                          ),
                        ),
                        if (_searchController.text.isNotEmpty)
                          IconButton(
                            onPressed: () {
                              _searchController.clear();
                            },
                            icon: Icon(Icons.clear_rounded, color: Color(0xFF64748B), size: 18),
                            splashRadius: 20,
                          ),
                        SizedBox(width: 8),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Materials List
            Expanded(
              child: FutureBuilder<List<MaterialItem>>(
                future: _materialsFuture,
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (_isLoading) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 28,
                            height: 28,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFF7C3AED),
                            ),
                          ),
                          SizedBox(height: 16),
                          Text(
                            "Loading Materials...",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    );
                  }

                  if (snapshot.hasError) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              Icons.error_outline_rounded,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            "Error Loading Materials",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            "Please check your connection",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          SizedBox(height: 16),
                          TextButton(
                            onPressed: _refreshMaterials,
                            style: TextButton.styleFrom(
                              foregroundColor: Color(0xFF667EEA),
                            ),
                            child: Text("Retry"),
                          ),
                        ],
                      ),
                    );
                  }

                  if (_filteredMaterials.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              _searchController.text.isNotEmpty
                                  ? Icons.search_off_rounded
                                  : Icons.folder_open_outlined,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            _searchController.text.isNotEmpty
                                ? "No matching materials found"
                                : "No Materials Available",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            _searchController.text.isNotEmpty
                                ? "Try different search terms"
                                : "Materials will appear here once uploaded",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          if (_searchController.text.isNotEmpty)
                            Padding(
                              padding: EdgeInsets.only(top: 16),
                              child: TextButton(
                                onPressed: () {
                                  _searchController.clear();
                                },
                                style: TextButton.styleFrom(
                                  foregroundColor: Color(0xFF667EEA),
                                ),
                                child: Text("Clear Search"),
                              ),
                            ),
                        ],
                      ),
                    );
                  }

                  return ListView.builder(
                    padding: EdgeInsets.all(16),
                    itemCount: _filteredMaterials.length,
                    itemBuilder: (BuildContext context, int index) {
                      var material = _filteredMaterials[index];
                      return _buildMaterialCard(material);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMaterialCard(MaterialItem material) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Color(0xFFE8E8E8), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Material Header
          Padding(
            padding: EdgeInsets.all(20),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    color: Color(0xFFF5F3FF),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Color(0xFFE9E0FF), width: 2),
                  ),
                  child: Icon(
                    Icons.description_outlined,
                    size: 32,
                    color: Color(0xFF8B5CF6),
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        material.subject,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                      SizedBox(height: 6),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Color(0xFFF5F3FF),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: Color(0xFFE9E0FF), width: 1),
                        ),
                        child: Text(
                          "Study Material",
                          style: TextStyle(
                            fontSize: 13,
                            color: Color(0xFF7C3AED),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(
                            Icons.title_rounded,
                            size: 14,
                            color: Color(0xFF94A3B8),
                          ),
                          SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              material.title,
                              style: TextStyle(
                                fontSize: 13,
                                color: Color(0xFF64748B),
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Material Details
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ID Badge
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Color(0xFFF8FAFC),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Color(0xFFF1F5F9)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.numbers_outlined,
                        size: 12,
                        color: Color(0xFF64748B),
                      ),
                      SizedBox(width: 6),
                      Text(
                        "ID: ${material.id}",
                        style: TextStyle(
                          fontSize: 11,
                          color: Color(0xFF64748B),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 20),

                // Material Details
                _buildDetailRow(Icons.menu_book_outlined, "Subject", material.subject),
                SizedBox(height: 12),
                _buildDetailRow(Icons.calendar_today_outlined, "Upload Date", material.date),

                SizedBox(height: 24),

                // View Material Button
                Container(
                  width: double.infinity,
                  height: 46,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Color(0xFF667EEA), width: 1.5),
                  ),
                  child: Material(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(10),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(10),
                      onTap: () async {
                        final String ipfsUrl = material.file.toString();
                        final Uri uri = Uri.parse(ipfsUrl);

                        if (await canLaunchUrl(uri)) {
                          await launchUrl(uri, mode: LaunchMode.externalApplication);
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Could not open the file'),
                              backgroundColor: Colors.red,
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          );
                        }
                      },
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.visibility_outlined,
                              size: 16,
                              color: Color(0xFF667EEA),
                            ),
                            SizedBox(width: 10),
                            Text(
                              'View Material',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF667EEA),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),

                SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    "Click to open in browser",
                    style: TextStyle(
                      fontSize: 11,
                      color: Color(0xFF94A3B8),
                    ),
                  ),
                ),
                SizedBox(height: 16),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Color(0xFFF1F5F9)),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: Color(0xFFF5F3FF),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: Color(0xFFE9E0FF)),
            ),
            child: Icon(
              icon,
              size: 16,
              color: Color(0xFF8B5CF6),
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF1E293B),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class MaterialItem {
  final String id;
  final String subject;
  final String title;
  final String file;
  final String date;

  MaterialItem(this.id, this.subject, this.title, this.file, this.date);
}







// import 'dart:convert';
//
// import 'package:college_connect/student/studenthome.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart'as http;
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:url_launcher/url_launcher.dart';
//
// class view_materials extends StatelessWidget {
// const view_materials({Key? key}) : super(key: key);
//
// @override
// Widget build(BuildContext context) {
// return MaterialApp(home: view_materials_sub(),);
// }
// }
//
// class view_materials_sub extends StatefulWidget {
// const view_materials_sub({Key? key}) : super(key: key);
//
// @override
// State<view_materials_sub> createState() => view_materials_sub_State();
// }
//
// class view_materials_sub_State extends State<view_materials_sub> {
//   Future<List<Joke>> _getJokes() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     String b = prefs.getString("uid").toString();
//     String foodimage="";
//     var data =
//     await http.post(Uri.parse(prefs.getString("ip").toString()+"/view_materials"),
//         body: {"id":b}
//     );
//
//     var jsonData = json.decode(data.body);
// //    print(jsonData);
//     List<Joke> jokes = [];
//     for (var joke in jsonData["data"]) {
//       print(joke);
//       Joke newJoke = Joke(
//           joke["id"].toString(),
//           joke["subject"].toString(),
//           joke["title"].toString(),
//           prefs.getString("ip").toString()+joke["file"].toString(),
//           joke["date"].toString()
//       );
//       jokes.add(newJoke);
//     }
//     return jokes;
//   }
//
//   @override
// Widget build(BuildContext context) {
// return Scaffold(
//   appBar: AppBar(title: Text("Materials"),centerTitle: true,leading: IconButton(onPressed: (){
//     Navigator.push(context, MaterialPageRoute(builder: (context)=>home()));
//   }, icon: Icon(Icons.arrow_back)),),
//   body:
//
//
//   Container(
//
//     child:
//     FutureBuilder(
//       future: _getJokes(),
//       builder: (BuildContext context, AsyncSnapshot snapshot) {
// //              print("snapshot"+snapshot.toString());
//         if (snapshot.data == null) {
//           return Container(
//             child: Center(
//               child: Text("Loading..."),
//             ),
//           );
//         } else {
//           return ListView.builder(
//             itemCount: snapshot.data.length,
//             itemBuilder: (BuildContext context, int index) {
//               var i = snapshot.data![index];
//               return Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: Card(
//                   elevation: 3,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(10),
//                     side: BorderSide(color: Colors.grey.shade300),
//                   ),
//                   child: Padding(
//                     padding: const EdgeInsets.all(16.0),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//
//                         SizedBox(height: 10),
//                         _buildRow("Id:", i.id.toString()),
//                         _buildRow("Subject Name:", i.subject.toString()),
//                         _buildRow("Title:", i.title.toString()),
//                         _buildRow("Date:", i.date.toString()),
//                         SizedBox(height: 10),
//                         ElevatedButton(onPressed: () async {
//                           final String ipfsUrl = i.file.toString();
//
// // ✅ Convert the string to a Uri object (required by url_launcher)
//                           final Uri uri = Uri.parse(ipfsUrl);
//
// // 🔍 Check if the URL can be launched
//                           if (await canLaunchUrl(uri)) {
//                             // 🚀 Launch the URL in an external application (e.g., browser, PDF viewer)
//                             await launchUrl(uri, mode: LaunchMode.externalApplication);
//                           } else {
//                             // ⚠ Handle the error gracefully (you can also show a toast/snackbar)
//                             throw '❌ Could not launch $ipfsUrl';
//                           }
//                         }, child: Text("view"))
//
//                       ],
//                     ),
//                   ),
//                 ),
//               );
//             },
//           );
//
//
//         }
//       },
//
//
//     ),
//
//
//
//
//
//   ),
// );
// }
// }
// Widget _buildRow(String label, String value) {
//   return Padding(
//     padding: const EdgeInsets.symmetric(vertical: 4),
//     child: Row(
//       children: [
//         SizedBox(
//           width: 100,
//           child: Text(
//             label,
//             style: TextStyle(
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//         ),
//         SizedBox(width: 5),
//         Flexible(
//           child: Text(
//             value,
//             style: TextStyle(
//               color: Colors.grey.shade800,
//             ),
//           ),
//         ),
//       ],
//     ),
//   );
// }
//
// class Joke {
//   final String id;
//   final String subject;
//   final String title;
//   final String file;
//   final String date;
//
//
//
//
//   Joke(this.id,this.subject, this.title,this.file,this.date);
// //  print("hiiiii");
// }
