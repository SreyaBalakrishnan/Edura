import 'dart:convert';
import 'package:college_connect/student/sent_feedback.dart';
import 'package:college_connect/student/studenthome.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class view_faculty extends StatelessWidget {
  const view_faculty({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: view_faculty_sub(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class view_faculty_sub extends StatefulWidget {
  const view_faculty_sub({Key? key}) : super(key: key);

  @override
  State<view_faculty_sub> createState() => view_faculty_sub_State();
}

class view_faculty_sub_State extends State<view_faculty_sub> {
  late Future<List<Faculty>> _facultyFuture;
  List<Faculty> _allFaculty = [];
  List<Faculty> _filteredFaculty = [];
  List<String> _departments = ["All"];
  String _selectedDepartment = "All";
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _facultyFuture = _fetchFaculty();
  }

  Future<List<Faculty>> _fetchFaculty() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String b = prefs.getString("uid").toString();
      var data = await http.post(
        Uri.parse(prefs.getString("ip").toString() + "/view_faculty"),
        body: {"id": b},
      );

      var jsonData = json.decode(data.body);
      List<Faculty> facultyList = [];
      Set<String> departmentSet = Set();

      for (var faculty in jsonData["data"]) {
        Faculty newFaculty = Faculty(
          prefs.getString("ip").toString() + faculty["profile_pic"].toString(),
          faculty["id"].toString(),
          faculty["name"].toString(),
          faculty["department"].toString(),
          faculty["designation"].toString(),
          faculty["number"].toString(),
          faculty["email"].toString(),
        );
        facultyList.add(newFaculty);
        if (faculty["department"].toString().isNotEmpty) {
          departmentSet.add(faculty["department"].toString());
        }
      }

      // Sort departments alphabetically
      List<String> sortedDepartments = departmentSet.toList()..sort();

      setState(() {
        _allFaculty = facultyList;
        _filteredFaculty = facultyList;
        _departments = ["All"] + sortedDepartments;
        _isLoading = false;
      });

      return facultyList;
    } catch (e) {
      print("Error fetching faculty: $e");
      setState(() {
        _isLoading = false;
      });
      return [];
    }
  }

  void _filterByDepartment(String department) {
    setState(() {
      _selectedDepartment = department;
      if (department == "All") {
        _filteredFaculty = _allFaculty;
      } else {
        _filteredFaculty = _allFaculty
            .where((faculty) => faculty.department == department)
            .toList();
      }
    });
  }

  Future<void> _refreshFaculty() async {
    setState(() {
      _isLoading = true;
      _facultyFuture = _fetchFaculty();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFAFAFA),
      body: SafeArea(
        child: Column(
          children: [
            // Clean Minimal Header
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                  bottom: BorderSide(color: Color(0xFFE8E8E8), width: 1),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: IconButton(
                          onPressed: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (context) => home()),
                            );
                          },
                          icon: Icon(Icons.arrow_back_ios_new_rounded,
                              size: 16, color: Color(0xFF667EEA)),
                          padding: EdgeInsets.zero,
                        ),
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Faculty Directory",
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF1E293B),
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              _isLoading
                                  ? "Loading..."
                                  : "${_filteredFaculty.length} faculty members",
                              style: TextStyle(
                                fontSize: 13,
                                color: Color(0xFF64748B),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: Icon(
                          Icons.school_outlined,
                          size: 22,
                          color: Color(0xFF667EEA),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 16),

                  // Department Filter Section
                  FutureBuilder<List<Faculty>>(
                    future: _facultyFuture,
                    builder: (context, snapshot) {
                      if (_isLoading) {
                        return SizedBox(
                          height: 40,
                          child: Center(
                            child: SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Color(0xFF7C3AED),
                              ),
                            ),
                          ),
                        );
                      }

                      return Container(
                        height: 40,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: _departments.length,
                          itemBuilder: (context, index) {
                            final department = _departments[index];
                            final isSelected = _selectedDepartment == department;

                            return Padding(
                              padding: EdgeInsets.only(right: 8),
                              child: ChoiceChip(
                                label: Text(
                                  department,
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: isSelected ? Colors.white : Color(0xFF667EEA),
                                  ),
                                ),
                                selected: isSelected,
                                onSelected: (selected) {
                                  if (selected) {
                                    _filterByDepartment(department);
                                  }
                                },
                                backgroundColor: Color(0xFFF0F5FF),
                                selectedColor: Color(0xFF667EEA),
                                shape: StadiumBorder(
                                  side: BorderSide(
                                    color: isSelected ? Color(0xFF667EEA) : Color(0xFFE0E7FF),
                                    width: 1,
                                  ),
                                ),
                                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),

            // Faculty List
            Expanded(
              child: FutureBuilder<List<Faculty>>(
                future: _facultyFuture,
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (_isLoading) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 28,
                            height: 28,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFF7C3AED),
                            ),
                          ),
                          SizedBox(height: 16),
                          Text(
                            "Loading Faculty...",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    );
                  }

                  if (snapshot.hasError) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              Icons.error_outline_rounded,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            "Error Loading Faculty",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            "Please check your connection",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          SizedBox(height: 16),
                          TextButton(
                            onPressed: _refreshFaculty,
                            style: TextButton.styleFrom(
                              foregroundColor: Color(0xFF667EEA),
                            ),
                            child: Text("Retry"),
                          ),
                        ],
                      ),
                    );
                  }

                  if (_filteredFaculty.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              _selectedDepartment != "All"
                                  ? Icons.filter_alt_outlined
                                  : Icons.people_alt_outlined,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            _selectedDepartment != "All"
                                ? "No faculty in ${_selectedDepartment}"
                                : "No Faculty Available",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            _selectedDepartment != "All"
                                ? "Try selecting a different department"
                                : "Faculty information will appear here",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          if (_selectedDepartment != "All")
                            Padding(
                              padding: EdgeInsets.only(top: 16),
                              child: TextButton(
                                onPressed: () => _filterByDepartment("All"),
                                style: TextButton.styleFrom(
                                  foregroundColor: Color(0xFF667EEA),
                                ),
                                child: Text("Show All Departments"),
                              ),
                            ),
                        ],
                      ),
                    );
                  }

                  return ListView.builder(
                    padding: EdgeInsets.all(16),
                    itemCount: _filteredFaculty.length,
                    itemBuilder: (BuildContext context, int index) {
                      var faculty = _filteredFaculty[index];
                      return _buildFacultyCard(faculty);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFacultyCard(Faculty faculty) {
    return Container(
        margin: EdgeInsets.only(bottom: 16),
    decoration: BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(14),
    border: Border.all(color: Color(0xFFE8E8E8), width: 1),
    boxShadow: [
    BoxShadow(
    color: Colors.black.withOpacity(0.02),
    blurRadius: 6,
    offset: Offset(0, 2),
    ),
    ],
    ),
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    // Profile Header
    Padding(
    padding: EdgeInsets.all(20),
    child: Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    // Profile Image
    Container(
    width: 70,
    height: 70,
    decoration: BoxDecoration(
    shape: BoxShape.circle,
    border: Border.all(
    color: Color(0xFFE0E7FF),
    width: 2,
    ),
    image: DecorationImage(
    image: NetworkImage(faculty.profile_pic),
    fit: BoxFit.cover,
    onError: (exception, stackTrace) => Container(
    decoration: BoxDecoration(
    shape: BoxShape.circle,
    color: Color(0xFFF5F3FF),
    ),
    child: Icon(
    Icons.person_outline_rounded,
    size: 32,
    color: Color(0xFF8B5CF6),
    ),
    ),
    ),
    ),
    ),
    SizedBox(width: 16),
    Expanded(
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    Text(
    faculty.name,
    style: TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w600,
    color: Color(0xFF1E293B),
    ),
    ),
    SizedBox(height: 6),
    Container(
    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(
    color: Color(0xFFF5F3FF),
    borderRadius: BorderRadius.circular(6),
    border: Border.all(color: Color(0xFFE9E0FF), width: 1),
    ),
    child: Text(
    faculty.designation,
    style: TextStyle(
    fontSize: 13,
    color: Color(0xFF7C3AED),
    fontWeight: FontWeight.w500,
    ),
    ),
    ),
    SizedBox(height: 8),
    Row(
    children: [
    Icon(
    Icons.business_rounded,
    size: 14,
    color: Color(0xFF94A3B8),
    ),
    SizedBox(width: 6),
    Text(
    faculty.department,
    style: TextStyle(
    fontSize: 13,
    color: Color(0xFF64748B),
    ),
    ),
    ],
    ),
    ],
    ),
    ),
    ],
    ),
    ),

    // Faculty Details
    Padding(
    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 0),
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    // ID Badge
    Container(
    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(
    color: Color(0xFFF8FAFC),
    borderRadius: BorderRadius.circular(8),
    border: Border.all(color: Color(0xFFF1F5F9)),
    ),
    child: Row(
    mainAxisSize: MainAxisSize.min,
    children: [
    Icon(
    Icons.badge_outlined,
    size: 12,
    color: Color(0xFF64748B),
    ),
    SizedBox(width: 6),
    Text(
    "ID: ${faculty.id}",
    style: TextStyle(
    fontSize: 11,
    color: Color(0xFF64748B),
    fontWeight: FontWeight.w500,
    ),
    ),
    ],
    ),
    ),

    SizedBox(height: 20),

    // Contact Details
    _buildDetailRow(Icons.email_outlined, faculty.email),
    SizedBox(height: 12),
    _buildDetailRow(Icons.phone_outlined, faculty.number),

    SizedBox(height: 24),

    // Send Feedback Button
    Container(
    width: double.infinity,
    height: 46,
    decoration: BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(10),
    border: Border.all(color: Color(0xFF667EEA), width: 1.5),
    ),
    child: Material(
    color: Colors.transparent,
    borderRadius: BorderRadius.circular(10),
    child: InkWell(
    borderRadius: BorderRadius.circular(10),
    onTap: () async {
    SharedPreferences prefs =
    await SharedPreferences.getInstance();
    prefs.setString("facultyid", faculty.id.toString());
    Navigator.push(
    context,
    MaterialPageRoute(
    builder: (context) => sent_feedback()),
    );
    },
    child: Center(
    child: Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
    Icon(
    Icons.feedback_outlined,
    size: 16,
    color: Color(0xFF667EEA),
    ),
    SizedBox(width: 10),
    Text(
    'Send Feedback',
    style: TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w600,
    color: Color(0xFF667EEA),
    ),
    ),
    ],
    ),
    ),
    ),
    ),
    ),

    SizedBox(height: 8),
    Align(
    alignment: Alignment.centerRight,
    child: Text(
    "Provide your valuable feedback",
    style: TextStyle(
    fontSize: 11,
    color: Color(0xFF94A3B8),
    ),
    ),
    ),
    SizedBox(height: 16),
    ],
    ),
    ),
    ],
    ));
  }

  Widget _buildDetailRow(IconData icon, String value) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Color(0xFFF1F5F9)),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: Color(0xFFF5F3FF),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: Color(0xFFE9E0FF)),
            ),
            child: Icon(
              icon,
              size: 16,
              color: Color(0xFF8B5CF6),
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF1E293B),
                    fontWeight: FontWeight.w500,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class Faculty {
  final String profile_pic;
  final String id;
  final String name;
  final String department;
  final String designation;
  final String number;
  final String email;

  Faculty(this.profile_pic, this.id, this.name, this.department,
      this.designation, this.number, this.email);
}








// import 'dart:convert';
//
// import 'package:college_connect/student/sent_feedback.dart';
// import 'package:college_connect/student/studenthome.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart'as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// class view_faculty extends StatelessWidget {
//   const view_faculty({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(home: view_faculty_sub(),);
//   }
// }
//
// class view_faculty_sub extends StatefulWidget {
//   const view_faculty_sub({Key? key}) : super(key: key);
//
//   @override
//   State<view_faculty_sub> createState() => view_faculty_sub_State();
// }
//
// class view_faculty_sub_State extends State<view_faculty_sub> {
//   Future<List<Joke>> _getJokes() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     String b = prefs.getString("uid").toString();
//     String foodimage="";
//     var data =
//     await http.post(Uri.parse(prefs.getString("ip").toString()+"/view_faculty"),
//         body: {"id":b}
//     );
//
//     var jsonData = json.decode(data.body);
// //    print(jsonData);
//     List<Joke> jokes = [];
//     for (var joke in jsonData["data"]) {
//       print(joke);
//       Joke newJoke = Joke(
//           prefs.getString("ip").toString()+joke["profile_pic"].toString(),
//           joke["id"].toString(),
//           joke["name"].toString(),
//           joke["department"].toString(),
//           joke["designation"].toString(),
//           joke["number"].toString(),
//           joke["email"].toString()
//       );
//       jokes.add(newJoke);
//     }
//     return jokes;
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text("Faculty"),centerTitle: true,leading: IconButton(onPressed: (){
//         Navigator.push(context, MaterialPageRoute(builder: (context)=>home()));
//       }, icon: Icon(Icons.arrow_back)),),
//       body:
//
//
//       Container(
//
//         child:
//         FutureBuilder(
//           future: _getJokes(),
//           builder: (BuildContext context, AsyncSnapshot snapshot) {
// //              print("snapshot"+snapshot.toString());
//             if (snapshot.data == null) {
//               return Container(
//                 child: Center(
//                   child: Text("Loading..."),
//                 ),
//               );
//             } else {
//               return ListView.builder(
//                 itemCount: snapshot.data.length,
//                 itemBuilder: (BuildContext context, int index) {
//                   var i = snapshot.data![index];
//                   return Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: Card(
//                       elevation: 3,
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(10),
//                         side: BorderSide(color: Colors.grey.shade300),
//                       ),
//                       child: Padding(
//                         padding: const EdgeInsets.all(16.0),
//                         child: Column(
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//
//                             SizedBox(height: 10),
//                             Image.network(i.profile_pic.toString(),height:100,width:100,),
//                             _buildRow("Id:", i.id.toString()),
//                             _buildRow("Faculty Name:", i.name.toString()),
//                             _buildRow("Department:", i.department.toString()),
//                             _buildRow("Designation:", i.designation.toString()),
//                             _buildRow("Number:", i.number.toString()),
//                             _buildRow("Email:", i.email.toString()),
//                             Row(children: [
//                               ElevatedButton(onPressed: ()async{
//                                 SharedPreferences prefs=await SharedPreferences.getInstance();
//                                 prefs.setString("facultyid", i.id.toString());
//                                 Navigator.push(context, MaterialPageRoute(builder: (context)=>sent_feedback()));
//                               }, child: Text("Send  feedback"))
//                             ],)
//
//                           ],
//                         ),
//                       ),
//                     ),
//                   );
//                 },
//               );
//
//
//             }
//           },
//
//
//         ),
//
//
//
//
//
//       ),
//     );
//   }
// }
// Widget _buildRow(String label, String value) {
//   return Padding(
//     padding: const EdgeInsets.symmetric(vertical: 4),
//     child: Row(
//       children: [
//         SizedBox(
//           width: 100,
//           child: Text(
//             label,
//             style: TextStyle(
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//         ),
//         SizedBox(width: 5),
//         Flexible(
//           child: Text(
//             value,
//             style: TextStyle(
//               color: Colors.grey.shade800,
//             ),
//           ),
//         ),
//       ],
//     ),
//   );
// }
//
// class Joke {
//   final String profile_pic;
//   final String id;
//   final String name;
//   final String department;
//   final String designation;
//   final String number;
//   final String email;
//
//
//
//
//   Joke(this.profile_pic,this.id,this.name, this.department,this.designation,this.number,this.email);
// //  print("hiiiii");
// }
