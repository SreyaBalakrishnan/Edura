import 'dart:convert';
import 'package:college_connect/student/studenthome.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class view_notification extends StatelessWidget {
  const view_notification({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: view_notification_sub(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class view_notification_sub extends StatefulWidget {
  const view_notification_sub({Key? key}) : super(key: key);

  @override
  State<view_notification_sub> createState() => view_notification_sub_State();
}

class view_notification_sub_State extends State<view_notification_sub> {
  late Future<List<Joke>> _notificationsFuture;
  bool _isLoading = true;
  List<Joke> _allNotifications = [];
  List<Joke> _filteredNotifications = [];
  List<String> _dateFilters = ["All", "Today", "This Week", "This Month"];
  String _selectedDateFilter = "All";

  @override
  void initState() {
    super.initState();
    _notificationsFuture = _getJokes();
  }

  Future<List<Joke>> _getJokes() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String b = prefs.getString("uid").toString();
      var data = await http.post(
        Uri.parse(prefs.getString("ip").toString() + "/view_notifications"),
        body: {"id": b},
      );

      var jsonData = json.decode(data.body);
      List<Joke> jokes = [];

      for (var joke in jsonData["data"]) {
        Joke newJoke = Joke(
          joke["id"].toString(),
          joke["title"].toString(),
          joke["message"].toString(),
          joke["date"].toString(),
        );
        jokes.add(newJoke);
      }

      // Sort by date (newest first)
      jokes.sort((a, b) => b.date.compareTo(a.date));

      setState(() {
        _allNotifications = jokes;
        _filteredNotifications = jokes;
        _isLoading = false;
      });

      return jokes;
    } catch (e) {
      print("Error fetching notifications: $e");
      setState(() {
        _isLoading = false;
      });
      return [];
    }
  }

  void _filterByDate(String filter) {
    setState(() {
      _selectedDateFilter = filter;

      if (filter == "All") {
        _filteredNotifications = _allNotifications;
      } else {
        DateTime now = DateTime.now();
        _filteredNotifications = _allNotifications.where((notification) {
          try {
            DateTime notificationDate = DateTime.parse(notification.date);

            if (filter == "Today") {
              return notificationDate.year == now.year &&
                  notificationDate.month == now.month &&
                  notificationDate.day == now.day;
            } else if (filter == "This Week") {
              DateTime weekStart = now.subtract(Duration(days: now.weekday - 1));
              return notificationDate.isAfter(weekStart);
            } else if (filter == "This Month") {
              return notificationDate.year == now.year &&
                  notificationDate.month == now.month;
            }
            return true;
          } catch (e) {
            return false;
          }
        }).toList();
      }
    });
  }

  Future<void> _refreshNotifications() async {
    setState(() {
      _isLoading = true;
      _notificationsFuture = _getJokes();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFAFAFA),
      body: SafeArea(
        child: Column(
          children: [
            // Clean Minimal Header
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                  bottom: BorderSide(color: Color(0xFFE8E8E8), width: 1),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: IconButton(
                          onPressed: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (context) => home()),
                            );
                          },
                          icon: Icon(Icons.arrow_back_ios_new_rounded,
                              size: 16, color: Color(0xFF667EEA)),
                          padding: EdgeInsets.zero,
                        ),
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Notifications",
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF1E293B),
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              _isLoading
                                  ? "Loading..."
                                  : "${_filteredNotifications.length} notifications",
                              style: TextStyle(
                                fontSize: 13,
                                color: Color(0xFF64748B),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: Icon(
                          Icons.notifications_outlined,
                          size: 22,
                          color: Color(0xFF667EEA),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 16),

                  // Date Filter Section
                  FutureBuilder<List<Joke>>(
                    future: _notificationsFuture,
                    builder: (context, snapshot) {
                      if (_isLoading) {
                        return SizedBox(
                          height: 40,
                          child: Center(
                            child: SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Color(0xFF7C3AED),
                              ),
                            ),
                          ),
                        );
                      }

                      if (_allNotifications.isEmpty) {
                        return Container(
                          height: 40,
                          child: Center(
                            child: Text(
                              "No notifications yet",
                              style: TextStyle(
                                color: Color(0xFF64748B),
                                fontSize: 13,
                              ),
                            ),
                          ),
                        );
                      }

                      return Container(
                        height: 40,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: _dateFilters.length,
                          itemBuilder: (context, index) {
                            final filter = _dateFilters[index];
                            final isSelected = _selectedDateFilter == filter;
                            Color filterColor = Color(0xFF8B5CF6);

                            return Padding(
                              padding: EdgeInsets.only(right: 8),
                              child: ChoiceChip(
                                label: Text(
                                  filter,
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: isSelected ? Colors.white : filterColor,
                                  ),
                                ),
                                selected: isSelected,
                                onSelected: (selected) {
                                  if (selected) {
                                    _filterByDate(filter);
                                  }
                                },
                                backgroundColor: filterColor.withOpacity(0.1),
                                selectedColor: filterColor,
                                shape: StadiumBorder(
                                  side: BorderSide(
                                    color: isSelected ? filterColor : filterColor.withOpacity(0.3),
                                    width: 1,
                                  ),
                                ),
                                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),

            // Notifications List
            Expanded(
              child: FutureBuilder<List<Joke>>(
                future: _notificationsFuture,
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (_isLoading) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 28,
                            height: 28,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFF7C3AED),
                            ),
                          ),
                          SizedBox(height: 16),
                          Text(
                            "Loading Notifications...",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    );
                  }

                  if (snapshot.hasError) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              Icons.error_outline_rounded,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            "Error Loading Notifications",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            "Please check your connection",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          SizedBox(height: 16),
                          TextButton(
                            onPressed: _refreshNotifications,
                            style: TextButton.styleFrom(
                              foregroundColor: Color(0xFF667EEA),
                            ),
                            child: Text("Retry"),
                          ),
                        ],
                      ),
                    );
                  }

                  if (_filteredNotifications.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              _selectedDateFilter != "All"
                                  ? Icons.filter_alt_outlined
                                  : Icons.notifications_off_outlined,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            _selectedDateFilter != "All"
                                ? "No notifications in selected period"
                                : "No Notifications Yet",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            _selectedDateFilter != "All"
                                ? "Try different filter combinations"
                                : "Notifications will appear here",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          if (_selectedDateFilter != "All")
                            Padding(
                              padding: EdgeInsets.only(top: 16),
                              child: TextButton(
                                onPressed: () {
                                  _filterByDate("All");
                                },
                                style: TextButton.styleFrom(
                                  foregroundColor: Color(0xFF667EEA),
                                ),
                                child: Text("Clear Filter"),
                              ),
                            ),
                        ],
                      ),
                    );
                  }

                  return ListView.builder(
                    padding: EdgeInsets.all(16),
                    itemCount: _filteredNotifications.length,
                    itemBuilder: (BuildContext context, int index) {
                      var notification = _filteredNotifications[index];
                      return _buildNotificationCard(notification);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNotificationCard(Joke notification) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Color(0xFFE8E8E8), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Notification Header
          Padding(
            padding: EdgeInsets.all(20),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF667EEA), Color(0xFF8B5CF6)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Color(0xFF667EEA), width: 2),
                  ),
                  child: Icon(
                    Icons.notifications_active_rounded,
                    size: 32,
                    color: Colors.white,
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        notification.title,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1E293B),
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 6),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: Text(
                          "Important",
                          style: TextStyle(
                            fontSize: 13,
                            color: Color(0xFF667EEA),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(
                            Icons.calendar_today_outlined,
                            size: 14,
                            color: Color(0xFF94A3B8),
                          ),
                          SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              _formatDate(notification.date),
                              style: TextStyle(
                                fontSize: 13,
                                color: Color(0xFF64748B),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Notification Details
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ID Badge
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Color(0xFFF8FAFC),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Color(0xFFF1F5F9)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.fingerprint_outlined,
                        size: 12,
                        color: Color(0xFF64748B),
                      ),
                      SizedBox(width: 6),
                      Text(
                        "Notification ID: ${notification.id}",
                        style: TextStyle(
                          fontSize: 11,
                          color: Color(0xFF64748B),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 20),

                // Notification Details
                _buildDetailRow(
                  Icons.title_outlined,
                  "Title",
                  notification.title,
                ),
                SizedBox(height: 12),
                _buildDetailRow(
                  Icons.message_outlined,
                  "Message",
                  notification.message,
                  isMultiline: true,
                ),
                SizedBox(height: 12),
                _buildDetailRow(
                  Icons.calendar_month_outlined,
                  "Date",
                  _formatDate(notification.date),
                ),

                SizedBox(height: 16),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value,
      {bool isMultiline = false, Color iconColor = const Color(0xFF8B5CF6)}) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Color(0xFFF1F5F9)),
      ),
      child: Row(
        crossAxisAlignment: isMultiline ? CrossAxisAlignment.start : CrossAxisAlignment.center,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: iconColor.withOpacity(0.3)),
            ),
            child: Icon(
              icon,
              size: 16,
              color: iconColor,
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2),
                if (isMultiline)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      value,
                      style: TextStyle(
                        fontSize: 14,
                        color: Color(0xFF1E293B),
                        fontWeight: FontWeight.w500,
                        height: 1.4,
                      ),
                    ),
                  )
                else
                  Text(
                    value,
                    style: TextStyle(
                      fontSize: 14,
                      color: Color(0xFF1E293B),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(String dateString) {
    try {
      DateTime date = DateTime.parse(dateString);
      return "${date.day.toString().padLeft(2, '0')}-${date.month.toString().padLeft(2, '0')}-${date.year} ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}";
    } catch (e) {
      return dateString;
    }
  }
}

class Joke {
  final String id;
  final String title;
  final String message;
  final String date;

  Joke(this.id, this.title, this.message, this.date);
}








// import 'dart:convert';
//
// import 'package:college_connect/student/studenthome.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart'as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// class view_notification extends StatelessWidget {
// const view_notification({Key? key}) : super(key: key);
//
// @override
// Widget build(BuildContext context) {
// return MaterialApp(home:view_notification_sub() ,);
// }
// }
//
// class view_notification_sub extends StatefulWidget {
// const view_notification_sub({Key? key}) : super(key: key);
//
// @override
// State<view_notification_sub> createState() => view_notification_sub_State();
// }
//
// class view_notification_sub_State extends State<view_notification_sub> {
//   Future<List<Joke>> _getJokes() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     String b = prefs.getString("uid").toString();
//     String foodimage="";
//     var data =
//     await http.post(Uri.parse(prefs.getString("ip").toString()+"/view_notifications"),
//         body: {"id":b}
//     );
//
//     var jsonData = json.decode(data.body);
// //    print(jsonData);
//     List<Joke> jokes = [];
//     for (var joke in jsonData["data"]) {
//       print(joke);
//       Joke newJoke = Joke(
//           joke["id"].toString(),
//           joke["title"].toString(),
//           joke["message"].toString(),
//           joke["date"].toString()
//       );
//       jokes.add(newJoke);
//     }
//     return jokes;
//   }
//   @override
// Widget build(BuildContext context) {
// return Scaffold(
//   appBar: AppBar(title: Text("Notifications"),centerTitle: true,leading: IconButton(onPressed: (){
//     Navigator.push(context, MaterialPageRoute(builder: (context)=>home()));
//   }, icon: Icon(Icons.arrow_back)),),
//   body:
//
//
//   Container(
//
//     child:
//     FutureBuilder(
//       future: _getJokes(),
//       builder: (BuildContext context, AsyncSnapshot snapshot) {
// //              print("snapshot"+snapshot.toString());
//         if (snapshot.data == null) {
//           return Container(
//             child: Center(
//               child: Text("Loading..."),
//             ),
//           );
//         } else {
//           return ListView.builder(
//             itemCount: snapshot.data.length,
//             itemBuilder: (BuildContext context, int index) {
//               var i = snapshot.data![index];
//               return Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: Card(
//                   elevation: 3,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(10),
//                     side: BorderSide(color: Colors.grey.shade300),
//                   ),
//                   child: Padding(
//                     padding: const EdgeInsets.all(16.0),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//
//                         SizedBox(height: 10),
//                         _buildRow("Id:", i.id.toString()),
//                         _buildRow("Title:", i.title.toString()),
//                         _buildRow("Message:", i.message.toString()),
//                         _buildRow("Date:", i.date.toString()),
//
//                       ],
//                     ),
//                   ),
//                 ),
//               );
//             },
//           );
//
//
//         }
//       },
//
//
//     ),
//
//
//
//
//
//   ),
// );
// }
// }
// Widget _buildRow(String label, String value) {
//   return Padding(
//     padding: const EdgeInsets.symmetric(vertical: 4),
//     child: Row(
//       children: [
//         SizedBox(
//           width: 100,
//           child: Text(
//             label,
//             style: TextStyle(
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//         ),
//         SizedBox(width: 5),
//         Flexible(
//           child: Text(
//             value,
//             style: TextStyle(
//               color: Colors.grey.shade800,
//             ),
//           ),
//         ),
//       ],
//     ),
//   );
// }
//
// class Joke {
//   final String id;
//   final String title;
//   final String message;
//   final String date;
//
//
//
//
//   Joke(this.id,this.title, this.message,this.date);
// //  print("hiiiii");
// }