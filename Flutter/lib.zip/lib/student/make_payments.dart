import 'package:flutter/material.dart';

class make_payments extends StatelessWidget {
const make_payments({Key? key}) : super(key: key);

@override
Widget build(BuildContext context) {
return MaterialApp(home:make_payments_sub() ,);
}
}

class make_payments_sub extends StatefulWidget {
const make_payments_sub({Key? key}) : super(key: key);

@override
State<make_payments_sub> createState() => _State();
}

class _State extends State<make_payments_sub> {
@override
Widget build(BuildContext context) {
return const Placeholder();
}
}