import 'dart:convert';
import 'package:college_connect/student/add_previousnotes.dart';
import 'package:college_connect/student/studenthome.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class view_subject extends StatelessWidget {
  const view_subject({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: view_subject_sub(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class view_subject_sub extends StatefulWidget {
  const view_subject_sub({Key? key}) : super(key: key);

  @override
  State<view_subject_sub> createState() => view_subject_sub_State();
}

class view_subject_sub_State extends State<view_subject_sub> {
  late Future<List<Subject>> _subjectsFuture;
  List<Subject> _allSubjects = [];
  List<Subject> _filteredSubjects = [];
  List<String> _courses = ["All"];
  String _selectedCourse = "All";
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _subjectsFuture = _fetchSubjects();
  }

  Future<List<Subject>> _fetchSubjects() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String b = prefs.getString("uid").toString();
      var data = await http.post(
        Uri.parse(prefs.getString("ip").toString() + "/usr_view_subject"),
        body: {"id": b},
      );

      var jsonData = json.decode(data.body);
      List<Subject> subjects = [];
      Set<String> courseSet = Set();

      for (var subject in jsonData["data"]) {
        Subject newSubject = Subject(
          subject["id"].toString(),
          subject["subname"].toString(),
          subject["semester"].toString(),
          subject["course"].toString(),
        );
        subjects.add(newSubject);
        if (subject["course"].toString().isNotEmpty) {
          courseSet.add(subject["course"].toString());
        }
      }

      // Sort courses alphabetically
      List<String> sortedCourses = courseSet.toList()..sort();

      setState(() {
        _allSubjects = subjects;
        _filteredSubjects = subjects;
        _courses = ["All"] + sortedCourses;
        _isLoading = false;
      });

      return subjects;
    } catch (e) {
      print("Error fetching subjects: $e");
      setState(() {
        _isLoading = false;
      });
      return [];
    }
  }

  void _filterByCourse(String course) {
    setState(() {
      _selectedCourse = course;
      if (course == "All") {
        _filteredSubjects = _allSubjects;
      } else {
        _filteredSubjects = _allSubjects
            .where((subject) => subject.course == course)
            .toList();
      }
    });
  }

  Future<void> _refreshSubjects() async {
    setState(() {
      _isLoading = true;
      _subjectsFuture = _fetchSubjects();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFAFAFA),
      body: SafeArea(
        child: Column(
          children: [
            // Clean Minimal Header
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                  bottom: BorderSide(color: Color(0xFFE8E8E8), width: 1),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: IconButton(
                          onPressed: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (context) => home()),
                            );
                          },
                          icon: Icon(Icons.arrow_back_ios_new_rounded,
                              size: 16, color: Color(0xFF667EEA)),
                          padding: EdgeInsets.zero,
                        ),
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Subjects",
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF1E293B),
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              _isLoading
                                  ? "Loading..."
                                  : "${_filteredSubjects.length} subjects",
                              style: TextStyle(
                                fontSize: 13,
                                color: Color(0xFF64748B),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: Icon(
                          Icons.subject_outlined,
                          size: 22,
                          color: Color(0xFF667EEA),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 16),

                  // Course Filter Section
                  FutureBuilder<List<Subject>>(
                    future: _subjectsFuture,
                    builder: (context, snapshot) {
                      if (_isLoading) {
                        return SizedBox(
                          height: 40,
                          child: Center(
                            child: SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Color(0xFF7C3AED),
                              ),
                            ),
                          ),
                        );
                      }

                      return Container(
                        height: 40,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: _courses.length,
                          itemBuilder: (context, index) {
                            final course = _courses[index];
                            final isSelected = _selectedCourse == course;

                            return Padding(
                              padding: EdgeInsets.only(right: 8),
                              child: ChoiceChip(
                                label: Text(
                                  course,
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: isSelected ? Colors.white : Color(0xFF667EEA),
                                  ),
                                ),
                                selected: isSelected,
                                onSelected: (selected) {
                                  if (selected) {
                                    _filterByCourse(course);
                                  }
                                },
                                backgroundColor: Color(0xFFF0F5FF),
                                selectedColor: Color(0xFF667EEA),
                                shape: StadiumBorder(
                                  side: BorderSide(
                                    color: isSelected ? Color(0xFF667EEA) : Color(0xFFE0E7FF),
                                    width: 1,
                                  ),
                                ),
                                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),

            // Subjects List
            Expanded(
              child: FutureBuilder<List<Subject>>(
                future: _subjectsFuture,
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (_isLoading) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 28,
                            height: 28,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFF7C3AED),
                            ),
                          ),
                          SizedBox(height: 16),
                          Text(
                            "Loading Subjects...",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    );
                  }

                  if (snapshot.hasError) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              Icons.error_outline_rounded,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            "Error Loading Subjects",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            "Please check your connection",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          SizedBox(height: 16),
                          TextButton(
                            onPressed: _refreshSubjects,
                            style: TextButton.styleFrom(
                              foregroundColor: Color(0xFF667EEA),
                            ),
                            child: Text("Retry"),
                          ),
                        ],
                      ),
                    );
                  }

                  if (_filteredSubjects.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              _selectedCourse != "All"
                                  ? Icons.filter_alt_outlined
                                  : Icons.subject_outlined,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            _selectedCourse != "All"
                                ? "No subjects in ${_selectedCourse}"
                                : "No Subjects Available",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            _selectedCourse != "All"
                                ? "Try selecting a different course"
                                : "Subjects will appear here once added",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          if (_selectedCourse != "All")
                            Padding(
                              padding: EdgeInsets.only(top: 16),
                              child: TextButton(
                                onPressed: () => _filterByCourse("All"),
                                style: TextButton.styleFrom(
                                  foregroundColor: Color(0xFF667EEA),
                                ),
                                child: Text("Show All Courses"),
                              ),
                            ),
                        ],
                      ),
                    );
                  }

                  return ListView.builder(
                    padding: EdgeInsets.all(16),
                    itemCount: _filteredSubjects.length,
                    itemBuilder: (BuildContext context, int index) {
                      var subject = _filteredSubjects[index];
                      return _buildSubjectCard(subject);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSubjectCard(Subject subject) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Color(0xFFE8E8E8), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Subject Header
          Padding(
            padding: EdgeInsets.all(20),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    color: Color(0xFFF5F3FF),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Color(0xFFE9E0FF), width: 2),
                  ),
                  child: Icon(
                    Icons.menu_book_outlined,
                    size: 32,
                    color: Color(0xFF8B5CF6),
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        subject.subname,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                      SizedBox(height: 6),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Color(0xFFF5F3FF),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: Color(0xFFE9E0FF), width: 1),
                        ),
                        child: Text(
                          subject.course,
                          style: TextStyle(
                            fontSize: 13,
                            color: Color(0xFF7C3AED),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(
                            Icons.school_outlined,
                            size: 14,
                            color: Color(0xFF94A3B8),
                          ),
                          SizedBox(width: 6),
                          Text(
                            "Semester ${subject.semester}",
                            style: TextStyle(
                              fontSize: 13,
                              color: Color(0xFF64748B),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Subject Details
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ID Badge
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Color(0xFFF8FAFC),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Color(0xFFF1F5F9)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.badge_outlined,
                        size: 12,
                        color: Color(0xFF64748B),
                      ),
                      SizedBox(width: 6),
                      Text(
                        "ID: ${subject.id}",
                        style: TextStyle(
                          fontSize: 11,
                          color: Color(0xFF64748B),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 20),

                // Subject Details
                _buildDetailRow(Icons.menu_book_outlined, "Subject", subject.subname),
                SizedBox(height: 12),
                _buildDetailRow(Icons.school_outlined, "Semester", "Semester ${subject.semester}"),
                SizedBox(height: 12),
                _buildDetailRow(Icons.category_outlined, "Course", subject.course),

                SizedBox(height: 24),

                // Add Previous Notes Button
                Container(
                  width: double.infinity,
                  height: 46,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Color(0xFF667EEA), width: 1.5),
                  ),
                  child: Material(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(10),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(10),
                      onTap: () async {
                        SharedPreferences sh = await SharedPreferences.getInstance();
                        sh.setString("subid", subject.id.toString());
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => add_previousnotes()),
                        );
                      },
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.note_add_outlined,
                              size: 16,
                              color: Color(0xFF667EEA),
                            ),
                            SizedBox(width: 10),
                            Text(
                              'Add Previous Notes',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF667EEA),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),

                SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    "Upload study materials for this subject",
                    style: TextStyle(
                      fontSize: 11,
                      color: Color(0xFF94A3B8),
                    ),
                  ),
                ),
                SizedBox(height: 16),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Container(
        padding: EdgeInsets.all(12),
    decoration: BoxDecoration(
    color: Color(0xFFF8FAFC),
    borderRadius: BorderRadius.circular(8),
    border: Border.all(color: Color(0xFFF1F5F9)),
    ),
    child: Row(
    children: [
    Container(
    width: 32,
    height: 32,
    decoration: BoxDecoration(
    color: Color(0xFFF5F3FF),
    borderRadius: BorderRadius.circular(6),
    border: Border.all(color: Color(0xFFE9E0FF)),
    ),
    child: Icon(
    icon,
    size: 16,
    color: Color(0xFF8B5CF6),
    ),
    ),
    SizedBox(width: 12),
    Expanded(
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    Text(
    label,
    style: TextStyle(
    fontSize: 12,
    color: Color(0xFF64748B),
    fontWeight: FontWeight.w500,
    ),
    ),
    SizedBox(height: 2),
    Text(
    value,
    style: TextStyle(
    fontSize: 14,
    color: Color(0xFF1E293B),
    fontWeight: FontWeight.w600,
    ),
    ),
    ],
    ),
    ),
    ],
    ));
  }
}

class Subject {
  final String id;
  final String subname;
  final String semester;
  final String course;

  Subject(this.id, this.subname, this.semester, this.course);
}









// import 'dart:convert';
//
// import 'package:college_connect/student/add_previousnotes.dart';
// import 'package:college_connect/student/studenthome.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart'as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// void main(){
//   runApp(view_subject());
// }
//
//
// class view_subject extends StatelessWidget {
//   const view_subject({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(home:view_subject_sub() ,);
//   }
// }
// class  view_subject_sub extends StatefulWidget {
//   const view_subject_sub({Key? key}) : super(key: key);
//
//   @override
//   State<view_subject_sub> createState() => view_subject_sub_State();
// }
//
// class view_subject_sub_State extends State<view_subject_sub> {
//   Future<List<Joke>> _getJokes() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     String b = prefs.getString("uid").toString();
//     String foodimage="";
//     var data =
//     await http.post(Uri.parse(prefs.getString("ip").toString()+"/usr_view_subject"),
//         body: {"id":b}
//     );
//
//     var jsonData = json.decode(data.body); //    print(jsonData);
//     List<Joke> jokes = [];
//     for (var joke in jsonData["data"]) {
//       print(joke);
//       Joke newJoke = Joke(
//           joke["id"].toString(),
//           joke["subname"].toString(),
//           joke["semester"].toString(),
//           joke["course"].toString()
//       );
//       jokes.add(newJoke);
//     }
//     return jokes;
//   }
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text("Subject"),centerTitle: true,leading: IconButton(onPressed: (){
//         Navigator.push(context, MaterialPageRoute(builder: (context)=>home()));
//       }, icon: Icon(Icons.arrow_back)),),
//       body:
//
//
//       Container(
//
//         child:
//         FutureBuilder(
//           future: _getJokes(),
//           builder: (BuildContext context, AsyncSnapshot snapshot) {
// //              print("snapshot"+snapshot.toString());
//             if (snapshot.data == null) {
//               return Container(
//                 child: Center(
//                   child: Text("Loading..."),
//                 ),
//               );
//             } else {
//               return ListView.builder(
//                 itemCount: snapshot.data.length,
//                 itemBuilder: (BuildContext context, int index) {
//                   var i = snapshot.data![index];
//                   return Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: Card(
//                       elevation: 3,
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(10),
//                         side: BorderSide(color: Colors.grey.shade300),
//                       ),
//                       child: Padding(
//                         padding: const EdgeInsets.all(16.0),
//                         child: Column(
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//
//                             SizedBox(height: 10),
//                             _buildRow("Id:", i.id.toString()),
//                             _buildRow("Subject Name:", i.subname.toString()),
//                             _buildRow("Semester:", i.semester.toString()),
//                             _buildRow("Course:", i.course.toString()),
//
//                             Row(children: [
//                               TextButton(onPressed: () async {
//                                 SharedPreferences sh=await SharedPreferences.getInstance();
//                                 sh.setString("subid", i.id.toString());
//                                 Navigator.push(context, MaterialPageRoute(builder: (context)=>add_previousnotes()));
//                               }, child: Text("Add previous notes"))
//                             ],)
//
//                           ],
//                         ),
//                       ),
//                     ),
//                   );
//                 },
//               );
//
//
//             }
//           },
//
//
//         ),
//
//
//
//
//
//       ),
//     );
//   }
// }
// Widget _buildRow(String label, String value) {
//   return Padding(
//     padding: const EdgeInsets.symmetric(vertical: 4),
//     child: Row(
//       children: [
//         SizedBox(
//           width: 100,
//           child: Text(
//             label,
//             style: TextStyle(
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//         ),
//         SizedBox(width: 5),
//         Flexible(
//           child: Text(
//             value,
//             style: TextStyle(
//               color: Colors.grey.shade800,
//             ),
//           ),
//         ),
//       ],
//     ),
//   );
// }
//
// class Joke {
//   final String id;
//   final String subname;
//   final String semester;
//   final String course;
//
//
//
//
//   Joke(this.id,this.subname, this.semester,this.course);
// //  print("hiiiii");
// }
