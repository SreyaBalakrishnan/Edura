import 'dart:convert';
import 'package:college_connect/student/studenthome.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class view_attendance extends StatelessWidget {
  const view_attendance({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: view_attendance_sub(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class view_attendance_sub extends StatefulWidget {
  const view_attendance_sub({Key? key}) : super(key: key);

  @override
  State<view_attendance_sub> createState() => view_attendance_sub_State();
}

class view_attendance_sub_State extends State<view_attendance_sub> {
  late Future<List<Attendance>> _attendanceFuture;
  List<Attendance> _allAttendance = [];
  List<Attendance> _filteredAttendance = [];
  List<String> _subjects = ["All"];
  List<String> _statuses = ["All", "Present", "Absent"];
  String _selectedSubject = "All";
  String _selectedStatus = "All";
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _attendanceFuture = _fetchAttendance();
  }

  Future<List<Attendance>> _fetchAttendance() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String b = prefs.getString("sid").toString();
      var data = await http.post(
        Uri.parse(prefs.getString("ip").toString() + "/view_attendance"),
        body: {"id": b},
      );

      var jsonData = json.decode(data.body);
      List<Attendance> attendanceList = [];
      Set<String> subjectSet = Set();

      for (var attendance in jsonData["data"]) {
        Attendance newAttendance = Attendance(
          attendance["id"].toString(),
          attendance["student"].toString(),
          attendance["rollno"].toString(),
          attendance["subject"].toString(),
          attendance["date"].toString(),
          attendance["status"].toString(),
        );
        attendanceList.add(newAttendance);
        if (attendance["subject"].toString().isNotEmpty) {
          subjectSet.add(attendance["subject"].toString());
        }
      }

      // Sort subjects alphabetically
      List<String> sortedSubjects = subjectSet.toList()..sort();

      setState(() {
        _allAttendance = attendanceList;
        _filteredAttendance = attendanceList;
        _subjects = ["All"] + sortedSubjects;
        _isLoading = false;
      });

      return attendanceList;
    } catch (e) {
      print("Error fetching attendance: $e");
      setState(() {
        _isLoading = false;
      });
      return [];
    }
  }

  void _filterBySubject(String subject) {
    setState(() {
      _selectedSubject = subject;
      _applyFilters();
    });
  }

  void _filterByStatus(String status) {
    setState(() {
      _selectedStatus = status;
      _applyFilters();
    });
  }

  void _applyFilters() {
    List<Attendance> filtered = _allAttendance;

    // Apply subject filter
    if (_selectedSubject != "All") {
      filtered = filtered
          .where((attendance) => attendance.subject == _selectedSubject)
          .toList();
    }

    // Apply status filter
    if (_selectedStatus != "All") {
      filtered = filtered
          .where((attendance) => attendance.status == _selectedStatus)
          .toList();
    }

    setState(() {
      _filteredAttendance = filtered;
    });
  }

  Future<void> _refreshAttendance() async {
    setState(() {
      _isLoading = true;
      _attendanceFuture = _fetchAttendance();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFAFAFA),
      body: SafeArea(
        child: Column(
          children: [
            // Clean Minimal Header
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                  bottom: BorderSide(color: Color(0xFFE8E8E8), width: 1),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: IconButton(
                          onPressed: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (context) => home()),
                            );
                          },
                          icon: Icon(Icons.arrow_back_ios_new_rounded,
                              size: 16, color: Color(0xFF667EEA)),
                          padding: EdgeInsets.zero,
                        ),
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Attendance Records",
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF1E293B),
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              _isLoading
                                  ? "Loading..."
                                  : "${_filteredAttendance.length} records",
                              style: TextStyle(
                                fontSize: 13,
                                color: Color(0xFF64748B),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: Color(0xFFF0F5FF),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                        ),
                        child: Icon(
                          Icons.calendar_today_outlined,
                          size: 22,
                          color: Color(0xFF667EEA),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 16),

                  // Subject Filter Section
                  FutureBuilder<List<Attendance>>(
                    future: _attendanceFuture,
                    builder: (context, snapshot) {
                      if (_isLoading) {
                        return SizedBox(
                          height: 40,
                          child: Center(
                            child: SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Color(0xFF7C3AED),
                              ),
                            ),
                          ),
                        );
                      }

                      return Column(
                        children: [
                          // Subject Filter
                          Container(
                            height: 40,
                            child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              itemCount: _subjects.length,
                              itemBuilder: (context, index) {
                                final subject = _subjects[index];
                                final isSelected = _selectedSubject == subject;

                                return Padding(
                                  padding: EdgeInsets.only(right: 8),
                                  child: ChoiceChip(
                                    label: Text(
                                      subject,
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: isSelected ? Colors.white : Color(0xFF667EEA),
                                      ),
                                    ),
                                    selected: isSelected,
                                    onSelected: (selected) {
                                      if (selected) {
                                        _filterBySubject(subject);
                                      }
                                    },
                                    backgroundColor: Color(0xFFF0F5FF),
                                    selectedColor: Color(0xFF667EEA),
                                    shape: StadiumBorder(
                                      side: BorderSide(
                                        color: isSelected ? Color(0xFF667EEA) : Color(0xFFE0E7FF),
                                        width: 1,
                                      ),
                                    ),
                                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                  ),
                                );
                              },
                            ),
                          ),

                          SizedBox(height: 8),

                          // Status Filter
                          Container(
                            height: 40,
                            child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              itemCount: _statuses.length,
                              itemBuilder: (context, index) {
                                final status = _statuses[index];
                                final isSelected = _selectedStatus == status;
                                Color statusColor = _getStatusColor(status);

                                return Padding(
                                  padding: EdgeInsets.only(right: 8),
                                  child: ChoiceChip(
                                    label: Text(
                                      status,
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: isSelected ? Colors.white : statusColor,
                                      ),
                                    ),
                                    selected: isSelected,
                                    onSelected: (selected) {
                                      if (selected) {
                                        _filterByStatus(status);
                                      }
                                    },
                                    backgroundColor: statusColor.withOpacity(0.1),
                                    selectedColor: statusColor,
                                    shape: StadiumBorder(
                                      side: BorderSide(
                                        color: isSelected ? statusColor : statusColor.withOpacity(0.3),
                                        width: 1,
                                      ),
                                    ),
                                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ),

            // Attendance List
            Expanded(
              child: FutureBuilder<List<Attendance>>(
                future: _attendanceFuture,
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (_isLoading) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 28,
                            height: 28,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFF7C3AED),
                            ),
                          ),
                          SizedBox(height: 16),
                          Text(
                            "Loading Attendance...",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    );
                  }

                  if (snapshot.hasError) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              Icons.error_outline_rounded,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            "Error Loading Attendance",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            "Please check your connection",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          SizedBox(height: 16),
                          TextButton(
                            onPressed: _refreshAttendance,
                            style: TextButton.styleFrom(
                              foregroundColor: Color(0xFF667EEA),
                            ),
                            child: Text("Retry"),
                          ),
                        ],
                      ),
                    );
                  }

                  if (_filteredAttendance.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              _selectedSubject != "All" || _selectedStatus != "All"
                                  ? Icons.filter_alt_outlined
                                  : Icons.calendar_today_outlined,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            _selectedSubject != "All" || _selectedStatus != "All"
                                ? "No matching attendance records"
                                : "No Attendance Records",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            _selectedSubject != "All" || _selectedStatus != "All"
                                ? "Try different filter combinations"
                                : "Attendance records will appear here",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          if (_selectedSubject != "All" || _selectedStatus != "All")
                            Padding(
                              padding: EdgeInsets.only(top: 16),
                              child: TextButton(
                                onPressed: () {
                                  _filterBySubject("All");
                                  _filterByStatus("All");
                                },
                                style: TextButton.styleFrom(
                                  foregroundColor: Color(0xFF667EEA),
                                ),
                                child: Text("Clear All Filters"),
                              ),
                            ),
                        ],
                      ),
                    );
                  }

                  return ListView.builder(
                    padding: EdgeInsets.all(16),
                    itemCount: _filteredAttendance.length,
                    itemBuilder: (BuildContext context, int index) {
                      var attendance = _filteredAttendance[index];
                      return _buildAttendanceCard(attendance);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAttendanceCard(Attendance attendance) {
    Color statusColor = _getStatusColor(attendance.status);

    return Container(
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Color(0xFFE8E8E8), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Attendance Header
          Padding(
            padding: EdgeInsets.all(20),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: statusColor, width: 2),
                  ),
                  child: Icon(
                    attendance.status == "Present"
                        ? Icons.check_circle_outline
                        : Icons.cancel_outlined,
                    size: 32,
                    color: statusColor,
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        attendance.student,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                      SizedBox(height: 6),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: statusColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: statusColor, width: 1),
                        ),
                        child: Text(
                          attendance.status,
                          style: TextStyle(
                            fontSize: 13,
                            color: statusColor,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(
                            Icons.subject_outlined,
                            size: 14,
                            color: Color(0xFF94A3B8),
                          ),
                          SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              attendance.subject,
                              style: TextStyle(
                                fontSize: 13,
                                color: Color(0xFF64748B),
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Attendance Details
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ID Badge
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Color(0xFFF8FAFC),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Color(0xFFF1F5F9)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.badge_outlined,
                        size: 12,
                        color: Color(0xFF64748B),
                      ),
                      SizedBox(width: 6),
                      Text(
                        "ID: ${attendance.id}",
                        style: TextStyle(
                          fontSize: 11,
                          color: Color(0xFF64748B),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 20),

                // Attendance Details
                _buildDetailRow(Icons.person_outlined, "Student", attendance.student),
                SizedBox(height: 12),
                _buildDetailRow(Icons.confirmation_number_outlined, "Roll No", attendance.rollno),
                SizedBox(height: 12),
                _buildDetailRow(Icons.subject_outlined, "Subject", attendance.subject),
                SizedBox(height: 12),
                _buildDetailRow(Icons.calendar_today_outlined, "Date", attendance.date),
                SizedBox(height: 12),
                _buildStatusDetailRow(attendance.status),

                SizedBox(height: 16),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Color(0xFFF1F5F9)),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: Color(0xFFF5F3FF),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: Color(0xFFE9E0FF)),
            ),
            child: Icon(
              icon,
              size: 16,
              color: Color(0xFF8B5CF6),
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF1E293B),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusDetailRow(String status) {
    Color statusColor = _getStatusColor(status);

    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: statusColor.withOpacity(0.05),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: statusColor.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: statusColor),
            ),
            child: Icon(
              status == "Present" ? Icons.check_circle_outline : Icons.cancel_outlined,
              size: 16,
              color: statusColor,
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Status",
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  status,
                  style: TextStyle(
                    fontSize: 14,
                    color: statusColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case "present":
        return Color(0xFF10B981); // Green
      case "absent":
        return Color(0xFFEF4444); // Red
      default:
        return Color(0xFF667EEA); // Blue
    }
  }
}

class Attendance {
  final String id;
  final String student;
  final String rollno;
  final String subject;
  final String date;
  final String status;

  Attendance(this.id, this.student, this.rollno, this.subject, this.date, this.status);
}








// import 'dart:convert';
//
// import 'package:college_connect/student/studenthome.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart'as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// class view_attendance extends StatelessWidget {
// const view_attendance({Key? key}) : super(key: key);
//
// @override
// Widget build(BuildContext context) {
// return MaterialApp(home:view_attendance_sub() ,);
// }
// }
//
// class  view_attendance_sub extends StatefulWidget {
// const view_attendance_sub({Key? key}) : super(key: key);
//
// @override
// State<view_attendance_sub> createState() => view_attendance_sub_State();
// }
//
// class view_attendance_sub_State extends State<view_attendance_sub> {
//   Future<List<Joke>> _getJokes() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     String b = prefs.getString("uid").toString();
//     String foodimage="";
//     var data =
//     await http.post(Uri.parse(prefs.getString("ip").toString()+"/view_attendance"),
//         body: {"id":b}
//     );
//
//     var jsonData = json.decode(data.body);
// //    print(jsonData);
//     List<Joke> jokes = [];
//     for (var joke in jsonData["data"]) {
//       print(joke);
//       Joke newJoke = Joke(
//           joke["id"].toString(),
//           joke["student"].toString(),
//           joke["rollno"].toString(),
//           joke["subject"].toString(),
//           joke["date"].toString(),
//           joke["status"].toString()
//       );
//       jokes.add(newJoke);
//     }
//     return jokes;
//   }
//
//   @override
// Widget build(BuildContext context) {
// return Scaffold(
//   appBar: AppBar(title: Text("Attendance"),centerTitle: true,leading: IconButton(onPressed: (){
//     Navigator.push(context, MaterialPageRoute(builder: (context)=>home()));
//   }, icon: Icon(Icons.arrow_back)),),
//   body:
//
//
//   Container(
//
//     child:
//     FutureBuilder(
//       future: _getJokes(),
//       builder: (BuildContext context, AsyncSnapshot snapshot) {
// //              print("snapshot"+snapshot.toString());
//         if (snapshot.data == null) {
//           return Container(
//             child: Center(
//               child: Text("Loading..."),
//             ),
//           );
//         } else {
//           return ListView.builder(
//             itemCount: snapshot.data.length,
//             itemBuilder: (BuildContext context, int index) {
//               var i = snapshot.data![index];
//               return Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: Card(
//                   elevation: 3,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(10),
//                     side: BorderSide(color: Colors.grey.shade300),
//                   ),
//                   child: Padding(
//                     padding: const EdgeInsets.all(16.0),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//
//                         SizedBox(height: 10),
//                         _buildRow("Id:", i.id.toString()),
//                         _buildRow("Student Name:", i.student.toString()),
//                         _buildRow("Roll Number:", i.rollno.toString()),
//                         _buildRow("Subject Name:", i.subject.toString()),
//                         _buildRow("Date:", i.date.toString()),
//                         _buildRow("Status:", i.status.toString()),
//
//
//                       ],
//                     ),
//                   ),
//                 ),
//               );
//             },
//           );
//
//
//         }
//       },
//
//
//     ),
//
//
//
//
//
//   ),
// );
// }
// }
// Widget _buildRow(String label, String value) {
//   return Padding(
//     padding: const EdgeInsets.symmetric(vertical: 4),
//     child: Row(
//       children: [
//         SizedBox(
//           width: 100,
//           child: Text(
//             label,
//             style: TextStyle(
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//         ),
//         SizedBox(width: 5),
//         Flexible(
//           child: Text(
//             value,
//             style: TextStyle(
//               color: Colors.grey.shade800,
//             ),
//           ),
//         ),
//       ],
//     ),
//   );
// }
//
// class Joke {
//   final String id;
//   final String student;
//   final String rollno;
//   final String subject;
//   final String date;
//   final String status;
//
//
//
//
//   Joke(this.id,this.student, this.rollno,this.subject,this.date,this.status);
// //  print("hiiiii");
// }