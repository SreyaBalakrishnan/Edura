import 'dart:convert';
import 'package:college_connect/student/studenthome.dart';
import 'package:college_connect/student/view_replies.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(sent_complaints());
}

class sent_complaints extends StatelessWidget {
  const sent_complaints({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: sent_complaints_sub(),
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Segoe UI',
      ),
    );
  }
}

class sent_complaints_sub extends StatefulWidget {
  const sent_complaints_sub({Key? key}) : super(key: key);

  @override
  State<sent_complaints_sub> createState() => _State();
}

class _State extends State<sent_complaints_sub> {
  TextEditingController complaint = TextEditingController();
  bool _isLoading = false;

  Future<void> _submitComplaint() async {
    if (complaint.text.trim().isEmpty) {
      _showSnackBar('Please enter your complaint');
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      print(prefs.getString("sid").toString());
      print(complaint.text);

      var data = await http.post(
        Uri.parse(prefs.getString("ip").toString() + "/sent_compliants"),
        body: {
          "complaint": complaint.text,
          'sid': prefs.getString("sid").toString()
        },
      );

      var decodedata = json.decode(data.body);

      if (decodedata['status'] == 'ok') {
        _showSuccessDialog();
      } else {
        _showSnackBar('Failed to submit complaint. Please try again.');
      }
    } catch (e) {
      _showSnackBar('Error: ${e.toString()}');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Color(0xFFEF4444),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        backgroundColor: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.check_rounded,
                  color: Colors.white,
                  size: 30,
                ),
              ),
              SizedBox(height: 20),
              Text(
                "Complaint Submitted",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF2D3748),
                ),
              ),
              SizedBox(height: 10),
              Text(
                "Your complaint has been successfully submitted.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF718096),
                  fontSize: 14,
                ),
              ),
              SizedBox(height: 25),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => home()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF667EEA),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    padding: EdgeInsets.symmetric(vertical: 14),
                    elevation: 0,
                  ),
                  child: Text(
                    "Back to Home",
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            width: MediaQuery.of(context).size.width * 0.9,
            constraints: BoxConstraints(maxWidth: 500),
            child: Column(
              children: [
                // Form Container
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.08),
                        blurRadius: 20,
                        offset: Offset(0, 5),
                      ),
                    ],
                    border: Border.all(
                      color: Color(0xFFE9ECEF),
                      width: 1,
                    ),
                  ),
                  child: Column(
                    children: [
                      // Form Header
                      Container(
                        padding: EdgeInsets.all(30),
                        decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(
                              color: Color(0xFFF1F3F5),
                              width: 1,
                            ),
                          ),
                        ),
                        child: Column(
                          children: [
                            Text(
                              "Submit Complaint",
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF2D3748),
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              "We're here to help resolve your concerns",
                              style: TextStyle(
                                color: Color(0xFF718096),
                                fontSize: 14,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Form Content
                      Padding(
                        padding: const EdgeInsets.all(30),
                        child: Column(
                          children: [
                            // Complaint Field
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Complaint Message",
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w500,
                                    color: Color(0xFF4A5568),
                                    letterSpacing: 0.3,
                                  ),
                                ),
                                SizedBox(height: 6),
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: Color(0xFFE2E8F0),
                                      width: 1,
                                    ),
                                  ),
                                  child: TextField(
                                    controller: complaint,
                                    maxLines: 6,
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Color(0xFF2D3748),
                                    ),
                                    decoration: InputDecoration(
                                      hintText: "Describe your complaint in detail...",
                                      hintStyle: TextStyle(
                                        color: Color(0xFFA0AEC0),
                                        fontSize: 13,
                                      ),
                                      border: InputBorder.none,
                                      contentPadding: EdgeInsets.all(16),
                                    ),
                                  ),
                                ),
                                SizedBox(height: 4),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text(
                                      "${complaint.text.length}/500",
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: complaint.text.length > 450
                                            ? Color(0xFFEF4444)
                                            : Color(0xFFA0AEC0),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),

                            SizedBox(height: 25),

                            // Submit Button
                            Material(
                              color: Colors.transparent,
                              child: InkWell(
                                onTap: _isLoading ? null : _submitComplaint,
                                borderRadius: BorderRadius.circular(8),
                                child: Container(
                                  width: double.infinity,
                                  padding: EdgeInsets.symmetric(vertical: 14),
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: _isLoading
                                          ? [Color(0xFFA0AEC0), Color(0xFF718096)]
                                          : [Color(0xFF667EEA), Color(0xFF764BA2)],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                    borderRadius: BorderRadius.circular(8),
                                    boxShadow: _isLoading
                                        ? []
                                        : [
                                      BoxShadow(
                                        color: Color(0xFF667EEA).withOpacity(0.2),
                                        blurRadius: 12,
                                        offset: Offset(0, 4),
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    child: _isLoading
                                        ? SizedBox(
                                      width: 20,
                                      height: 20,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Colors.white,
                                      ),
                                    )
                                        : Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.send_rounded,
                                          color: Colors.white,
                                          size: 16,
                                        ),
                                        SizedBox(width: 8),
                                        Text(
                                          "Send Complaint",
                                          style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.white,
                                            letterSpacing: 0.5,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),

                            SizedBox(height: 10),

                            // Back Link
                            Material(
                              color: Colors.transparent,
                              child: InkWell(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (context) => view_replies()),
                                  );
                                },
                                borderRadius: BorderRadius.circular(6),
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                    vertical: 8,
                                    horizontal: 12,
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.arrow_back_ios_new_rounded,
                                        color: Color(0xFF667EEA),
                                        size: 14,
                                      ),
                                      SizedBox(width: 6),
                                      Text(
                                        "Back to Previous Complaints",
                                        style: TextStyle(
                                          color: Color(0xFF667EEA),
                                          fontSize: 13,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                // Responsive spacing
                SizedBox(height: MediaQuery.of(context).size.height * 0.05),
              ],
            ),
          ),
        ),
      ),
    );
  }
}







// import 'dart:convert';
//
// import 'package:college_connect/student/studenthome.dart';
// import 'package:college_connect/student/view_replies.dart';
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:http/http.dart'as http;
// void main(){
//   runApp(sent_complaints());
// }
// class  sent_complaints extends StatelessWidget {
// const sent_complaints({Key? key}) : super(key: key);
//
// @override
// Widget build(BuildContext context) {
// return MaterialApp(home:sent_complaints_sub() ,);
// }
// }
//
// class sent_complaints_sub extends StatefulWidget {
// const sent_complaints_sub({Key? key}) : super(key: key);
//
// @override
// State<sent_complaints_sub> createState() => _State();
// }
//
// class _State extends State<sent_complaints_sub> {
//   TextEditingController complaint=TextEditingController();
//
//   @override
// Widget build(BuildContext context) {
// return Scaffold( appBar: AppBar(title: Text("Complaint"),centerTitle: true,leading: IconButton(onPressed: (){
//   Navigator.push(context, MaterialPageRoute(builder: (context)=>view_replies()));
// }, icon: Icon(Icons.arrow_back)),),
//     body: Center(child: Column(children: [
//       SizedBox(height: 30,),
//       SizedBox(height: 40,width: 300,child: TextField(controller: complaint,
//         decoration: InputDecoration(border: OutlineInputBorder(),labelText: "Complaint"),
//       ),),
//       ElevatedButton(onPressed: () async {
//         SharedPreferences prefs= await SharedPreferences.getInstance();
//         print(prefs.getString("sid").toString());
//         print(complaint.text);
//         var data =
//         await http.post(Uri.parse(prefs.getString("ip").toString()+"/sent_compliants"),
//             body: {"complaint":complaint.text,'sid':prefs.getString("sid").toString()}
//         );
//         var decodedata=json.decode(data.body);
//         if(decodedata['status']=='ok'){
//           Navigator.push(context, MaterialPageRoute(builder: (context)=>home()));
//         }
//
//
//       }, child: Text("Send"))
//
//     ],),)
// );
//   }
// }