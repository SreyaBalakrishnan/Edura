import 'dart:convert';
import 'package:college_connect/student/studenthome.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(profile());
}

class profile extends StatelessWidget {
  const profile({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: profile_sub(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class profile_sub extends StatefulWidget {
  const profile_sub({Key? key}) : super(key: key);

  @override
  State<profile_sub> createState() => _State();
}

class _State extends State<profile_sub> {
  Future<List<Joke>> _getJokes() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String b = prefs.getString("uid").toString();
    String foodimage = "";
    var data = await http.post(
      Uri.parse(prefs.getString("ip").toString() + "/usr_view_profile"),
      body: {"sid": prefs.getString("sid").toString()},
    );

    var jsonData = json.decode(data.body);
    List<Joke> jokes = [];
    for (var joke in jsonData["data"]) {
      print(joke);
      Joke newJoke = Joke(
        joke["id"].toString(),
        joke["name"].toString(),
        joke["rollno"].toString(),
        joke["course"].toString(),
        joke["year"].toString(),
        joke["semester"].toString(),
        joke["number"].toString(),
        joke["email"].toString(),
      );
      jokes.add(newJoke);
    }
    return jokes;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8FAFC),
      body: SafeArea(
        child: FutureBuilder(
          future: _getJokes(),
          builder: (BuildContext context, AsyncSnapshot snapshot) {
            if (snapshot.data == null) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(
                      color: Color(0xFF667EEA),
                    ),
                    SizedBox(height: 16),
                    Text(
                      "Loading Profile...",
                      style: TextStyle(
                        fontSize: 14,
                        color: Color(0xFF64748B),
                      ),
                    ),
                  ],
                ),
              );
            } else {
              return ListView.builder(
                itemCount: snapshot.data.length,
                itemBuilder: (BuildContext context, int index) {
                  var i = snapshot.data![index];
                  return _buildProfileCard(i);
                },
              );
            }
          },
        ),
      ),
    );
  }

  Widget _buildProfileCard(Joke student) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          // Header with Back Button
          Container(
            margin: EdgeInsets.only(bottom: 24),
            child: Row(
              children: [
                InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => home()),
                    );
                  },
                  borderRadius: BorderRadius.circular(8),
                  child: Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Color(0xFFE2E8F0)),
                    ),
                    child: Icon(
                      Icons.arrow_back_rounded,
                      size: 20,
                      color: Color(0xFF4A5568),
                    ),
                  ),
                ),
                SizedBox(width: 12),
                Text(
                  "My Profile",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF2D3748),
                  ),
                ),
              ],
            ),
          ),

          // Profile Header Card
          Container(
            padding: EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Color(0xFF667EEA).withOpacity(0.2),
                  blurRadius: 20,
                  offset: Offset(0, 8),
                ),
              ],
            ),
            child: Column(
              children: [
                // Profile Icon
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(40),
                    border: Border.all(color: Colors.white, width: 4),
                  ),
                  child: Icon(
                    Icons.person_rounded,
                    size: 40,
                    color: Color(0xFF667EEA),
                  ),
                ),
                SizedBox(height: 16),
                Text(
                  student.name,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  student.course,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.white.withOpacity(0.9),
                  ),
                ),
                SizedBox(height: 8),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    "ID: ${student.id}",
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 24),

          // Details Card
          Container(
            padding: EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 8,
                  offset: Offset(0, 2),
                ),
              ],
              border: Border.all(color: Color(0xFFE2E8F0)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Section Header
                Row(
                  children: [
                    Icon(
                      Icons.school_rounded,
                      size: 18,
                      color: Color(0xFF667EEA),
                    ),
                    SizedBox(width: 8),
                    Text(
                      "Academic Details",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF1E293B),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20),

                // Details Grid
                _buildDetailItem("Roll Number", student.rollno, Icons.badge_rounded),
                _buildDetailItem("Course", student.course, Icons.menu_book_rounded),
                _buildDetailItem("Year", student.year, Icons.calendar_today_rounded),
                _buildDetailItem("Semester", student.semester, Icons.layers_rounded),

                SizedBox(height: 24),

                // Contact Header
                Row(
                  children: [
                    Icon(
                      Icons.contact_page_rounded,
                      size: 18,
                      color: Color(0xFF667EEA),
                    ),
                    SizedBox(width: 8),
                    Text(
                      "Contact Information",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF1E293B),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20),

                _buildDetailItem("Phone", student.number, Icons.phone_rounded),
                _buildDetailItem("Email", student.email, Icons.email_rounded),

                SizedBox(height: 24),

                // Student Status Badge
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Color(0xFFF0F9FF),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Color(0xFFBAE6FD)),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.verified_rounded,
                        size: 20,
                        color: Color(0xFF0284C7),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Active Student",
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF0C4A6E),
                              ),
                            ),
                            SizedBox(height: 2),
                            Text(
                              "Full-time enrolled student",
                              style: TextStyle(
                                fontSize: 12,
                                color: Color(0xFF0284C7),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 32),

          // Footer
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Color(0xFFF1F5F9),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Color(0xFFE2E8F0)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.security_rounded,
                  size: 14,
                  color: Color(0xFF64748B),
                ),
                SizedBox(width: 8),
                Text(
                  "Secure Student Profile • Edura Portal",
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: Color(0xFF64748B),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailItem(String label, String value, IconData icon) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Color(0xFFE2E8F0)),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: Color(0xFF667EEA).withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              size: 18,
              color: Color(0xFF667EEA),
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 15,
                    color: Color(0xFF1E293B),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class Joke {
  final String id;
  final String name;
  final String rollno;
  final String course;
  final String year;
  final String semester;
  final String number;
  final String email;

  Joke(this.id, this.name, this.rollno, this.course, this.year, this.semester,
      this.number, this.email);
}








// import 'dart:convert';
//
// import 'package:college_connect/student/studenthome.dart';
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:http/http.dart'as http;
//
// void main(){
//   runApp(profile());
// }
// class profile extends StatelessWidget {
// const profile({Key? key}) : super(key: key);
//
// @override
// Widget build(BuildContext context) {
// return MaterialApp(home: profile_sub(),);
// }
// }
//
// class profile_sub extends StatefulWidget {
// const profile_sub({Key? key}) : super(key: key);
//
// @override
// State<profile_sub> createState() => _State();
// }
//
// class _State extends State<profile_sub> {
//   Future<List<Joke>> _getJokes() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     String b = prefs.getString("uid").toString();
//     String foodimage="";
//     var data =
//     await http.post(Uri.parse(prefs.getString("ip").toString()+"/usr_view_profile"),
//         body: {"sid":prefs.getString("sid").toString()}
//     );
//
//     var jsonData = json.decode(data.body);
// //    print(jsonData);
//     List<Joke> jokes = [];
//     for (var joke in jsonData["data"]) {
//       print(joke);
//       Joke newJoke = Joke(
//           joke["id"].toString(),
//           joke["name"].toString(),
//           joke["rollno"].toString(),
//           joke["course"].toString(),
//           joke["year"].toString(),
//           joke["semester"].toString(),
//           joke["number"].toString(),
//           joke["email"].toString()
//
//       );
//       jokes.add(newJoke);
//     }
//     return jokes;
//   }
// @override
// Widget build(BuildContext context) {
// return Scaffold(
//   appBar: AppBar(title: Text("My Profile"),centerTitle: true,leading: IconButton(onPressed: (){
//     Navigator.push(context, MaterialPageRoute(builder: (context)=>home()));
//   }, icon: Icon(Icons.arrow_back)),),
//   body:
//
//
// Container(
//
//   child:
//   FutureBuilder(
//     future: _getJokes(),
//     builder: (BuildContext context, AsyncSnapshot snapshot) {
// //              print("snapshot"+snapshot.toString());
//       if (snapshot.data == null) {
//         return Container(
//           child: Center(
//             child: Text("Loading..."),
//           ),
//         );
//       } else {
//         return ListView.builder(
//           itemCount: snapshot.data.length,
//           itemBuilder: (BuildContext context, int index) {
//             var i = snapshot.data![index];
//             return Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: Card(
//                 elevation: 3,
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(10),
//                   side: BorderSide(color: Colors.grey.shade300),
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.all(16.0),
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//
//                       SizedBox(height: 10),
//                       _buildRow("Id:", i.id.toString()),
//                       _buildRow("Name:", i.name.toString()),
//                       _buildRow("Roll No:", i.rollno.toString()),
//                       _buildRow("Course:", i.course.toString()),
//                       _buildRow("Year:", i.year.toString()),
//                       _buildRow("Semester:", i.semester.toString()),
//                       _buildRow("Number:", i.number.toString()),
//                       _buildRow("Email:", i.email.toString()),
//                     ],
//                   ),
//                 ),
//               ),
//             );
//           },
//         );
//
//
//       }
//     },
//
//
//   ),
//
//
//
//
//
// ),
// );
// }
// }
// Widget _buildRow(String label, String value) {
//   return Padding(
//     padding: const EdgeInsets.symmetric(vertical: 4),
//     child: Row(
//       children: [
//         SizedBox(
//           width: 100,
//           child: Text(
//             label,
//             style: TextStyle(
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//         ),
//         SizedBox(width: 5),
//         Flexible(
//           child: Text(
//             value,
//             style: TextStyle(
//               color: Colors.grey.shade800,
//             ),
//           ),
//         ),
//       ],
//     ),
//   );
// }
//
// class Joke {
//   final String id;
//   final String name;
//   final String rollno;
//   final String course;
//   final String year;
//   final String semester;
//   final String number;
//   final String email ;
//
//
//
//
//
//
//   Joke(this.id,this.name, this.rollno,this.course,this.year,this.semester,this.number,this.email);
// //  print("hiiiii");
// }