import 'dart:convert';

import 'package:college_connect/student/studenthome.dart';
import 'package:college_connect/student/view_events.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class view_result_events extends StatelessWidget {
  const view_result_events({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: view_result_events_sub(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class view_result_events_sub extends StatefulWidget {
  const view_result_events_sub({Key? key}) : super(key: key);

  @override
  State<view_result_events_sub> createState() => view_result_events_sub_State();
}

class view_result_events_sub_State extends State<view_result_events_sub> {
  Future<List<Joke>> _getJokes() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String b = prefs.getString("uid").toString();
    String foodimage = "";
    var data = await http.post(
      Uri.parse(prefs.getString("ip").toString() + "/view_event_results"),
      body: {"id": b},
    );

    var jsonData = json.decode(data.body);
    List<Joke> jokes = [];
    for (var joke in jsonData["data"]) {
      print(joke);
      Joke newJoke = Joke(
        joke["id"].toString(),
        joke["event"].toString(),
        joke["student"].toString(),
        joke["status"].toString(),
        joke["result"].toString(),
      );
      jokes.add(newJoke);
    }
    return jokes;
  }

  Color _getResultColor(String result) {
    switch (result.toLowerCase()) {
      case "won":
      case "winner":
      case "1st prize":
      case "gold":
        return Color(0xFF10B981); // Green for winner (matches Completed)
      case "runner-up":
      case "2nd prize":
      case "silver":
      case "lost":
        return Color(0xFFF59E0B); // Amber for runner-up (matches Ongoing)
      case "participated":
      case "participant":
      case "3rd prize":
      case "bronze":
        return Color(0xFF667EEA); // Blue for participation (matches Upcoming)
      case "pending":
      case "processing":
        return Color(0xFF94A3B8); // Gray for pending
      default:
        return Color(0xFF667EEA); // Default blue
    }
  }

  IconData _getResultIcon(String result) {
    switch (result.toLowerCase()) {
      case "won":
      case "winner":
      case "1st prize":
      case "gold":
        return Icons.emoji_events_rounded;
      case "runner-up":
      case "2nd prize":
      case "silver":
        return Icons.star_half_rounded;
      case "participated":
      case "participant":
      case "3rd prize":
      case "bronze":
        return Icons.check_circle_outline;
      case "pending":
      case "processing":
        return Icons.hourglass_empty_rounded;
      default:
        return Icons.assignment_outlined;
    }
  }

  String _getResultLabel(String result) {
    switch (result.toLowerCase()) {
      case "won":
      case "winner":
      case "1st prize":
      case "gold":
        return "WINNER";
      case "runner-up":
      case "2nd prize":
      case "silver":
        return "RUNNER-UP";
      case "participated":
      case "participant":
      case "3rd prize":
      case "bronze":
        return "PARTICIPANT";
      case "pending":
      case "processing":
        return "PENDING";
      default:
        return result.toUpperCase();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFAFAFA),
      body: SafeArea(
        child: Column(
          children: [
            // Clean Header
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                  bottom: BorderSide(color: Color(0xFFE8E8E8), width: 1),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Color(0xFFF0F5FF),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                    ),
                    child: IconButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => view_events()),
                        );
                      },
                      icon: Icon(Icons.arrow_back_ios_new_rounded,
                          size: 16, color: Color(0xFF667EEA)),
                      padding: EdgeInsets.zero,
                    ),
                  ),
                  SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Event Results",
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF1E293B),
                          ),
                        ),
                        SizedBox(height: 4),
                        FutureBuilder<List<Joke>>(
                          future: _getJokes(),
                          builder: (context, snapshot) {
                            if (snapshot.connectionState == ConnectionState.waiting) {
                              return Text(
                                "Loading results...",
                                style: TextStyle(
                                  fontSize: 13,
                                  color: Color(0xFF64748B),
                                ),
                              );
                            } else if (snapshot.hasData) {
                              return Text(
                                "${snapshot.data!.length} result(s) found",
                                style: TextStyle(
                                  fontSize: 13,
                                  color: Color(0xFF64748B),
                                ),
                              );
                            }
                            return Container();
                          },
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Color(0xFF667EEA),
                          Color(0xFF764BA2),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xFF667EEA).withOpacity(0.3),
                          blurRadius: 8,
                          offset: Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Icon(
                      Icons.emoji_events_outlined,
                      size: 22,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),

            // Results List
            Expanded(
              child: FutureBuilder<List<Joke>>(
                future: _getJokes(),
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 28,
                            height: 28,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFF667EEA),
                            ),
                          ),
                          SizedBox(height: 16),
                          Text(
                            "Loading Results...",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    );
                  }

                  if (snapshot.hasError) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Color(0xFFF5F3FF),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE9E0FF),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              Icons.error_outline_rounded,
                              size: 36,
                              color: Color(0xFF8B5CF6),
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            "Error Loading Results",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            "Please check your connection",
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          SizedBox(height: 16),
                          TextButton(
                            onPressed: () {
                              setState(() {});
                            },
                            style: TextButton.styleFrom(
                              foregroundColor: Color(0xFF667EEA),
                            ),
                            child: Text("Retry"),
                          ),
                        ],
                      ),
                    );
                  }

                  if (snapshot.data == null || snapshot.data!.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 100,
                            height: 100,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Color(0xFFF0F5FF),
                                  Color(0xFFF5F3FF),
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFFE0E7FF),
                                width: 2,
                              ),
                            ),
                            child: Icon(
                              Icons.emoji_events_outlined,
                              size: 48,
                              color: Color(0xFF667EEA),
                            ),
                          ),
                          SizedBox(height: 24),
                          Text(
                            "No Results Yet",
                            style: TextStyle(
                              fontSize: 18,
                              color: Color(0xFF1E293B),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 12),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 40),
                            child: Text(
                              "Your event results will appear here once they are published by the organizers.",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 14,
                                color: Color(0xFF64748B),
                                height: 1.5,
                              ),
                            ),
                          ),
                          SizedBox(height: 24),
                          Container(
                            width: 200,
                            height: 44,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: Color(0xFFE2E8F0), width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.05),
                                  blurRadius: 4,
                                  offset: Offset(0, 2),
                                ),
                              ],
                            ),
                            child: TextButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => view_events()),
                                );
                              },
                              style: TextButton.styleFrom(
                                foregroundColor: Color(0xFF334155),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.event_outlined, size: 18),
                                  SizedBox(width: 8),
                                  Text(
                                    "View Events",
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  }

                  return ListView.builder(
                    padding: EdgeInsets.all(16),
                    itemCount: snapshot.data.length,
                    itemBuilder: (BuildContext context, int index) {
                      var result = snapshot.data![index];
                      Color resultColor = _getResultColor(result.result);

                      return Container(
                        margin: EdgeInsets.only(bottom: 16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: Color(0xFFE8E8E8), width: 1),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.02),
                              blurRadius: 6,
                              offset: Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Result Header with Icon
                            Padding(
                              padding: EdgeInsets.all(20),
                              child: Row(
                                children: [
                                  Container(
                                    width: 60,
                                    height: 60,
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [
                                          resultColor.withOpacity(0.2),
                                          resultColor.withOpacity(0.1),
                                        ],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                      ),
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(
                                        color: resultColor.withOpacity(0.3),
                                        width: 2,
                                      ),
                                    ),
                                    child: Icon(
                                      _getResultIcon(result.result),
                                      size: 30,
                                      color: resultColor,
                                    ),
                                  ),
                                  SizedBox(width: 16),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          result.event,
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600,
                                            color: Color(0xFF1E293B),
                                          ),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        SizedBox(height: 8),
                                        Container(
                                          padding: EdgeInsets.symmetric(
                                            horizontal: 12,
                                            vertical: 6,
                                          ),
                                          decoration: BoxDecoration(
                                            color: resultColor.withOpacity(0.1),
                                            borderRadius: BorderRadius.circular(8),
                                            border: Border.all(
                                              color: resultColor,
                                              width: 1,
                                            ),
                                          ),
                                          child: Text(
                                            _getResultLabel(result.result),
                                            style: TextStyle(
                                              fontSize: 12,
                                              color: resultColor,
                                              fontWeight: FontWeight.w600,
                                              letterSpacing: 0.5,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            Divider(
                              height: 1,
                              color: Color(0xFFF1F5F9),
                            ),

                            // Result Details
                            Padding(
                              padding: EdgeInsets.all(20),
                              child: Column(
                                children: [
                                  // ID Badge
                                  Container(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 12,
                                      vertical: 8,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Color(0xFFF8FAFC),
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(color: Color(0xFFF1F5F9)),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(
                                          Icons.fingerprint_outlined,
                                          size: 14,
                                          color: Color(0xFF64748B),
                                        ),
                                        SizedBox(width: 8),
                                        Text(
                                          "Result ID: ${result.id}",
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: Color(0xFF64748B),
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  SizedBox(height: 20),

                                  // Details Grid
                                  Container(
                                    padding: EdgeInsets.all(16),
                                    decoration: BoxDecoration(
                                      color: Color(0xFFF8FAFC),
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                        color: Color(0xFFE2E8F0),
                                        width: 1,
                                      ),
                                    ),
                                    child: Column(
                                      children: [
                                        _buildDetailItem(
                                          Icons.event_outlined,
                                          "Event Name",
                                          result.event,
                                          Color(0xFF8B5CF6),
                                        ),
                                        SizedBox(height: 12),
                                        _buildDetailItem(
                                          Icons.person_outline,
                                          "Student",
                                          result.student,
                                          Color(0xFF667EEA),
                                        ),
                                        SizedBox(height: 12),
                                        _buildDetailItem(
                                          Icons.info_outline,
                                          "Status",
                                          result.status,
                                          Color(0xFFF59E0B),
                                        ),
                                        SizedBox(height: 12),

                                        // Final Result Card - Updated with event status colors
                                        Container(
                                          padding: EdgeInsets.all(16),
                                          decoration: BoxDecoration(
                                            color: resultColor.withOpacity(0.05),
                                            borderRadius: BorderRadius.circular(10),
                                            border: Border.all(
                                              color: resultColor.withOpacity(0.3),
                                              width: 1.5,
                                            ),
                                            boxShadow: [
                                              BoxShadow(
                                                color: resultColor.withOpacity(0.1),
                                                blurRadius: 4,
                                                offset: Offset(0, 2),
                                              ),
                                            ],
                                          ),
                                          child: Row(
                                            children: [
                                              Container(
                                                width: 44,
                                                height: 44,
                                                decoration: BoxDecoration(
                                                  color: resultColor.withOpacity(0.15),
                                                  borderRadius:
                                                  BorderRadius.circular(10),
                                                  border: Border.all(
                                                    color: resultColor,
                                                    width: 2,
                                                  ),
                                                ),
                                                child: Icon(
                                                  _getResultIcon(result.result),
                                                  size: 22,
                                                  color: resultColor,
                                                ),
                                              ),
                                              SizedBox(width: 16),
                                              Expanded(
                                                child: Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                                  children: [
                                                    Text(
                                                      "FINAL RESULT",
                                                      style: TextStyle(
                                                        fontSize: 11,
                                                        color: Color(0xFF64748B),
                                                        fontWeight: FontWeight.w600,
                                                        letterSpacing: 1,
                                                      ),
                                                    ),
                                                    SizedBox(height: 6),
                                                    Text(
                                                      result.result.toUpperCase(),
                                                      style: TextStyle(
                                                        fontSize: 18,
                                                        color: resultColor,
                                                        fontWeight: FontWeight.w700,
                                                        letterSpacing: 0.5,
                                                      ),
                                                    ),
                                                    SizedBox(height: 4),
                                                    Container(
                                                      padding: EdgeInsets.symmetric(
                                                        horizontal: 10,
                                                        vertical: 4,
                                                      ),
                                                      decoration: BoxDecoration(
                                                        color: resultColor.withOpacity(0.1),
                                                        borderRadius: BorderRadius.circular(6),
                                                        border: Border.all(
                                                          color: resultColor.withOpacity(0.3),
                                                        ),
                                                      ),
                                                      child: Text(
                                                        _getResultTypeText(result.result),
                                                        style: TextStyle(
                                                          fontSize: 11,
                                                          color: resultColor,
                                                          fontWeight: FontWeight.w500,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailItem(IconData icon, String label, String value, Color color) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Color(0xFFF1F5F9)),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: color.withOpacity(0.3)),
            ),
            child: Icon(
              icon,
              size: 18,
              color: color,
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF1E293B),
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _getResultTypeText(String result) {
    switch (result.toLowerCase()) {
      case "won":
      case "winner":
      case "1st prize":
      case "gold":
        return "🏆 First Position";
      case "runner-up":
      case "2nd prize":
      case "silver":
      case "lost":
        return "🥈 Second Position";
      case "participated":
      case "participant":
      case "3rd prize":
      case "bronze":
        return "🥉 Participated";
      case "pending":
      case "processing":
        return "⏳ Awaiting Result";
      default:
        return "📋 Result Declared";
    }
  }
}

class Joke {
  final String id;
  final String event;
  final String student;
  final String status;
  final String result;

  Joke(this.id, this.event, this.student, this.status, this.result);
}








// import 'dart:convert';
//
// import 'package:college_connect/student/studenthome.dart';
// import 'package:college_connect/student/view_events.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart'as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// class view_result_events extends StatelessWidget {
// const view_result_events({Key? key}) : super(key: key);
//
// @override
// Widget build(BuildContext context) {
// return MaterialApp(home:view_result_events_sub() ,);
// }
// }
//
// class view_result_events_sub extends StatefulWidget {
// const view_result_events_sub({Key? key}) : super(key: key);
//
// @override
// State<view_result_events_sub> createState() => view_result_events_sub_State();
// }
//
// class view_result_events_sub_State extends State<view_result_events_sub> {
//   Future<List<Joke>> _getJokes() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     String b = prefs.getString("uid").toString();
//     String foodimage="";
//     var data =
//     await http.post(Uri.parse(prefs.getString("ip").toString()+"/view_event_results"),
//         body: {"id":b}
//     );
//
//     var jsonData = json.decode(data.body);
// //    print(jsonData);
//     List<Joke> jokes = [];
//     for (var joke in jsonData["data"]) {
//       print(joke);
//       Joke newJoke = Joke(
//           joke["id"].toString(),
//           joke["event"].toString(),
//           joke["student"].toString(),
//           joke["status"].toString(),
//           joke["result"].toString()
//       );
//       jokes.add(newJoke);
//     }
//     return jokes;
//   }
// @override
// Widget build(BuildContext context) {
// return Scaffold(
//   appBar: AppBar(title: Text("Results"),centerTitle: true,leading: IconButton(onPressed: (){
//     Navigator.push(context, MaterialPageRoute(builder: (context)=>view_events()));
//   }, icon: Icon(Icons.arrow_back)),),
//   body:
//
//
//   Container(
//
//     child:
//     FutureBuilder(
//       future: _getJokes(),
//       builder: (BuildContext context, AsyncSnapshot snapshot) {
// //              print("snapshot"+snapshot.toString());
//         if (snapshot.data == null) {
//           return Container(
//             child: Center(
//               child: Text("Loading..."),
//             ),
//           );
//         } else {
//           return ListView.builder(
//             itemCount: snapshot.data.length,
//             itemBuilder: (BuildContext context, int index) {
//               var i = snapshot.data![index];
//               return Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: Card(
//                   elevation: 3,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(10),
//                     side: BorderSide(color: Colors.grey.shade300),
//                   ),
//                   child: Padding(
//                     padding: const EdgeInsets.all(16.0),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//
//                         SizedBox(height: 10),
//                         _buildRow("Id:", i.id.toString()),
//                         _buildRow("Event :", i.event.toString()),
//                         _buildRow("Student:", i.student.toString()),
//                         _buildRow("Status:", i.status.toString()),
//                         _buildRow("Result:", i.result.toString()),
//
//                       ],
//                     ),
//                   ),
//                 ),
//               );
//             },
//           );
//
//
//         }
//       },
//
//
//     ),
//
//
//
//
//
//   ),
// );
// }
// }
// Widget _buildRow(String label, String value) {
//   return Padding(
//     padding: const EdgeInsets.symmetric(vertical: 4),
//     child: Row(
//       children: [
//         SizedBox(
//           width: 100,
//           child: Text(
//             label,
//             style: TextStyle(
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//         ),
//         SizedBox(width: 5),
//         Flexible(
//           child: Text(
//             value,
//             style: TextStyle(
//               color: Colors.grey.shade800,
//             ),
//           ),
//         ),
//       ],
//     ),
//   );
// }
//
// class Joke {
//   final String id;
//   final String event;
//
//   final String student;
//   final String status;
//   final String result;
//
//
//
//
//   Joke(this.id,this.event, this.student,this.status,this.result);
// //  print("hiiiii");
// }