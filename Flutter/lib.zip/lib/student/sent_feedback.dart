import 'dart:convert';
import 'package:college_connect/student/studenthome.dart';
import 'package:college_connect/student/view_faculty.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(sent_feedback());
}

class sent_feedback extends StatelessWidget {
  const sent_feedback({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: sent_feedback_sub(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class sent_feedback_sub extends StatefulWidget {
  const sent_feedback_sub({Key? key}) : super(key: key);

  @override
  State<sent_feedback_sub> createState() => _State();
}

class _State extends State<sent_feedback_sub> {
  TextEditingController feedback = TextEditingController();
  bool _isLoading = false;
  String _errorMessage = '';

  Future<void> _submitFeedback() async {
    if (feedback.text.trim().isEmpty) {
      setState(() {
        _errorMessage = 'Please enter your feedback';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      var data = await http.post(
        Uri.parse(prefs.getString("ip").toString() + "/sent_feedback"),
        body: {
          "feedback": feedback.text,
          'fid': prefs.getString("facultyid").toString(),
          'sid': prefs.getString("sid").toString()
        },
      );

      var decodedata = json.decode(data.body);
      if (decodedata['status'] == 'ok') {
        _showSuccessDialog();
      } else {
        setState(() {
          _errorMessage = 'Failed to send feedback. Please try again.';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Error: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        backgroundColor: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: Color(0xFF10B981).withOpacity(0.1),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Color(0xFF10B981),
                    width: 2,
                  ),
                ),
                child: Icon(
                  Icons.check_circle_outline_rounded,
                  color: Color(0xFF10B981),
                  size: 32,
                ),
              ),
              SizedBox(height: 20),
              Text(
                "Feedback Sent!",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF1E293B),
                ),
              ),
              SizedBox(height: 12),
              Text(
                "Thank you for your valuable feedback.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF64748B),
                  fontSize: 14,
                ),
              ),
              SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => view_faculty()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF10B981),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    padding: EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: Text(
                    "Back to Faculty",
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFAFAFA),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Clean Minimal Header
              Container(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border(
                    bottom: BorderSide(color: Color(0xFFE8E8E8), width: 1),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.03),
                      blurRadius: 6,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Color(0xFFF0F5FF),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                      ),
                      child: IconButton(
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (context) => view_faculty()),
                          );
                        },
                        icon: Icon(Icons.arrow_back_ios_new_rounded,
                            size: 16, color: Color(0xFF667EEA)),
                        padding: EdgeInsets.zero,
                      ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Send Feedback",
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF1E293B),
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            "Share your thoughts with the faculty",
                            style: TextStyle(
                              fontSize: 13,
                              color: Color(0xFF64748B),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: Color(0xFFF0F5FF),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Color(0xFFE0E7FF), width: 1),
                      ),
                      child: Icon(
                        Icons.feedback_outlined,
                        size: 22,
                        color: Color(0xFF667EEA),
                      ),
                    ),
                  ],
                ),
              ),

              // Form Content
              Padding(
                padding: EdgeInsets.all(24),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Color(0xFFE8E8E8), width: 1),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.02),
                        blurRadius: 6,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Feedback Field
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.message_outlined,
                                  size: 16,
                                  color: Color(0xFF667EEA),
                                ),
                                SizedBox(width: 8),
                                Text(
                                  "Your Feedback",
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    color: Color(0xFF1E293B),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 8),
                            Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: Color(0xFFE2E8F0)),
                              ),
                              child: TextField(
                                controller: feedback,
                                maxLines: 6,
                                style: TextStyle(
                                  fontSize: 15,
                                  color: Color(0xFF1E293B),
                                ),
                                decoration: InputDecoration(
                                  hintText: "Write your feedback here...\n\n• Teaching methods\n• Course content\n• Communication style\n• Suggestions for improvement",
                                  hintStyle: TextStyle(
                                    color: Color(0xFF94A3B8),
                                    fontSize: 14,
                                    height: 1.5,
                                  ),
                                  border: InputBorder.none,
                                  contentPadding: EdgeInsets.all(16),
                                ),
                              ),
                            ),
                            SizedBox(height: 8),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(
                                  "${feedback.text.length}/500 characters",
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: feedback.text.length > 450
                                        ? Color(0xFFEF4444)
                                        : Color(0xFF64748B),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),

                        // Error Message
                        if (_errorMessage.isNotEmpty) ...[
                          SizedBox(height: 20),
                          Container(
                            padding: EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Color(0xFFFEF2F2),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Color(0xFFFECACA)),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.error_outline_rounded,
                                  color: Color(0xFFDC2626),
                                  size: 16,
                                ),
                                SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    _errorMessage,
                                    style: TextStyle(
                                      fontSize: 13,
                                      color: Color(0xFFDC2626),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],

                        SizedBox(height: 32),

                        // Guidelines
                        Container(
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Color(0xFFF0F9FF),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: Color(0xFFBAE6FD),
                              width: 1.5,
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.lightbulb_outline_rounded,
                                    color: Color(0xFF0EA5E9),
                                    size: 16,
                                  ),
                                  SizedBox(width: 8),
                                  Text(
                                    "Feedback Guidelines",
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Color(0xFF0369A1),
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 8),
                              Text(
                                "• Be constructive and specific\n• Focus on teaching and course aspects\n• Provide actionable suggestions\n• Maintain respectful tone\n• Your feedback helps improve teaching quality",
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Color(0xFF0C4A6E),
                                  height: 1.5,
                                ),
                              ),
                            ],
                          ),
                        ),

                        SizedBox(height: 32),

                        // Submit Button
                        Container(
                          width: double.infinity,
                          height: 52,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            gradient: LinearGradient(
                              colors: [
                                Color(0xFF667EEA),
                                Color(0xFF8B5CF6),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF667EEA).withOpacity(0.3),
                                blurRadius: 10,
                                offset: Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Material(
                            color: Colors.transparent,
                            borderRadius: BorderRadius.circular(12),
                            child: InkWell(
                              borderRadius: BorderRadius.circular(12),
                              onTap: _isLoading ? null : _submitFeedback,
                              child: Center(
                                child: _isLoading
                                    ? SizedBox(
                                  width: 24,
                                  height: 24,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                                    : Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.send_outlined,
                                      size: 20,
                                      color: Colors.white,
                                    ),
                                    SizedBox(width: 10),
                                    Text(
                                      "Send Feedback",
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),

                        SizedBox(height: 16),
                        Align(
                          alignment: Alignment.centerRight,
                          child: Text(
                            "Your feedback is anonymous and confidential",
                            style: TextStyle(
                              fontSize: 11,
                              color: Color(0xFF94A3B8),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}








// import 'dart:convert';
//
// import 'package:college_connect/student/studenthome.dart';
// import 'package:college_connect/student/view_faculty.dart';
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:http/http.dart'as http;
// void main(){
//   runApp(sent_feedback());
// }
// class  sent_feedback extends StatelessWidget {
// const sent_feedback({Key? key}) : super(key: key);
//
// @override
// Widget build(BuildContext context) {
// return MaterialApp(home: sent_feedback_sub(),);
// }
// }
//
// class sent_feedback_sub extends StatefulWidget {
// const sent_feedback_sub({Key? key}) : super(key: key);
//
// @override
// State<sent_feedback_sub> createState() => _State();
// }
//
// class _State extends State<sent_feedback_sub> {
//   TextEditingController feedback=TextEditingController();
//   @override
// Widget build(BuildContext context) {
// return Scaffold(
//   appBar: AppBar(title: Text("Feedback"),centerTitle: true,leading: IconButton(onPressed: (){
//     Navigator.push(context, MaterialPageRoute(builder: (context)=>view_faculty()));
//   }, icon: Icon(Icons.arrow_back)),),
//   body: Center(child: Column(children: [
//   SizedBox(height: 30,),
//     SizedBox(height: 40,width: 300,child: TextField(controller: feedback,
//       decoration: InputDecoration(border: OutlineInputBorder(),labelText: "Feedback"),
//     ),),
//   ElevatedButton(onPressed: () async {
//     SharedPreferences prefs= await SharedPreferences.getInstance();
//     var data =
//         await http.post(Uri.parse(prefs.getString("ip").toString()+"/sent_feedback"),
//         body: {"feedback":feedback.text,'fid':prefs.getString("facultyid").toString(),'sid':prefs.getString("sid").toString()}
//     );
//     var decodedata=json.decode(data.body);
//     if(decodedata['status']=='ok'){
//       Navigator.push(context, MaterialPageRoute(builder: (context)=>view_faculty()));
//     }
//
//
//   }, child: Text("Send"))
//
//   ],),)
// );
// }
// }