import 'package:flutter/material.dart';


class  ai_lecturenotes extends StatelessWidget {
  const ai_lecturenotes({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(home:ai_lecturenotes_sub(),);
  }
}

class  ai_lecturenotes_sub extends StatefulWidget {
  const ai_lecturenotes_sub({Key? key}) : super(key: key);

  @override
  State<ai_lecturenotes_sub> createState() => _State();
}

class _State extends State<ai_lecturenotes_sub> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}

