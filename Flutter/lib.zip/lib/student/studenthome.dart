import 'package:college_connect/login.dart';
import 'package:college_connect/student/ai_lecturenotes.dart';
import 'package:college_connect/student/chatbot.dart';
import 'package:college_connect/student/view_group.dart';
import 'package:college_connect/student/profile.dart';
import 'package:college_connect/student/sent_complaints.dart';
import 'package:college_connect/student/sent_feedback.dart';
import 'package:college_connect/student/verify_request_notes.dart';
import 'package:college_connect/student/view_approved_request.dart';
import 'package:college_connect/student/view_assignments.dart';
import 'package:college_connect/student/view_attendance.dart';
import 'package:college_connect/student/view_events.dart';
import 'package:college_connect/student/view_faculty.dart';
import 'package:college_connect/student/view_intmark.dart';
import 'package:college_connect/student/view_materials.dart';
import 'package:college_connect/student/view_my_previousnotes.dart';
import 'package:college_connect/student/view_notification.dart';
import 'package:college_connect/student/view_ordered_previousnotes.dart';
import 'package:college_connect/student/view_others_previousnotes.dart';
import 'package:college_connect/student/view_replies.dart';
import 'package:college_connect/student/view_request_notes.dart';
import 'package:college_connect/student/view_subject.dart';
import 'package:flutter/material.dart';
import 'package:college_connect/student/chat.dart';

class home extends StatelessWidget {
  const home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: home_sub(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class home_sub extends StatefulWidget {
  const home_sub({Key? key}) : super(key: key);

  @override
  State<home_sub> createState() => _home_subState();
}

class _home_subState extends State<home_sub> {
  final List<DrawerItem> _drawerItems = [
    DrawerItem(
      title: "View Profile",
      icon: Icons.person_outline,
      route: () => profile(),
      color: Color(0xFF667EEA),
    ),
    DrawerItem(
      title: "View Subject",
      icon: Icons.menu_book_outlined,
      route: () => view_subject(),
      color: Color(0xFF8B5CF6),
    ),
    DrawerItem(
      title: "View Faculty",
      icon: Icons.school_outlined,
      route: () => view_faculty(),
      color: Color(0xFF667EEA),
    ),
    DrawerItem(
      title: "View Materials",
      icon: Icons.library_books_outlined,
      route: () => view_materials(),
      color: Color(0xFF8B5CF6),
    ),
    DrawerItem(
      title: "View Assignments",
      icon: Icons.assignment_outlined,
      route: () => view_assignments(),
      color: Color(0xFF667EEA),
    ),
    DrawerItem(
      title: "View Attendance",
      icon: Icons.calendar_today_outlined,
      route: () => view_attendance(),
      color: Color(0xFF8B5CF6),
    ),
    DrawerItem(
      title: "View Internal Marks",
      icon: Icons.grading_outlined,
      route: () => view_intmarks(),
      color: Color(0xFF667EEA),
    ),
    DrawerItem(
      title: "View Events & Results",
      icon: Icons.event_outlined,
      route: () => view_events(),
      color: Color(0xFF8B5CF6),
    ),
    DrawerItem(
      title: "ChatBot",
      icon: Icons.smart_toy_outlined,
      route: () => MyChatBotApp(),
      color: Color(0xFF667EEA),
    ),
    DrawerItem(
      title: "Sent Complaints",
      icon: Icons.report_problem_outlined,
      route: () => sent_complaints(),
      color: Color(0xFF8B5CF6),
    ),
    DrawerItem(
      title: "View Replies",
      icon: Icons.question_answer_outlined,
      route: () => view_replies(),
      color: Color(0xFF667EEA),
    ),
    DrawerItem(
      title: "View Notifications",
      icon: Icons.notifications_outlined,
      route: () => view_notification(),
      color: Color(0xFF8B5CF6),
    ),
    DrawerItem(
      title: "View Groups",
      icon: Icons.group_outlined,
      route: () => view_group(),
      color: Color(0xFF667EEA),
    ),
    DrawerItem(
      title: "View Request For Notes",
      icon: Icons.request_page_outlined,
      route: () => view_request_notes(),
      color: Color(0xFF8B5CF6),
    ),
    DrawerItem(
      title: "View Approved Request",
      icon: Icons.verified_outlined,
      route: () => view_approved_request(),
      color: Color(0xFF667EEA),
    ),
    DrawerItem(
      title: "View Other Students Notes",
      icon: Icons.note_outlined,
      route: () => view_others_previousnotes(),
      color: Color(0xFF8B5CF6),
    ),
    DrawerItem(
      title: "View My Previous Notes",
      icon: Icons.my_library_books_outlined,
      route: () => view_my_previousnotes(),
      color: Color(0xFF667EEA),
    ),
    DrawerItem(
      title: "View Ordered Notes",
      icon: Icons.shopping_cart_outlined,
      route: () => view_ordered_previousnotes(),
      color: Color(0xFF8B5CF6),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFAFAFA),
      appBar: AppBar(
        title: Text(
          "College Connect",
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w700,
            color: Colors.white,
            letterSpacing: 0.5,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xFF667EEA),
                Color(0xFF8B5CF6),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: Color(0xFF667EEA).withOpacity(0.3),
                blurRadius: 15,
                offset: Offset(0, 3),
              ),
            ],
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => profile()),
              );
            },
            icon: Icon(Icons.person_outline, color: Colors.white),
            tooltip: "Profile",
          ),
        ],
      ),
      drawer: _buildDrawer(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Hero Section
            Container(
              height: 200,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF667EEA).withOpacity(0.9),
                    Color(0xFF8B5CF6).withOpacity(0.9),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Stack(
                children: [
                  Positioned(
                    right: -50,
                    top: -50,
                    child: Container(
                      width: 200,
                      height: 200,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(0.1),
                      ),
                    ),
                  ),
                  Positioned(
                    left: -30,
                    bottom: -30,
                    child: Container(
                      width: 150,
                      height: 150,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(0.1),
                      ),
                    ),
                  ),
                  Center(
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "Welcome Back!",
                            style: TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              letterSpacing: 1,
                            ),
                          ),
                          SizedBox(height: 10),
                          Text(
                            "Your digital campus is here",
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.white.withOpacity(0.9),
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Quick Stats Cards
            Padding(
              padding: EdgeInsets.all(20),
              child: Row(
                children: [
                  Expanded(
                    child: _buildStatCard(
                      title: "Academic",
                      icon: Icons.school_outlined,
                      count: "8",
                      color: Color(0xFF667EEA),
                    ),
                  ),
                  SizedBox(width: 15),
                  Expanded(
                    child: _buildStatCard(
                      title: "Resources",
                      icon: Icons.library_books_outlined,
                      count: "12+",
                      color: Color(0xFF8B5CF6),
                    ),
                  ),
                ],
              ),
            ),

            // Main Features Grid
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.dashboard_outlined,
                        color: Color(0xFF667EEA),
                        size: 20,
                      ),
                      SizedBox(width: 8),
                      Text(
                        "Quick Access",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 15),
                  GridView.count(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    crossAxisCount: 2,
                    crossAxisSpacing: 15,
                    mainAxisSpacing: 15,
                    children: [
                      _buildFeatureCard(
                        title: "My Profile",
                        icon: Icons.person_outline,
                        color: Color(0xFF667EEA),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => profile()),
                        ),
                      ),
                      _buildFeatureCard(
                        title: "Subjects",
                        icon: Icons.menu_book_outlined,
                        color: Color(0xFF8B5CF6),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => view_subject()),
                        ),
                      ),
                      _buildFeatureCard(
                        title: "Assignments",
                        icon: Icons.assignment_outlined,
                        color: Color(0xFF667EEA),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => view_assignments()),
                        ),
                      ),
                      _buildFeatureCard(
                        title: "Attendance",
                        icon: Icons.calendar_today_outlined,
                        color: Color(0xFF8B5CF6),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => view_attendance()),
                        ),
                      ),
                      _buildFeatureCard(
                        title: "Materials",
                        icon: Icons.library_books_outlined,
                        color: Color(0xFF667EEA),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => view_materials()),
                        ),
                      ),
                      _buildFeatureCard(
                        title: "Events",
                        icon: Icons.event_outlined,
                        color: Color(0xFF8B5CF6),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => view_events()),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Services Section
            Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.auto_awesome_mosaic_outlined,
                        color: Color(0xFF667EEA),
                        size: 20,
                      ),
                      SizedBox(width: 8),
                      Text(
                        "Learning Services",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 15),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        _buildServiceCard(
                          title: "AI Notes",
                          icon: Icons.auto_awesome_outlined,
                          description: "Generate lecture notes",
                          color: Color(0xFF667EEA),
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => ai_lecturenotes()),
                          ),
                        ),
                        SizedBox(width: 15),
                        _buildServiceCard(
                          title: "ChatBot",
                          icon: Icons.smart_toy_outlined,
                          description: "Get instant help",
                          color: Color(0xFF8B5CF6),
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => MyChatBotApp()),
                          ),
                        ),
                        SizedBox(width: 15),
                        _buildServiceCard(
                          title: "Study Groups",
                          icon: Icons.group_outlined,
                          description: "Collaborate & learn",
                          color: Color(0xFF667EEA),
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => view_group()),
                          ),
                        ),
                        SizedBox(width: 15),
                        _buildServiceCard(
                          title: "Notes Market",
                          icon: Icons.shopping_cart_outlined,
                          description: "Buy & sell notes",
                          color: Color(0xFF8B5CF6),
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => view_others_previousnotes()),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Footer Section
            Container(
              margin: EdgeInsets.only(top: 30),
              padding: EdgeInsets.all(25),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF667EEA),
                    Color(0xFF8B5CF6),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Column(
                children: [
                  Text(
                    "College Connect Platform",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Your complete academic companion",
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.white.withOpacity(0.8),
                    ),
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.school_outlined, color: Colors.white, size: 16),
                      SizedBox(width: 8),
                      Text(
                        "Academic Excellence",
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(width: 20),
                      Icon(Icons.security_outlined, color: Colors.white, size: 16),
                      SizedBox(width: 8),
                      Text(
                        "Secure Platform",
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      child: SingleChildScrollView(
        child: Column(
          children: [
            // Drawer Header
            Container(
              height: 180,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF667EEA),
                    Color(0xFF8B5CF6),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 70,
                      height: 70,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(0.2),
                        border: Border.all(color: Colors.white, width: 2),
                      ),
                      child: Icon(
                        Icons.school_outlined,
                        size: 32,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(height: 15),
                    Text(
                      "College Connect",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      "Student Dashboard",
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.white.withOpacity(0.9),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Drawer Items
            Padding(
              padding: EdgeInsets.all(15),
              child: Column(
                children: _drawerItems.map((item) => _buildDrawerItem(item)).toList(),
              ),
            ),

            // Logout Button
            Padding(
              padding: EdgeInsets.all(15),
              child: Container(
                decoration: BoxDecoration(
                  color: Color(0xFFFEF2F2),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Color(0xFFFECACA)),
                ),
                child: ListTile(
                  leading: Icon(
                    Icons.logout_outlined,
                    color: Color(0xFFDC2626),
                  ),
                  title: Text(
                    "Log Out",
                    style: TextStyle(
                      color: Color(0xFFDC2626),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  onTap: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => login()),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerItem(DrawerItem item) {
    return Card(
      margin: EdgeInsets.only(bottom: 8),
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: BorderSide(color: Color(0xFFF1F5F9), width: 1),
      ),
      child: ListTile(
        leading: Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: item.color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: item.color.withOpacity(0.3)),
          ),
          child: Icon(
            item.icon,
            size: 18,
            color: item.color,
          ),
        ),
        title: Text(
          item.title,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: Color(0xFF334155),
          ),
        ),
        trailing: Icon(
          Icons.arrow_forward_ios_rounded,
          size: 14,
          color: Color(0xFF94A3B8),
        ),
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => item.route()),
          );
        },
        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      ),
    );
  }

  Widget _buildStatCard({required String title, required IconData icon, required String count, required Color color}) {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
        border: Border.all(color: Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              icon,
              color: color,
              size: 22,
            ),
          ),
          SizedBox(height: 15),
          Text(
            count,
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w700,
              color: Color(0xFF1E293B),
            ),
          ),
          SizedBox(height: 5),
          Text(
            title,
            style: TextStyle(
              fontSize: 14,
              color: Color(0xFF64748B),
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureCard({required String title, required IconData icon, required Color color, required Function onTap}) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => onTap(),
        child: Container(
          padding: EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Color(0xFFE2E8F0)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.03),
                blurRadius: 6,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: color.withOpacity(0.3), width: 1.5),
                ),
                child: Icon(
                  icon,
                  color: color,
                  size: 24,
                ),
              ),
              SizedBox(height: 12),
              Text(
                title,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF1E293B),
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildServiceCard({required String title, required IconData icon, required String description, required Color color, required Function onTap}) {
    return Container(
      width: 150,
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => onTap(),
          child: Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Color(0xFFE2E8F0)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 8,
                  offset: Offset(0, 3),
                ),
              ],
            ),
            child: Column(
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        color.withOpacity(0.2),
                        color.withOpacity(0.1),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: color.withOpacity(0.3)),
                  ),
                  child: Icon(
                    icon,
                    color: color,
                    size: 28,
                  ),
                ),
                SizedBox(height: 15),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF1E293B),
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 5),
                Text(
                  description,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class DrawerItem {
  final String title;
  final IconData icon;
  final Widget Function() route;
  final Color color;

  DrawerItem({
    required this.title,
    required this.icon,
    required this.route,
    required this.color,
  });
}






// import 'package:college_connect/login.dart';
// import 'package:college_connect/student/ai_lecturenotes.dart';
// import 'package:college_connect/student/chatbot.dart';
// import 'package:college_connect/student/view_group.dart';
// import 'package:college_connect/student/profile.dart';
// import 'package:college_connect/student/sent_complaints.dart';
// import 'package:college_connect/student/sent_feedback.dart';
// import 'package:college_connect/student/verify_request_notes.dart';
// import 'package:college_connect/student/view_approved_request.dart';
// import 'package:college_connect/student/view_assignments.dart';
// import 'package:college_connect/student/view_attendance.dart';
// import 'package:college_connect/student/view_events.dart';
// import 'package:college_connect/student/view_faculty.dart';
// import 'package:college_connect/student/view_intmark.dart';
// import 'package:college_connect/student/view_materials.dart';
// import 'package:college_connect/student/view_my_previousnotes.dart';
// import 'package:college_connect/student/view_notification.dart';
// import 'package:college_connect/student/view_ordered_previousnotes.dart';
// import 'package:college_connect/student/view_others_previousnotes.dart';
// import 'package:college_connect/student/view_replies.dart';
// import 'package:college_connect/student/view_request_notes.dart';
// import 'package:college_connect/student/view_subject.dart';
// import 'package:flutter/material.dart';
//
// import 'chat.dart';
//
// class home extends StatelessWidget {
//   const home({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(home: home_sub(),);
//   }
// }
// class home_sub extends StatefulWidget {
//   const home_sub({Key? key}) : super(key: key);
//
//   @override
//   State<home_sub> createState() => _home_subState();
// }
//
// class _home_subState extends State<home_sub> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text("HOME"),centerTitle: true,),
//       drawer: Drawer(
//         child:SingleChildScrollView(child:  Column(children: [
//           ListTile(title: Text("View Profile"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>profile())),),
//           ListTile(title: Text("View Subject"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>view_subject())),),
//           ListTile(title: Text("View Faculty"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>view_faculty())),),
//           ListTile(title: Text("View Materials"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>view_materials())),),
//           ListTile(title: Text("View Assignments"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>view_assignments())),),
//           ListTile(title: Text("View Attendance"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>view_attendance())),),
//           ListTile(title: Text("View Internal Marks"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>view_intmarks())),),
//           ListTile(title: Text("View Events & Results"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>view_events())),),
//           ListTile(title: Text("ChatBot"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>MyChatBotApp())),),
//           ListTile(title: Text("Sent Complaints"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>sent_complaints())),),
//           ListTile(title: Text("View Replies"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>view_replies())),),
//           ListTile(title: Text("View Notifications"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>view_notification())),),
//           ListTile(title: Text("View Groups"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>view_group())),),
//           ListTile(title: Text("View Request For Notes"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>view_request_notes())),),
//           ListTile(title: Text("View Approved Request"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>view_approved_request())),),
//           ListTile(title: Text("View Other Students Notes"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>view_others_previousnotes())),),
//           ListTile(title: Text("View My Previous Notes"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>view_my_previousnotes())),),
//           ListTile(title: Text("View Ordered Notes"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>view_ordered_previousnotes())),),
//           ListTile(title: Text("Log Out"),onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>login())),),
//
//
//         ],),)
//       ),
//       body:Center(child: Column(children: [
//         Text("welcome")
//       ],),) ,
//     );
//   }
// }
