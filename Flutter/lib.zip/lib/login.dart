import 'dart:convert';
import 'package:college_connect/student/profile.dart';
import 'package:college_connect/student/studenthome.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'forgotemail.dart';

void main() {
  runApp(login());
}

class login extends StatelessWidget {
  const login({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Edura',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Roboto',
      ),
      home: login_sub(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class login_sub extends StatefulWidget {
  const login_sub({Key? key}) : super(key: key);

  @override
  State<login_sub> createState() => _State();
}

class _State extends State<login_sub> {
  TextEditingController username = TextEditingController(text: "sreyavb@gmail.com");
  TextEditingController password = TextEditingController(text: "sreyavb");
  bool _isLoading = false;
  bool _obscurePassword = true;
  bool _rememberMe = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8FAFC),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Container(
              width: 750,
              constraints: BoxConstraints(
                maxWidth: 750,
                minHeight: 480,
              ),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Color(0xFF6A5ACD).withOpacity(0.08),
                    blurRadius: 12,
                    spreadRadius: 2,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: IntrinsicHeight(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Left Panel - Branding
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Color(0xFF4A8DF8),
                              Color(0xFF8A2BE2),
                            ],
                          ),
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(16),
                            bottomLeft: Radius.circular(16),
                          ),
                        ),
                        padding: EdgeInsets.symmetric(horizontal: 30, vertical: 25),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Logo
                            Container(
                              margin: EdgeInsets.only(bottom: 35),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    width: 55,
                                    height: 55,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Icon(
                                      Icons.school,
                                      size: 30,
                                      color: Color(0xFF4A8DF8),
                                    ),
                                  ),
                                  SizedBox(height: 18),
                                  Text(
                                    "Edura",
                                    style: TextStyle(
                                      fontSize: 30,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                  SizedBox(height: 8),
                                  Text(
                                    "Education Excellence Simplified",
                                    style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.white.withOpacity(0.95),
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            // Features
                            SizedBox(height: 35),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                _buildFeatureItem(
                                  Icons.verified_user,
                                  "Two-factor authentication",
                                ),
                                SizedBox(height: 18),
                                _buildFeatureItem(
                                  Icons.lock,
                                  "End-to-end encryption",
                                ),
                                SizedBox(height: 18),
                                _buildFeatureItem(
                                  Icons.support,
                                  "24/7 Support",
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Right Panel - Login Form
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 35, vertical: 30),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // Header
                            Container(
                              margin: EdgeInsets.only(bottom: 35),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Welcome to Edura",
                                    style: TextStyle(
                                      fontSize: 26,
                                      fontWeight: FontWeight.w600,
                                      color: Color(0xFF1E293B),
                                    ),
                                  ),
                                  SizedBox(height: 8),
                                  Text(
                                    "Sign in to your Edura account to continue",
                                    style: TextStyle(
                                      fontSize: 15,
                                      color: Color(0xFF64748B),
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            // Form
                            Form(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // Username Field
                                  _buildFormField(
                                    "Username",
                                    Icons.person,
                                    username,
                                    false,
                                  ),
                                  SizedBox(height: 22),

                                  // Password Field
                                  _buildPasswordField(),
                                  SizedBox(height: 22),

                                  // Remember Me & Forgot Password
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Row(
                                          children: [
                                            Checkbox(
                                              value: _rememberMe,
                                              onChanged: (value) {
                                                setState(() {
                                                  _rememberMe = value!;
                                                });
                                              },
                                              activeColor: Color(0xFF8A2BE2),
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.circular(4),
                                              ),
                                            ),
                                            Flexible(
                                              child: Text(
                                                "Remember me",
                                                style: TextStyle(
                                                  fontSize: 14,
                                                  color: Color(0xFF475569),
                                                ),
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      TextButton(
                                        onPressed: () async {
                                          SharedPreferences prefs = await SharedPreferences.getInstance();
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) => forgotemail(),
                                            ),
                                          );
                                        },
                                        style: TextButton.styleFrom(
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Text(
                                          "Forgot password?",
                                          style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w500,
                                            color: Color(0xFF8A2BE2),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 28),

                                  // Login Button
                                  Container(
                                    width: double.infinity,
                                    height: 50,
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [
                                          Color(0xFF4A8DF8),
                                          Color(0xFF8A2BE2),
                                        ],
                                        begin: Alignment.centerLeft,
                                        end: Alignment.centerRight,
                                      ),
                                      borderRadius: BorderRadius.circular(10),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Color(0xFF6A5ACD).withOpacity(0.2),
                                          blurRadius: 8,
                                          offset: Offset(0, 4),
                                        ),
                                      ],
                                    ),
                                    child: Material(
                                      color: Colors.transparent,
                                      borderRadius: BorderRadius.circular(10),
                                      child: InkWell(
                                        borderRadius: BorderRadius.circular(10),
                                        onTap: _isLoading ? null : _handleLogin,
                                        child: Center(
                                          child: _isLoading
                                              ? SizedBox(
                                            width: 20,
                                            height: 20,
                                            child: CircularProgressIndicator(
                                              strokeWidth: 2,
                                              color: Colors.white,
                                            ),
                                          )
                                              : Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Icon(
                                                Icons.login,
                                                size: 18,
                                                color: Colors.white,
                                              ),
                                              SizedBox(width: 10),
                                              Text(
                                                "Sign In",
                                                style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w600,
                                                  color: Colors.white,
                                                  letterSpacing: 0.5,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),

                                  // Divider
                                  SizedBox(height: 28),
                                  Divider(
                                    color: Color(0xFFE2E8F0),
                                    thickness: 1,
                                  ),

                                  // Contact Admin - NOW VISIBLE AND WORKING
                                  SizedBox(height: 20),
                                  Center(
                                    child: MouseRegion(
                                      cursor: SystemMouseCursors.click,
                                      child: GestureDetector(
                                        onTap: _callAdministrator,
                                        child: Container(
                                          padding: EdgeInsets.all(8),
                                          child: Text.rich(
                                            TextSpan(
                                              text: "Don't have an account? ",
                                              style: TextStyle(
                                                fontSize: 14,
                                                color: Color(0xFF64748B),
                                              ),
                                              children: [
                                                TextSpan(
                                                  text: "Contact administrator",
                                                  style: TextStyle(
                                                    fontSize: 14,
                                                    fontWeight: FontWeight.w500,
                                                    color: Color(0xFF8A2BE2),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFeatureItem(IconData icon, String text) {
    return Row(
      children: [
        Icon(
          icon,
          size: 20,
          color: Colors.white,
        ),
        SizedBox(width: 12),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              fontSize: 14,
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFormField(
      String label,
      IconData icon,
      TextEditingController controller,
      bool isPassword,
      ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              icon,
              size: 16,
              color: Color(0xFF8A2BE2),
            ),
            SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Color(0xFF475569),
              ),
            ),
          ],
        ),
        SizedBox(height: 8),
        Container(
          height: 48,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: Color(0xFFE2E8F0),
              width: 1.5,
            ),
          ),
          child: Row(
            children: [
              SizedBox(width: 16),
              Icon(
                icon,
                size: 18,
                color: Color(0xFF94A3B8),
              ),
              SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: controller,
                  obscureText: isPassword && _obscurePassword,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Enter your ${label.toLowerCase()}",
                    hintStyle: TextStyle(
                      color: Color(0xFF94A3B8),
                      fontSize: 15,
                    ),
                  ),
                  style: TextStyle(
                    fontSize: 15,
                    color: Color(0xFF334155),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPasswordField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              Icons.lock,
              size: 16,
              color: Color(0xFF8A2BE2),
            ),
            SizedBox(width: 8),
            Text(
              "Password",
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Color(0xFF475569),
              ),
            ),
          ],
        ),
        SizedBox(height: 8),
        Container(
          height: 48,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: Color(0xFFE2E8F0),
              width: 1.5,
            ),
          ),
          child: Row(
            children: [
              SizedBox(width: 16),
              Icon(
                Icons.lock,
                size: 18,
                color: Color(0xFF94A3B8),
              ),
              SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: password,
                  obscureText: _obscurePassword,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Enter your password",
                    hintStyle: TextStyle(
                      color: Color(0xFF94A3B8),
                      fontSize: 15,
                    ),
                  ),
                  style: TextStyle(
                    fontSize: 15,
                    color: Color(0xFF334155),
                  ),
                ),
              ),
              IconButton(
                icon: Icon(
                  _obscurePassword ? Icons.visibility : Icons.visibility_off,
                  size: 20,
                  color: Color(0xFF94A3B8),
                ),
                onPressed: () {
                  setState(() {
                    _obscurePassword = !_obscurePassword;
                  });
                },
                padding: EdgeInsets.all(8),
              ),
              SizedBox(width: 8),
            ],
          ),
        ),
      ],
    );
  }

  void _handleLogin() async {
    setState(() {
      _isLoading = true;
    });

    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      var data = await http.post(
        Uri.parse(prefs.getString("ip").toString() + "/userlogin/"),
        body: {
          "username": username.text,
          'pwd': password.text,
        },
      );
      var decodedata = json.decode(data.body);
      if (decodedata['status'] == 'success') {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        prefs.setString("sid", decodedata['sid'].toString());
        prefs.setString("lid", decodedata['lid'].toString());
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => home(),
          ),
        );
      } else {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text("Login Failed"),
            content: Text("Invalid username or password. Please try again."),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text("OK"),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text("Network Error"),
          content: Text("Please check your internet connection and try again."),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("OK"),
            ),
          ],
        ),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _callAdministrator() async {
    final phoneNumber = 'tel:7907003039';
    try {
      if (await canLaunch(phoneNumber)) {
        await launch(phoneNumber);
      } else {
        // Copy phone number to clipboard as fallback
        await Clipboard.setData(ClipboardData(text: '7907003039'));
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text("Cannot Make Call"),
            content: Text("Phone number 7907003039 has been copied to clipboard.\n\nYou can manually dial this number."),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text("OK"),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      // Copy phone number to clipboard as fallback
      await Clipboard.setData(ClipboardData(text: '7907003039'));
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text("Error"),
          content: Text("Phone number 7907003039 has been copied to clipboard.\n\nPlease call this number manually."),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("OK"),
            ),
          ],
        ),
      );
    }
  }
}








// import 'dart:convert';
//
// import 'package:college_connect/student/profile.dart';
// import 'package:college_connect/student/studenthome.dart';
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:http/http.dart' as http;
//
// import 'forgotemail.dart';
//
// void main(){
//   runApp(login());
// }
// class login extends StatelessWidget {
// const login({Key? key}) : super(key: key);
//
// @override
// Widget build(BuildContext context) {
// return MaterialApp(home:login_sub() ,);
// }
// }
//
// class login_sub extends StatefulWidget {
// const login_sub({Key? key}) : super(key: key);
//
// @override
// State<login_sub> createState() => _State();
// }
//
// class _State extends State<login_sub> {
//   TextEditingController username=TextEditingController(text: "sreyavb@gmail.com");
//   TextEditingController password=TextEditingController(text:"sreyavb");
// @override
// Widget build(BuildContext context) {
// return Scaffold(
//   body: Center(child: Column(children: [
//     SizedBox(height: 30,),
//     SizedBox(height: 40,width: 300,child: TextField(controller: username,
//       decoration: InputDecoration(border: OutlineInputBorder(),labelText: "Username"),
//     ),),
//     SizedBox(height: 30,),
//     SizedBox(height: 40,width: 300,child: TextField(controller: password,
//       decoration: InputDecoration(border: OutlineInputBorder(),labelText: "Password"),
//     ),),
//     ElevatedButton(onPressed: () async {
//       SharedPreferences prefs= await SharedPreferences.getInstance();
//       var data =
//       await http.post(Uri.parse(prefs.getString("ip").toString()+"/userlogin"),
//           body: {"username":username.text,'pwd':password.text}
//       );
//       var decodedata=json.decode(data.body);
//       if(decodedata['status']=='success'){
//         SharedPreferences prefs=await SharedPreferences.getInstance();
//         prefs.setString("sid", decodedata['sid'].toString());
//         prefs.setString("lid", decodedata['lid'].toString());
//         Navigator.push(context, MaterialPageRoute(builder: (context)=>home()));
//       }
//       else{
//         Navigator.push(context, MaterialPageRoute(builder: (context)=>login()));
//
//       }
//
//     }, child: Text("LOGIN")),
//     TextButton(onPressed: () async {
//       SharedPreferences prefs= await SharedPreferences.getInstance();
//       Navigator.push(context, MaterialPageRoute(builder: (context)=>forgotemail()));
//
//     }, child: Text("ForgotPassword"))
//   ],),),
//
//
// );
// }
// }